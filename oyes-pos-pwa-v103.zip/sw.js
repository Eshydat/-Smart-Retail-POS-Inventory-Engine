/* =========================================================================
   Oyes POS — Service Worker
   Caches the app's own static shell (HTML/CSS/JS/manifest) so it loads
   instantly and works offline. Deliberately does NOT cache anything else —
   this is a live point-of-sale app with real-time stock, prices, and auth
   via Supabase, plus third-party CDN scripts (JsBarcode/ZXing/supabase-js).
   Caching any of that could serve stale stock/prices or an expired login,
   which would be actively harmful, not just inconvenient.
   ========================================================================= */

const CACHE_NAME = 'oyes-pos-shell-v4';
const STATIC_ASSETS = [
  './',
  './index.html',
  './styles.css',
  './app.js',
  './manifest.json',
];

// These are pinned/versioned library files (not live data endpoints), so caching them carries
// none of the "stale stock/price/login" risk described above — they only ever change if the
// version number in the URL itself changes. Caching them means barcode scanning and the rest of
// the UI still work offline after the very first successful load, instead of just the shell.
const CDN_LIBRARY_ASSETS = [
  'https://cdnjs.cloudflare.com/ajax/libs/jsbarcode/3.12.3/JsBarcode.all.min.js',
  'https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2',
  'https://cdn.jsdelivr.net/npm/@zxing/library@0.19.1/umd/index.min.js',
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then((cache) => cache.addAll(STATIC_ASSETS))
      .then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys()
      .then((keys) => Promise.all(
        keys.filter((key) => key !== CACHE_NAME).map((key) => caches.delete(key))
      ))
      .then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', (event) => {
  const req = event.request;
  const url = new URL(req.url);

  // Only ever intercept GET requests for our own same-origin static shell files, plus the
  // handful of pinned third-party library scripts above. Everything else (Supabase API/auth
  // calls, POST/PUT/DELETE requests, barcode/photo data) is left completely alone and goes
  // straight to the network.
  const isSameOrigin = url.origin === self.location.origin;
  const isGet = req.method === 'GET';
  const isStaticShellFile = isSameOrigin && STATIC_ASSETS.some((asset) => {
    const assetPath = asset === './' ? '/' : asset.replace('./', '/');
    return url.pathname === assetPath || url.pathname.endsWith(assetPath);
  });
  const isCdnLibrary = CDN_LIBRARY_ASSETS.includes(req.url);

  if (!isGet || !(isStaticShellFile || isCdnLibrary)) {
    return; // not our concern — let the browser handle it normally
  }

  // Network-first: while this app is under active development, always try to get the freshest
  // copy first so a fix actually takes effect on the very next reload instead of one reload
  // after that. Falls back to the cached copy only when the network fetch fails (offline).
  event.respondWith(
    fetch(req)
      .then((response) => {
        if (response && response.status === 200) {
          const clone = response.clone();
          caches.open(CACHE_NAME).then((cache) => cache.put(req, clone));
        }
        return response;
      })
      .catch(() => caches.match(req))
  );
});
