/* =========================================================================
   OYES POS — mobile point-of-sale app
   Vanilla JS, single file. Data persisted via window.storage (per-user).
   ========================================================================= */

/* ---------------- seed data (from uploaded workbook) ---------------- */
const SEED_PRODUCTS = [{"id": "PROD-1", "name": "CT plus 250ml", "category": "Skin Care & Lotion", "cost": 2800.0, "price": 3500.0, "stock": 1}, {"id": "PROD-2", "name": "Light Up 400ml", "category": "Skin Care & Lotion", "cost": 4500.0, "price": 5500.0, "stock": 3}, {"id": "PROD-3", "name": "Rich N Pure 250ml", "category": "Skin Care & Lotion", "cost": 3500.0, "price": 4500.0, "stock": 5}, {"id": "PROD-4", "name": "Rich N Pure Soap", "category": "Bathing Soap", "cost": 1333.0, "price": 2000.0, "stock": 5}, {"id": "PROD-5", "name": "Veet Gold Oil Tumeric", "category": "Body Oil", "cost": 4500.0, "price": 6000.0, "stock": 1}, {"id": "PROD-6", "name": "Irish Gold Egg Yolk", "category": "Skin Care & Lotion", "cost": 2667.0, "price": 3500.0, "stock": 3}, {"id": "PROD-7", "name": "Piment Cleanser", "category": "Cleanser", "cost": 1333.0, "price": 2000.0, "stock": 5}, {"id": "PROD-8", "name": "Nivea Radiant Beauty", "category": "Skin Care & Lotion", "cost": 4750.0, "price": 6000.0, "stock": 4}, {"id": "PROD-9", "name": "Nivea Cocoa", "category": "Skin Care & Lotion", "cost": 3750.0, "price": 4500.0, "stock": 3}, {"id": "PROD-10", "name": "Kul Spa Scrub", "category": "Skin Care", "cost": 3083.0, "price": 4500.0, "stock": 3}, {"id": "PROD-11", "name": "Alpha Arbutln", "category": "Skin Care & Lotion", "cost": 2916.0, "price": 4500.0, "stock": 2}, {"id": "PROD-12", "name": "Fair Child Vitamin C", "category": "Skin Care & Lotion", "cost": 2666.0, "price": 3500.0, "stock": 2}, {"id": "PROD-13", "name": "Kids And Teens", "category": "Skin Care & Lotion", "cost": 2583.0, "price": 3500.0, "stock": 3}, {"id": "PROD-14", "name": "Kojie San Soap", "category": "Bathing Soap", "cost": 1416.0, "price": 2000.0, "stock": 6}, {"id": "PROD-15", "name": "Blue Sea Vaseline 50ml", "category": "Skin Care & Lotion", "cost": 625.0, "price": 1000.0, "stock": 8}, {"id": "PROD-16", "name": "Lemovate Tube", "category": "Tubes", "cost": 1000.0, "price": 1300.0, "stock": 9}, {"id": "PROD-17", "name": "Miss Cherie", "category": "Skin Care & Lotion", "cost": 958.0, "price": 2000.0, "stock": 3}, {"id": "PROD-18", "name": "Sadoer", "category": "Skin Care & Lotion", "cost": 1958.0, "price": 3000.0, "stock": 5}, {"id": "PROD-19", "name": "Kojic White Soap", "category": "Bathing Soap", "cost": 1625.0, "price": 2000.0, "stock": 5}, {"id": "PROD-20", "name": "Nano Extra White Soap", "category": "Bathing Soap", "cost": 1625.0, "price": 2000.0, "stock": 16}, {"id": "PROD-21", "name": "Parley Goldie", "category": "Skin Care", "cost": 3125.0, "price": 4500.0, "stock": 8}, {"id": "PROD-22", "name": "Tea Tree Face Wash", "category": "Skin Care", "cost": 2333.0, "price": 3000.0, "stock": 12}, {"id": "PROD-23", "name": "Gluta White Bath", "category": "Liquid Soap", "cost": 1166.0, "price": 3000.0, "stock": 3}, {"id": "PROD-24", "name": "K Brother Shower Gel", "category": "Liquid Soap", "cost": 1166.0, "price": 3000.0, "stock": 3}, {"id": "PROD-25", "name": "Tumeric Soap", "category": "Bathing Soap", "cost": 1333.0, "price": 2000.0, "stock": 3}, {"id": "PROD-26", "name": "Stay Young Saop", "category": "Bathing Soap", "cost": 2916.0, "price": 4000.0, "stock": 3}, {"id": "PROD-27", "name": "Olaybact Kids N Teens", "category": "Skin Care & Lotion", "cost": 2600.0, "price": 3500.0, "stock": 3}, {"id": "PROD-28", "name": "KiddieTeenz", "category": "Skin Care & Lotion", "cost": 2600.0, "price": 3500.0, "stock": 3}, {"id": "PROD-29", "name": "Skin Doctor", "category": "Skin Care & Lotion", "cost": 4917.0, "price": 7000.0, "stock": 5}, {"id": "PROD-30", "name": "Rich N Pure Serum", "category": "Skin Care", "cost": 1625.0, "price": 2500.0, "stock": 11}, {"id": "PROD-31", "name": "Abana", "category": "Face Cream", "cost": 1000.0, "price": 1200.0, "stock": 4}, {"id": "PROD-32", "name": "Perfect Clinic BSC", "category": "Skin Care", "cost": 1125.0, "price": 1400.0, "stock": 0}, {"id": "PROD-33", "name": "Derma Extract BSC", "category": "Skin Care", "cost": 750.0, "price": 1200.0, "stock": 12}, {"id": "PROD-34", "name": "Biore UV Sun Screen", "category": "Skin Care", "cost": 2250.0, "price": 3500.0, "stock": 1}, {"id": "PROD-35", "name": "Swiss Flower", "category": "Air Freshener", "cost": 700.0, "price": 1000.0, "stock": 2}, {"id": "PROD-36", "name": "Oral B Medium Tooth Brush", "category": "Toileteries", "cost": 131.0, "price": 300.0, "stock": 13}, {"id": "PROD-38", "name": "fair child for prince &princess", "category": "Skin Care & Lotion", "cost": 2666.0, "price": 3500.0, "stock": 2}, {"id": "PROD-39", "name": "Brown Orchid", "category": "Body Spray", "cost": 2500.0, "price": 3500.0, "stock": 5}, {"id": "PROD-40", "name": "riggs", "category": "Body Spray", "cost": 2915.0, "price": 3500.0, "stock": 12}, {"id": "PROD-41", "name": "aventus for him", "category": "Body Spray", "cost": 2400.0, "price": 3000.0, "stock": 2}, {"id": "PROD-42", "name": "Vanilla Crush", "category": "Perfume", "cost": 1300.0, "price": 2000.0, "stock": 2}, {"id": "PROD-43", "name": "Asad", "category": "Perfume", "cost": 2500.0, "price": 5000.0, "stock": 1}, {"id": "PROD-44", "name": "Now", "category": "Perfume", "cost": 5000.0, "price": 6500.0, "stock": 2}, {"id": "PROD-45", "name": "Challenge S", "category": "Body Spray", "cost": 1000.0, "price": 2000.0, "stock": 1}, {"id": "PROD-46", "name": "Challenge P", "category": "Perfume", "cost": 3500.0, "price": 5000.0, "stock": 2}, {"id": "PROD-47", "name": "Doobai", "category": "Body Spray", "cost": 3000.0, "price": 3500.0, "stock": 3}, {"id": "PROD-48", "name": "Matadpor", "category": "Perfume", "cost": 2500.0, "price": 3000.0, "stock": 6}, {"id": "PROD-49", "name": "Element", "category": "Perfume", "cost": 3000.0, "price": 4000.0, "stock": 3}, {"id": "PROD-50", "name": "Ashantee", "category": "Perfume", "cost": 3000.0, "price": 4000.0, "stock": 5}, {"id": "PROD-51", "name": "Deal", "category": "Perfume", "cost": 5000.0, "price": 6500.0, "stock": 2}, {"id": "PROD-52", "name": "Top Breeze", "category": "Air Freshener", "cost": 3500.0, "price": 4500.0, "stock": 1}, {"id": "PROD-53", "name": "Ameer Al Oudh", "category": "Perfume", "cost": 5500.0, "price": 6500.0, "stock": 1}, {"id": "PROD-54", "name": "Ramz", "category": "Perfume", "cost": 5000.0, "price": 6500.0, "stock": 1}, {"id": "PROD-55", "name": "Red Diamond", "category": "Perfume", "cost": 4500.0, "price": 6000.0, "stock": 1}, {"id": "PROD-56", "name": "Joy Soap", "category": "Bathing Soap", "cost": 433.0, "price": 500.0, "stock": 12}, {"id": "PROD-57", "name": "Tender White 280ml", "category": "Skin Care & Lotion", "cost": 1867.0, "price": 2500.0, "stock": 3}, {"id": "PROD-58", "name": "K Brother Face Soap", "category": "Bathing Soap", "cost": 1333.0, "price": 1700.0, "stock": 5}, {"id": "PROD-59", "name": "Eva Soap", "category": "Bathing Soap", "cost": 600.0, "price": 800.0, "stock": 14}, {"id": "PROD-60", "name": "Almond", "category": "Skin Care & Lotion", "cost": 4500.0, "price": 6000.0, "stock": 1}, {"id": "PROD-61", "name": "white Secret  500ml", "category": "Skin Care & Lotion", "cost": 3300.0, "price": 4500.0, "stock": 3}, {"id": "PROD-62", "name": "white Secret  300ml", "category": "Skin Care & Lotion", "cost": 2200.0, "price": 3500.0, "stock": 3}, {"id": "PROD-63", "name": "Ashantee papaya", "category": "Bathing Soap", "cost": 1250.0, "price": 2000.0, "stock": 6}, {"id": "PROD-64", "name": "Stay Young F", "category": "Face Cream", "cost": 877.0, "price": 1200.0, "stock": 12}, {"id": "PROD-64-2", "name": "Dermaliss", "category": "Cleanser", "cost": 1542.0, "price": 2500.0, "stock": 4}, {"id": "PROD-65", "name": "visita Plus 250ml", "category": "Skin Care & Lotion", "cost": 1833.0, "price": 2500.0, "stock": 4}, {"id": "PROD-66", "name": "visita Plus 500ml", "category": "Skin Care & Lotion", "cost": 2750.0, "price": 3500.0, "stock": 6}, {"id": "PROD-67", "name": "Dodo Skin Gold", "category": "Face Cream", "cost": 834.0, "price": 1200.0, "stock": 4}, {"id": "PROD-68", "name": "Elixir Light", "category": "Face Cream", "cost": 1250.0, "price": 1500.0, "stock": 12}, {"id": "PROD-69", "name": "Parley Beauty", "category": "Face Cream", "cost": 3917.0, "price": 4500.0, "stock": 6}, {"id": "PROD-70", "name": "Hug", "category": "Perfume", "cost": 3000.0, "price": 4500.0, "stock": 6}, {"id": "PROD-71", "name": "Cred 4 Him", "category": "Perfume", "cost": 5000.0, "price": 6500.0, "stock": 3}, {"id": "PROD-72", "name": "Aventus 4 Him", "category": "Perfume", "cost": 14500.0, "price": 18000.0, "stock": 2}, {"id": "PROD-73", "name": "Sure Spray", "category": "Body Spray", "cost": 3667.0, "price": 4500.0, "stock": 6}, {"id": "PROD-74", "name": "Nivea Spray", "category": "Body Spray", "cost": 4500.0, "price": 6500.0, "stock": 3}, {"id": "PROD-75", "name": "24k RollOn", "category": "Roll-On", "cost": 750.0, "price": 2000.0, "stock": 6}, {"id": "PROD-76", "name": "Suger Pf", "category": "Perfume", "cost": 10000.0, "price": 13000.0, "stock": 3}, {"id": "PROD-77", "name": "SugerBaby", "category": "Perfume", "cost": 3500.0, "price": 5500.0, "stock": 3}, {"id": "PROD-78", "name": "Nivea RollOn", "category": "Roll-On", "cost": 1667.0, "price": 2000.0, "stock": 12}, {"id": "PROD-79", "name": "Rexona", "category": "Roll-On", "cost": 1500.0, "price": 2000.0, "stock": 6}, {"id": "PROD-80", "name": "Suspenso", "category": "Perfume", "cost": 14500.0, "price": 18000.0, "stock": 2}, {"id": "PROD-81", "name": "Gk Men", "category": "Perfume", "cost": 1500.0, "price": 2500.0, "stock": 3}, {"id": "PROD-82", "name": "Faidra", "category": "Perfume", "cost": 5500.0, "price": 6500.0, "stock": 2}, {"id": "PROD-83", "name": "Storm Elixir", "category": "Body Spray", "cost": 2250.0, "price": 3500.0, "stock": 2}, {"id": "PROD-84", "name": "24k pf", "category": "Perfume", "cost": 4500.0, "price": 6000.0, "stock": 1}, {"id": "PROD-85", "name": "Dear Body Spy", "category": "Body Spray", "cost": 2700.0, "price": 4000.0, "stock": 1}, {"id": "PROD-86", "name": "karis", "category": "Body Spray", "cost": 3000.0, "price": 4500.0, "stock": 1}, {"id": "PROD-87", "name": "Elixir Light Body Cream", "category": "Skin Care & Lotion", "cost": 2766.0, "price": 3500.0, "stock": 1}, {"id": "PROD-88", "name": "Gluta White Cream", "category": "Skin Care & Lotion", "cost": 3583.0, "price": 4500.0, "stock": 2}, {"id": "PROD-89", "name": "Caro Tone Cup B/S", "category": "Skin Care & Lotion", "cost": 2416.0, "price": 3500.0, "stock": 4}, {"id": "PROD-90", "name": "White secret S/S", "category": "Skin Care & Lotion", "cost": 1650.0, "price": 2500.0, "stock": 3}, {"id": "PROD-91", "name": "Perfect Glow S/S", "category": "Skin Care & Lotion", "cost": 1700.0, "price": 2500.0, "stock": 3}, {"id": "PROD-92", "name": "CT saop", "category": "Bathing Soap", "cost": 1166.0, "price": 2000.0, "stock": 2}, {"id": "PROD-93", "name": "Pears Baby Oil", "category": "Body Oil", "cost": 1800.0, "price": 2500.0, "stock": 6}, {"id": "PROD-94", "name": "Perfect Glow Soap", "category": "Bathing Soap", "cost": 1333.0, "price": 2000.0, "stock": 2}, {"id": "PROD-95", "name": "Light Up Soap", "category": "Bathing Soap", "cost": 2166.0, "price": 2500.0, "stock": 2}, {"id": "PROD-96", "name": "Viva  Medium 170g", "category": "Detergent", "cost": 430.0, "price": 550.0, "stock": 26}, {"id": "PROD-97", "name": "So Klin 170g", "category": "Detergent", "cost": 408.0, "price": 500.0, "stock": 12}, {"id": "PROD-98", "name": "Klin 170g", "category": "Detergent", "cost": 408.0, "price": 500.0, "stock": 13}, {"id": "PROD-99", "name": "Malto", "category": "Biscuit", "cost": 86.1, "price": 100.0, "stock": 68}, {"id": "PROD-100", "name": "Peak Milk Sachet", "category": "Beverages", "cost": 175.0, "price": 250.0, "stock": 34}, {"id": "PROD-101", "name": "Nyra Elro Mikk", "category": "Sweats", "cost": 44.1, "price": 50.0, "stock": 98}, {"id": "PROD-102", "name": "Milo 3 in 1 Sachet", "category": "Beverages", "cost": 300.0, "price": 350.0, "stock": 10}, {"id": "PROD-103", "name": "kelifa Choco", "category": "Sweats", "cost": 18.0, "price": 33.3, "stock": 50}, {"id": "PROD-104", "name": "Choco King", "category": "Biscuit", "cost": 112.5, "price": 150.0, "stock": 45}, {"id": "PROD-105", "name": "3 Crown Sachet", "category": "Beverages", "cost": 688.0, "price": 900.0, "stock": 12}, {"id": "PROD-106", "name": "Peak Milk Evap", "category": "Beverages", "cost": 239.0, "price": 300.0, "stock": 18}];

const CATEGORY_PALETTE = ["#0B5D57","#E8962E","#C1443D","#3C6E9B","#8B5A9E","#3C8A5B","#B8843A","#6B6255","#C9576B","#3D8FA0"];

function buildSeedCategories(products){
  const names = [...new Set(products.map(p=>p.category))].sort();
  return names.map((name,i)=>({ id:'cat_'+i, name, color: CATEGORY_PALETTE[i % CATEGORY_PALETTE.length] }));
}

/* ---------------- state ---------------- */
function firstOfCurrentMonth(){
  const d = new Date();
  const p = n => String(n).padStart(2,'0');
  return `${d.getFullYear()}-${p(d.getMonth()+1)}-01`;
}

const state = {
  ready:false,
  products:[],
  categories:[],
  transactions:[],
  stockLog:[], // manual stock adjustments (restocks) logged per variant, for the variant history view
  customers:[], // credit customers: {id, name, phone, balance, createdAt, updatedAt}
  customerLedger:[], // history of credit sales & payments: {id, customerId, type:'sale'|'payment', txnId, amount, paid, balanceAfter, payMethod, note, date}
  customersSearch:'',
  settings:{ shopName:'Oyes Store', shopSub:'Beauty • Cosmetics • Provisions', currency:'₦', txnSeq:1, address:'Lagos, Nigeria', logo:'' },
  cloud:{ url:'https://ofniihohppitzvhxzirt.supabase.co', key:'sb_publishable_v1lCfzvB0PFKzRG4ulAiAA_3Go90r8i', connected:false, client:null, error:'', configured:false },
  auth:{ session:null, user:null, profile:null },
  tab:'sell',
  cart:[], // {productId, name, category, qty, unitPrice, unitCost, discount}
  search:'',
  activeCategory:'All',
  expandedCategoryId:null,
  productStockFilter:'all', // 'all' | 'low' — toggled by the filter pills atop the Products page
  historyFilter:{ start:firstOfCurrentMonth(), end:null },
  lastReceipt:null,
  scannerStream:null,
  scannerRAF:null,
};

/* ---------------- storage helpers ---------------- */
// Uses real browser localStorage (works on any real hosted site — Netlify, GitHub Pages, etc.)
// rather than window.storage, which is an API only available inside Claude's own artifact
// preview and does not exist on externally hosted pages.
async function getJSON(key, fallback){
  try{
    const raw = localStorage.getItem(key);
    if(raw !== null) return JSON.parse(raw);
    return fallback;
  }catch(e){ return fallback; }
}
async function setJSON(key, val){
  try{ localStorage.setItem(key, JSON.stringify(val)); }
  catch(e){ console.error('storage set failed', key, e); }
}

// This shop's Supabase project — baked in so the app connects automatically on first load,
// with no manual "Cloud sync" setup step required for anyone opening it for the first time.
const DEFAULT_CLOUD_CONFIG = {
  url: 'https://ofniihohppitzvhxzirt.supabase.co',
  key: 'sb_publishable_v1lCfzvB0PFKzRG4ulAiAA_3Go90r8i',
};

async function loadAll(){
  let cloudCfg = await getJSON('oyes:cloud_config', null);
  if((!cloudCfg || !cloudCfg.url || !cloudCfg.key) && DEFAULT_CLOUD_CONFIG.url && DEFAULT_CLOUD_CONFIG.key){
    cloudCfg = DEFAULT_CLOUD_CONFIG;
    await setJSON('oyes:cloud_config', cloudCfg); // persist so it's explicit from here on
  }
  if(cloudCfg && cloudCfg.url && cloudCfg.key){
    initCloudClient(cloudCfg.url, cloudCfg.key);
    // If this device has a persisted session (from a previous successful login), restore it
    // straight away instead of always showing the login screen — this is what lets the app
    // open directly into the store with no network at all, as long as it's been logged into
    // at least once before while online.
    try{
      const { data } = await state.cloud.client.auth.getSession();
      if(data && data.session){
        state.auth.session = data.session;
        state.auth.user = data.session.user;
        const cachedAuth = await getJSON('oyes:cached_auth', null);
        if(cachedAuth && cachedAuth.id === data.session.user.id) state.auth.profile = cachedAuth.profile;
        // Load whatever this device already has locally FIRST — it may include edits made
        // while offline (a new product, a stock change, a new variant…) that never made it
        // to the cloud last time the app was open. Mark connected + flush those up BEFORE
        // pulling, so the pull below reflects them instead of silently overwriting them with
        // the stale server copy. Doing the pull first (the old order) is what used to make an
        // offline-added variant vanish the moment the device reconnected.
        await loadLocalCacheIntoState();
        state.cloud.connected = true;
        await flushAllPending();
        const pulled = await pullFromCloud().catch(()=>false);
        if(pulled){
          setJSON('oyes:products', state.products); setJSON('oyes:categories', state.categories);
          setJSON('oyes:transactions', state.transactions); setJSON('oyes:settings', state.settings);
          setJSON('oyes:customers', state.customers); setJSON('oyes:customerLedger', state.customerLedger);
          setOfflineBanner(false);
          cacheAuthProfile();
        } else {
          // Offline (or the pull otherwise failed) — keep showing what was just loaded locally
          // above, rather than blocking the till from opening at all.
          setOfflineBanner(true);
        }
      }
    }catch(e){ console.error('session restore failed', e); }
    state.ready = true; // login screen will show if no session was restored above
    return;
  }
  const photos = await getJSON('oyes:photos', null);
  const legacyPhotos = photos || {}; // one-time source for migrating old product-level photos onto variants
  await loadLocalCacheIntoState();
  state.products = state.products.map(p=>ensureVariants(p, legacyPhotos[p.id]));
  await setJSON('oyes:products', state.products);
  await setJSON('oyes:categories', state.categories);
  await setJSON('oyes:settings', state.settings);
  state.ready = true;
}
function saveProducts(){
  setJSON('oyes:products', state.products);
  if(state.cloud.connected) syncUpsertOrQueue('products');
}
function saveCategories(){
  setJSON('oyes:categories', state.categories);
  if(state.cloud.connected) syncUpsertOrQueue('categories');
}
function saveTransactions(){ setJSON('oyes:transactions', state.transactions); }
function saveStockLog(){ setJSON('oyes:stockLog', state.stockLog); }
function saveCustomers(){
  setJSON('oyes:customers', state.customers);
  if(state.cloud.connected) syncUpsertOrQueue('customers');
}
function saveCustomerLedger(){ setJSON('oyes:customerLedger', state.customerLedger); }
async function saveNewLedgerEntryCloud(entry){
  if(!state.cloud.connected) return;
  if(!navigator.onLine){ await addPendingSync({type:'ledger', entry}); updateSyncBanner(); return; }
  try{
    await cloudUpsert('oyes_customer_ledger', [ledgerEntryToRow(entry)]);
    updateSyncBanner();
  }catch(e){
    noteSyncError('Customer ledger', e);
    await addPendingSync({type:'ledger', entry});
    toast(syncFailMessage('Payment'), 5200);
    updateSyncBanner();
  }
}
// Writes one sale to the cloud: header row first (line items reference it), then its items.
// Items are cleared first so a retry after a half-finished attempt can never double-count them.
async function pushTransaction(txn){
  await cloudUpsert('oyes_transactions', [transactionHeaderToRow(txn)]);
  try{ await state.cloud.client.from('oyes_transaction_items').delete().eq('transaction_id', txn.id); }catch(e){}
  await cloudUpsert('oyes_transaction_items', transactionItemRows(txn));
}
async function saveNewTransactionCloud(txn){
  if(!state.cloud.connected) return;
  if(!navigator.onLine){ await addPendingSync({type:'transaction', txn}); updateSyncBanner(); return; }
  try{
    await pushTransaction(txn);
    updateSyncBanner();
  }catch(e){
    noteSyncError('Sale', e);
    await addPendingSync({type:'transaction', txn});
    toast(syncFailMessage('Sale'), 5200);
    updateSyncBanner();
  }
}
function saveSettings(){
  setJSON('oyes:settings', state.settings);
  if(state.cloud.connected) syncUpsertOrQueue('settings');
}

/* ---------------- Supabase cloud sync ---------------- */
function productToRow(p){
  return { id:p.id, name:p.name, category:p.category, cost:p.cost, price:p.price, stock:p.stock,
    barcode:p.barcode||p.id, variants: p.variants||[], photo: (p.variants&&p.variants[0]&&p.variants[0].photo)||null, updated_at: p.updatedAt||new Date().toISOString() };
}
function rowToProduct(r){
  return { id:r.id, name:r.name, category:r.category, cost:Number(r.cost)||0, price:Number(r.price)||0,
    stock:Number(r.stock)||0, barcode:r.barcode||r.id, variants: Array.isArray(r.variants) ? r.variants : null,
    updatedAt:r.updated_at, profit: r.profit!=null ? Number(r.profit) : unitProfit(r.cost, r.price) };
}
function categoryToRow(c){ return { id:c.id, name:c.name, color:c.color }; }
function rowToCategory(r){ return { id:r.id, name:r.name, color:r.color }; }
// transaction header (one row per sale) — no item detail here, that lives in oyes_transaction_items
function transactionHeaderToRow(t){
  return { id:t.id, type:t.type, payment:t.payment, txn_date:t.date, subtotal:t.subtotal, discount:t.discount, total:t.total,
    customer_id:t.customerId||null, customer_name:t.customerName||null, customer_phone:t.customerPhone||null,
    amount_paid: t.amountPaid!=null ? t.amountPaid : t.total, balance_due: t.balanceDue||0,
    user_name:t.userName||null, user_email:t.userEmail||null };
}
function rowToTransactionHeader(r){
  return { id:r.id, type:r.type, payment:r.payment, date:r.txn_date, subtotal:Number(r.subtotal)||0, discount:Number(r.discount)||0, total:Number(r.total)||0,
    customerId:r.customer_id||null, customerName:r.customer_name||null, customerPhone:r.customer_phone||null,
    amountPaid: r.amount_paid!=null ? Number(r.amount_paid) : Number(r.total)||0, balanceDue: Number(r.balance_due)||0,
    userName:r.user_name||'', userEmail:r.user_email||'', items:[] };
}
// line-item fact rows (one row per product sold) — transaction_id repeats for multi-item sales
function transactionItemRows(t){
  return t.items.map(it=>({
    transaction_id: t.id,
    product_id: it.productId,
    product_name: it.name,
    qty: it.qty,
    unit_price: it.unitPrice,
    unit_cost: it.unitCost,
    discount: it.discount || 0,
    line_total: it.lineTotal,
  }));
}
function rowToTransactionItem(r){
  return { productId:r.product_id, name:r.product_name, qty:Number(r.qty)||0, unitPrice:Number(r.unit_price)||0,
    unitCost:Number(r.unit_cost)||0, discount:Number(r.discount)||0, lineTotal:Number(r.line_total)||0 };
}
function customerToRow(c){
  return { id:c.id, name:c.name, phone:c.phone||'', balance:c.balance||0, created_at:c.createdAt, updated_at:c.updatedAt||new Date().toISOString() };
}
function rowToCustomer(r){
  return { id:r.id, name:r.name, phone:r.phone||'', balance:Number(r.balance)||0, createdAt:r.created_at, updatedAt:r.updated_at };
}
function ledgerEntryToRow(e){
  return { id:e.id, customer_id:e.customerId, type:e.type, txn_id:e.txnId||null, amount:e.amount, paid:e.paid,
    balance_after:e.balanceAfter, pay_method:e.payMethod||null, note:e.note||null, entry_date:e.date, user_name:e.userName||null };
}
function rowToLedgerEntry(r){
  return { id:r.id, customerId:r.customer_id, type:r.type, txnId:r.txn_id, amount:Number(r.amount)||0, paid:Number(r.paid)||0,
    balanceAfter:Number(r.balance_after)||0, payMethod:r.pay_method, note:r.note, date:r.entry_date, userName:r.user_name };
}
function settingsToRow(){
  return { id:'main', shop_name:state.settings.shopName, shop_sub:state.settings.shopSub, address:state.settings.address, currency:state.settings.currency, txn_seq:state.settings.txnSeq, logo:state.settings.logo||null };
}
function rowToSettings(r){
  return { shopName:r.shop_name, shopSub:r.shop_sub, address:r.address, currency:r.currency, txnSeq:r.txn_seq, logo:r.logo||'' };
}

async function syncUpsert(table, rows){
  if(!state.cloud.client || !rows.length) return;
  try{ const {error} = await state.cloud.client.from(table).upsert(rows); if(error) throw error; }
  catch(e){ console.error('cloud upsert failed', table, e); toast('Saved locally — cloud sync failed'); }
}
async function syncDelete(table, id){
  if(!state.cloud.client) return;
  if(!navigator.onLine){ addPendingSync({type:'delete', table, id}); return; }
  try{
    const {error} = await state.cloud.client.from(table).delete().eq('id', id);
    if(error) throw error;
  }catch(e){
    console.error('cloud delete failed', table, e);
    addPendingSync({type:'delete', table, id});
    toast('Deleted locally — will sync when back online');
  }
}

/* ---------------- offline-safe table sync (products/categories/customers/settings) ----------------
   These tables are always upserted as a full snapshot of the current local array (not a diff),
   so unlike transactions/ledger there's nothing per-change to queue — we just need to remember
   THAT a table has unsynced local edits ("dirty"), and re-push its current contents once we're
   back online, BEFORE pulling from the cloud again. Skipping that ordering is what used to let a
   cloud pull silently overwrite an offline edit (e.g. a variant added while offline) with the
   stale server copy the moment connectivity returned. */
const DIRTY_TABLES = {
  products:   { table:'oyes_products',   getRows: ()=> state.products.map(productToRow) },
  categories: { table:'oyes_categories', getRows: ()=> state.categories.map(categoryToRow) },
  customers:  { table:'oyes_customers',  getRows: ()=> state.customers.map(customerToRow) },
  settings:   { table:'oyes_settings',   getRows: ()=> [settingsToRow()] },
};
async function getDirtyFlags(){ return await getJSON('oyes:dirty_flags', {}); }
async function markDirty(key){
  const d = await getDirtyFlags();
  if(!d[key]){ d[key] = true; await setJSON('oyes:dirty_flags', d); }
}
async function clearDirty(key){
  const d = await getDirtyFlags();
  if(d[key]){ delete d[key]; await setJSON('oyes:dirty_flags', d); }
}
// Called right after a local save (products/categories/customers/settings). Tries to push
// immediately; if that's not possible (offline) or it fails (flaky connection), the table is
// just marked dirty so flushDirtyTables() can retry it once we're back online — the local save
// itself (setJSON, already done by the caller) is never blocked or lost either way.
async function syncUpsertOrQueue(key){
  const def = DIRTY_TABLES[key];
  if(!state.cloud.client || !def) return;
  if(!navigator.onLine){ await markDirty(key); updateSyncBanner(); return; }
  try{
    await pushDirtyTable(key);
    await clearDirty(key);
  }catch(e){
    noteSyncError(def.table, e);
    await markDirty(key);
    toast(syncFailMessage('Change'), 5200);
  }
  updateSyncBanner();
}
// Pushes one table's current local contents to the cloud.
// Cashiers are special-cased for customers: the database only lets ADMINS insert new customer
// rows, and Postgres checks that insert rule even for an upsert that would only update an
// existing row — so a cashier's upsert (every credit sale / payment changes a balance) was
// being rejected outright. Cashiers update existing customer rows one by one instead.
async function pushDirtyTable(key){
  const def = DIRTY_TABLES[key];
  const rows = def.getRows();
  if(!rows.length) return;
  if(key === 'customers' && !isAdmin()){
    for(const r of rows){
      if(state.custPushed[r.id] === r.updated_at) continue;
      const { error } = await state.cloud.client.from(def.table)
        .update({ name:r.name, phone:r.phone, balance:r.balance, updated_at:r.updated_at }).eq('id', r.id);
      if(error) throw error;
      state.custPushed[r.id] = r.updated_at;
    }
    return;
  }
  await cloudUpsert(def.table, rows);
}
// Pushes every table with unsynced local edits up to the cloud. Always run this BEFORE
// pullFromCloud() whenever reconnecting, so a pull reflects (rather than erases) local changes.
async function flushDirtyTables(){
  if(!state.cloud.connected || !state.cloud.client || !navigator.onLine) return;
  const d = await getDirtyFlags();
  for(const key of Object.keys(d)){
    const def = DIRTY_TABLES[key];
    if(!d[key] || !def) continue;
    try{
      await pushDirtyTable(key);
      await clearDirty(key);
    }catch(e){ noteSyncError(def.table, e); }
  }
}

/* ---------------- sync health: real error messages, auto-retry, "not synced" banner ----------------
   Before this, ANY failed cloud write showed "Saved locally — will sync when back online" even
   with a perfectly good connection, hid the real reason, and only retried on the next app open.
   Meanwhile the next cloud pull replaced the on-screen data with the server's copy — which
   doesn't yet contain the unsynced sale — so today's KPIs dropped to 0 on refresh. */
state.sync = { lastError:'', lastErrorAt:'', missingCols:{}, flushing:false };
state.custPushed = {};

const MIGRATION_SQL = `-- Run once in Supabase → SQL Editor (safe to re-run)
alter table oyes_transactions add column if not exists customer_id text;
alter table oyes_transactions add column if not exists customer_name text;
alter table oyes_transactions add column if not exists customer_phone text;
alter table oyes_transactions add column if not exists amount_paid numeric;
alter table oyes_transactions add column if not exists balance_due numeric default 0;
alter table oyes_transactions add column if not exists user_name text;
alter table oyes_transactions add column if not exists user_email text;
alter table oyes_customer_ledger add column if not exists user_name text;
notify pgrst, 'reload schema';`;

function describeSyncError(e){
  if(!e) return 'Unknown error';
  const msg = e.message || String(e);
  return (e.code ? '['+e.code+'] ' : '') + msg;
}
function noteSyncError(ctx, e){
  console.error('[sync]', ctx, e);
  state.sync.lastError = ctx + ': ' + describeSyncError(e);
  state.sync.lastErrorAt = new Date().toISOString();
  setJSON('oyes:last_sync_error', { msg:state.sync.lastError, at:state.sync.lastErrorAt });
}
function clearSyncError(){
  if(!state.sync.lastError) return;
  state.sync.lastError = ''; state.sync.lastErrorAt = '';
  setJSON('oyes:last_sync_error', null);
}
function syncFailMessage(what){
  return navigator.onLine
    ? what + ' saved on this device, but cloud sync failed — tap the red bar at the top for details'
    : 'Saved locally — will sync when back online';
}
function isAuthError(e){
  if(!e) return false;
  const m = e.message || '';
  return e.status === 401 || e.code === 'PGRST301' || e.code === '42501' || /jwt|row-level security|permission denied|not authorized/i.test(m);
}
// The one place every cloud write goes through. Two self-repairs:
//  1. "Could not find the 'x' column" (the shop's database is missing a newer column): drop just
//     that field and retry, so the sale still reaches the cloud instead of being stuck forever.
//     The banner then tells the user to run the migration SQL to add the column.
//  2. Expired/invalid login token: refresh the session once and retry.
async function cloudUpsert(table, rows){
  const client = state.cloud.client;
  let stripped = state.sync.missingCols[table] || [];
  let refreshed = false;
  for(let attempt=0; attempt<10; attempt++){
    const payload = stripped.length ? rows.map(r=>{ const c={...r}; stripped.forEach(k=>delete c[k]); return c; }) : rows;
    const { error } = await client.from(table).upsert(payload);
    if(!error) return;
    const m = /Could not find the '([^']+)' column/i.exec(error.message || '');
    if(m && !stripped.includes(m[1])){
      stripped = [...stripped, m[1]];
      state.sync.missingCols[table] = stripped;
      noteSyncError(table, error); // remembered so the banner/details can explain it
      continue;
    }
    if(!refreshed && isAuthError(error)){
      refreshed = true;
      try{ await state.cloud.client.auth.refreshSession(); }catch(e){}
      continue;
    }
    throw error;
  }
  throw new Error('Too many retries writing to ' + table);
}

async function updateSyncBanner(){
  const el = document.getElementById('syncBanner');
  if(!el) return;
  if(!state.cloud.connected || !navigator.onLine){ el.classList.add('hidden'); return; }
  const q = await getPendingSync();
  const d = await getDirtyFlags();
  const n = q.length + Object.keys(d).length;
  const missing = Object.values(state.sync.missingCols).some(c=>c.length);
  if(!n && !missing){ el.classList.add('hidden'); return; }
  el.textContent = n
    ? `⚠ ${n} change${n>1?'s':''} not synced to the cloud yet — tap for details`
    : '⚠ Your database is missing some columns — tap for the fix';
  el.classList.remove('hidden');
}

async function retrySyncNow(){
  if(!state.cloud.connected || !state.cloud.client){ toast('Not signed in to the cloud'); return false; }
  if(!navigator.onLine){ toast('No internet connection right now'); return false; }
  toast('Syncing…');
  await flushAllPending();
  const q = await getPendingSync();
  const d = await getDirtyFlags();
  const clean = !q.length && !Object.keys(d).length;
  if(clean){
    const pulled = await pullFromCloud().catch(()=>false);
    if(pulled){
      setJSON('oyes:products', state.products); setJSON('oyes:categories', state.categories);
      setJSON('oyes:transactions', state.transactions); setJSON('oyes:settings', state.settings);
      setJSON('oyes:customers', state.customers); setJSON('oyes:customerLedger', state.customerLedger);
      setOfflineBanner(false);
      renderActiveTab(); syncTopbar();
    }
    toast('Everything is synced');
  } else {
    toast('Still could not sync — see details', 4200);
  }
  updateSyncBanner();
  return clean;
}

async function openSyncDetailsModal(){
  const root = document.getElementById('modalRoot');
  const q = await getPendingSync();
  const d = await getDirtyFlags();
  const sales = q.filter(i=>i.type==='transaction').length;
  const ledger = q.filter(i=>i.type==='ledger').length;
  const dels = q.filter(i=>i.type==='delete').length;
  const tables = Object.keys(d);
  const missing = Object.entries(state.sync.missingCols).filter(([t,c])=>c.length);
  const err = state.sync.lastError;
  let hint = '';
  if(missing.length){
    hint = `Your Supabase database is missing: ${missing.map(([t,c])=>t+' → '+c.join(', ')).join('; ')}. Sales are still being saved without those fields. Copy the SQL below, run it once in Supabase → SQL Editor, then tap Retry.`;
  } else if(/row-level security|jwt|42501|401|PGRST301|permission denied/i.test(err)){
    hint = 'The database refused the write (login expired or not allowed). Log out and log back in while online, then tap Retry.';
  } else if(/fetch|network|failed to fetch|timeout/i.test(err)){
    hint = 'The database could not be reached. Check the connection (or that the Supabase project is not paused), then tap Retry.';
  }
  const parts = [];
  if(sales) parts.push(`${sales} sale${sales>1?'s':''}`);
  if(ledger) parts.push(`${ledger} customer payment/credit entr${ledger>1?'ies':'y'}`);
  if(dels) parts.push(`${dels} deletion${dels>1?'s':''}`);
  if(tables.length) parts.push('unsynced edits to: ' + tables.join(', '));
  root.innerHTML = `
    <div class="modal-back" id="mbSync">
      <div class="modal-sheet">
        <div class="modal-handle"></div>
        <div class="section-title" style="padding-top:0">Cloud sync status</div>
        <div class="field field-hint" style="padding-top:0">${parts.length ? 'Waiting to sync: ' + esc(parts.join(' · ')) + '. Nothing is lost — it is all safe on this device and retried automatically.' : 'Nothing is waiting to sync.'}</div>
        ${err ? `<div class="field"><label>Last error from the database</label><div style="font-family:var(--font-mono);font-size:11.5px;background:var(--red-tint);color:var(--red);padding:9px 10px;border-radius:10px;word-break:break-word">${esc(err)}</div></div>` : ''}
        ${hint ? `<div class="field field-hint" style="padding-top:0">${esc(hint)}</div>` : ''}
        ${missing.length ? `<div class="field"><textarea readonly id="syncSqlBox" style="width:100%;height:150px;font-family:var(--font-mono);font-size:11px;border:1px solid var(--line);border-radius:10px;padding:8px">${esc(MIGRATION_SQL)}</textarea><button class="btn btn-ghost" id="syncCopySql" style="margin-top:8px">Copy SQL</button></div>` : ''}
        <div class="field"><div class="btn-row">
          <button class="btn btn-ghost" id="syncClose">Close</button>
          <button class="btn btn-primary" id="syncRetry">Retry now</button>
        </div></div>
      </div>
    </div>`;
  document.getElementById('mbSync').addEventListener('click', e=>{ if(e.target.id==='mbSync') root.innerHTML=''; });
  document.getElementById('syncClose').onclick = ()=>root.innerHTML='';
  const copyBtn = document.getElementById('syncCopySql');
  if(copyBtn) copyBtn.onclick = async ()=>{
    try{ await navigator.clipboard.writeText(MIGRATION_SQL); toast('SQL copied'); }
    catch(e){ const b=document.getElementById('syncSqlBox'); b.select(); document.execCommand && document.execCommand('copy'); toast('SQL copied'); }
  };
  document.getElementById('syncRetry').onclick = async ()=>{
    const btn = document.getElementById('syncRetry'); btn.disabled = true; btn.textContent = 'Syncing…';
    await retrySyncNow();
    openSyncDetailsModal();
  };
}

// Retry automatically instead of waiting for the next app open: every 30s while anything is
// waiting, and immediately whenever the app comes back to the foreground.
setInterval(async ()=>{
  if(document.hidden || !state.cloud.connected || !navigator.onLine) return;
  const q = await getPendingSync(); const d = await getDirtyFlags();
  if(q.length || Object.keys(d).length) flushAllPending();
}, 30000);
document.addEventListener('visibilitychange', ()=>{
  if(!document.hidden && state.cloud.connected && navigator.onLine) flushAllPending();
});
document.addEventListener('click', (e)=>{
  if(e.target && e.target.id === 'syncBanner') openSyncDetailsModal();
});

function initCloudClient(url, key){
  // persistSession:true — the signed-in session is kept in localStorage so the app can restore
  // it (and thus open straight into the store) with no network round trip. This is what makes
  // offline use possible: without a persisted session, every app open would need a fresh
  // signInWithPassword call, which fails the moment there's no connection. Logging out still
  // clears it (see logout()), so a deliberate log-out still requires network to log back in.
  state.cloud.client = window.supabase.createClient(url, key, { auth:{ persistSession:true, autoRefreshToken:true } });
  state.cloud.url = url; state.cloud.key = key; state.cloud.configured = true;
}

/* ---------------- offline support ---------------- */
// Tracks whether we're currently showing cached (not freshly-pulled) data because the last
// cloud pull failed — used to show the "Offline" banner and to know when to retry.
state.offline = false;

function setOfflineBanner(isOffline){
  state.offline = isOffline;
  const el = document.getElementById('offlineBanner');
  if(el) el.classList.toggle('hidden', !isOffline);
}

// Remembers who's allowed in, independent of the live Supabase session object, so the login
// screen (and the "who am I" chip) still has something to show immediately while offline.
async function cacheAuthProfile(){
  if(!state.auth.user) return;
  await setJSON('oyes:cached_auth', { id: state.auth.user.id, email: state.auth.user.email, profile: state.auth.profile });
}

// Any transaction/ledger write that failed to reach the cloud (because we were offline) waits
// here until connectivity returns, so a sale made offline still ends up in Supabase eventually
// instead of only ever living in this one device's localStorage.
async function getPendingSync(){ return await getJSON('oyes:pending_sync', []); }
async function addPendingSync(item){
  const q = await getPendingSync();
  q.push(item);
  await setJSON('oyes:pending_sync', q);
}
async function flushPendingSync(){
  if(!state.cloud.connected || !state.cloud.client || !navigator.onLine) return;
  if(state.sync.flushing) return;
  state.sync.flushing = true;
  try{
    const q = await getPendingSync();
    if(!q.length) return;
    const remaining = [];
    for(const item of q){
      try{
        if(item.type === 'transaction'){
          await pushTransaction(item.txn);
        } else if(item.type === 'ledger'){
          await cloudUpsert('oyes_customer_ledger', [ledgerEntryToRow(item.entry)]);
        } else if(item.type === 'delete'){
          const r = await state.cloud.client.from(item.table).delete().eq('id', item.id);
          if(r.error) throw r.error;
        }
      }catch(e){ noteSyncError(item.type, e); remaining.push(item); }
    }
    // anything queued while this flush was running must survive — re-read before overwriting
    const nowQ = await getPendingSync();
    const added = nowQ.slice(q.length);
    await setJSON('oyes:pending_sync', remaining.concat(added));
    if(remaining.length < q.length){
      toast(remaining.length ? `Synced some sales — ${remaining.length} still pending` : 'All offline sales synced to the cloud');
    }
  } finally {
    state.sync.flushing = false;
  }
}
// Pushes everything unsynced up to the cloud: queued sales/payments/deletes AND any dirty
// products/categories/customers/settings snapshots. Always call this before pullFromCloud()
// when reconnecting so the pull can't clobber local edits made while offline.
async function flushAllPending(){
  await flushDirtyTables();
  await flushPendingSync();
  const q = await getPendingSync();
  const d = await getDirtyFlags();
  if(!q.length && !Object.keys(d).length && !Object.values(state.sync.missingCols).some(c=>c.length)) clearSyncError();
  updateSyncBanner();
}
// When connectivity comes back: flush anything queued, then pull fresh data so this device
// is showing the latest shared stock/prices/history again, and clear the offline banner.
window.addEventListener('online', async ()=>{
  if(!state.cloud.connected) return;
  await flushAllPending();
  const pulled = await pullFromCloud().catch(()=>false);
  if(pulled){
    setOfflineBanner(false);
    setJSON('oyes:products', state.products); setJSON('oyes:categories', state.categories);
    setJSON('oyes:transactions', state.transactions); setJSON('oyes:settings', state.settings);
    setJSON('oyes:customers', state.customers); setJSON('oyes:customerLedger', state.customerLedger);
    if(state.ready){ renderActiveTab(); syncTopbar(); }
  }
});
window.addEventListener('offline', ()=>{ if(state.cloud.connected) setOfflineBanner(true); });

async function attemptLogin(email, password){
  if(!state.cloud.client) return {ok:false, error:'Cloud not configured'};
  try{
    const { data, error } = await state.cloud.client.auth.signInWithPassword({ email, password });
    if(error) throw error;
    state.auth.session = data.session; state.auth.user = data.user;
    const { data:profile } = await state.cloud.client.from('oyes_profiles').select('*').eq('id', data.user.id).maybeSingle();
    state.auth.profile = profile || { full_name: data.user.email, role:'staff' };
    state.cloud.connected = true;
    await flushAllPending();
    const pulled = await pullFromCloud();
    if(!pulled){ state.cloud.connected = false; return {ok:false, error:'Logged in, but could not load shop data — check your tables are set up (see setup SQL in Settings after logging in fails).'}; }
    setJSON('oyes:products', state.products);
    setJSON('oyes:categories', state.categories);
    setJSON('oyes:transactions', state.transactions);
    setJSON('oyes:settings', state.settings);
    setJSON('oyes:customers', state.customers);
    setJSON('oyes:customerLedger', state.customerLedger);
    cacheAuthProfile();
    return {ok:true};
  }catch(e){
    // A network failure (as opposed to wrong credentials) — if this exact device has logged in
    // successfully before, let the entered email through on the cached data instead of blocking
    // the till from opening just because the connection is down.
    const isNetworkError = !navigator.onLine || (e && /fetch|network/i.test(e.message||''));
    if(isNetworkError){
      const cached = await getJSON('oyes:cached_auth', null);
      if(cached && cached.email && cached.email.toLowerCase() === email.trim().toLowerCase()){
        state.auth.user = { id: cached.id, email: cached.email };
        state.auth.profile = cached.profile;
        await loadLocalCacheIntoState();
        state.cloud.connected = true;
        setOfflineBanner(true);
        return {ok:true};
      }
      return {ok:false, error:'No internet connection, and this device has no saved login yet. Connect once and log in successfully — after that, this app works offline automatically.'};
    }
    return {ok:false, error:(e && e.message) ? e.message : 'Login failed'};
  }
}

// Loads whatever was last saved to this device's localStorage (from a previous successful
// cloud pull) straight into state — used both when there's no cloud configured at all, and as
// the offline fallback when a cloud pull can't reach the network.
async function loadLocalCacheIntoState(){
  const [products, categories, transactions, settings, stockLog, customers, customerLedger] = await Promise.all([
    getJSON('oyes:products', null),
    getJSON('oyes:categories', null),
    getJSON('oyes:transactions', null),
    getJSON('oyes:settings', null),
    getJSON('oyes:stockLog', null),
    getJSON('oyes:customers', null),
    getJSON('oyes:customerLedger', null),
  ]);
  state.products = (products || SEED_PRODUCTS.map(p=>({...p, barcode:p.id, updatedAt:new Date().toISOString()}))).map(p=>ensureVariants(p));
  state.categories = categories || buildSeedCategories(state.products);
  state.transactions = transactions || [];
  state.stockLog = stockLog || [];
  state.customers = customers || [];
  state.customerLedger = customerLedger || [];
  state.settings = settings ? {...state.settings, ...settings} : state.settings;
}

async function logout(){
  try{ if(state.cloud.client) await state.cloud.client.auth.signOut(); }catch(e){}
  // Clearing the cached-auth record means a deliberate log-out really does require a fresh,
  // network-verified login afterwards — offline re-entry only works for a session that's still
  // open (the app was just closed/reloaded), not one someone explicitly signed out of.
  try{ localStorage.removeItem('oyes:cached_auth'); }catch(e){}
  state.auth = { session:null, user:null, profile:null };
  state.cloud.connected = false;
  setOfflineBanner(false);
  state.cart = [];
  document.getElementById('bottomnav').classList.add('hidden');
  document.getElementById('userChipBtn').classList.add('hidden');
  closeOverlay();
  document.getElementById('modalRoot').innerHTML = '';
  renderLogin();
}

async function pullFromCloud(){
  const c = state.cloud.client;
  try{
    // Without a valid login the database silently returns EMPTY tables (row-level security) —
    // which used to look like a successful pull of "no products, no sales". Treat it as a failure.
    const { data:sessData } = await c.auth.getSession();
    if(!sessData || !sessData.session){ console.warn('cloud pull skipped: no active session'); return false; }
    // Anything that hasn't reached the cloud yet must NOT be wiped by this pull.
    const dirty = await getDirtyFlags();
    const pendingQ = await getPendingSync();
    const [prod, cat, txnHead, txnItems, set, cust, ledger] = await Promise.all([
      c.from('oyes_products').select('*'),
      c.from('oyes_categories').select('*'),
      c.from('oyes_transactions').select('*').order('txn_date', {ascending:false}),
      c.from('oyes_transaction_items').select('*').order('id', {ascending:true}),
      c.from('oyes_settings').select('*').eq('id','main').maybeSingle(),
      c.from('oyes_customers').select('*'),
      c.from('oyes_customer_ledger').select('*').order('entry_date', {ascending:false}),
    ]);
    if(prod.error || cat.error || txnHead.error || txnItems.error) throw (prod.error||cat.error||txnHead.error||txnItems.error);
    // customers/ledger tables are optional (older shops may not have run the newer setup SQL yet)
    // — don't fail the whole sync if they're missing, just fall back to whatever's cached locally.
    if(!cust.error){
      state.custPushed = {};
      (cust.data||[]).forEach(r=>{ state.custPushed[r.id] = r.updated_at; });
      if(!dirty.customers) state.customers = (cust.data||[]).map(rowToCustomer);
    }
    if(!ledger.error){
      const rows = (ledger.data||[]).map(rowToLedgerEntry);
      const have = new Set(rows.map(r=>r.id));
      pendingQ.forEach(i=>{ if(i.type==='ledger' && i.entry && !have.has(i.entry.id)) rows.unshift(i.entry); });
      state.customerLedger = rows;
    }

    if(dirty.products){
      // local product/stock edits are still waiting to upload — keep them
    } else if(prod.data && prod.data.length){
      state.products = prod.data.map(r=>ensureVariants(rowToProduct(r), r.photo));
    } else {
      // empty cloud tables -> seed from workbook defaults and push up
      state.products = SEED_PRODUCTS.map(p=>({...p, barcode:p.id, updatedAt:new Date().toISOString()})).map(p=>ensureVariants(p));
      await syncUpsertForce('oyes_products', state.products.map(productToRow));
    }
    if(dirty.categories){
      // keep local
    } else if(cat.data && cat.data.length){
      state.categories = cat.data.map(rowToCategory);
    } else {
      state.categories = buildSeedCategories(state.products);
      await syncUpsertForce('oyes_categories', state.categories.map(categoryToRow));
    }
    // join line-items (fact table) onto their transaction header by transaction_id
    const itemsByTxn = {};
    (txnItems.data||[]).forEach(r=>{
      (itemsByTxn[r.transaction_id] = itemsByTxn[r.transaction_id] || []).push(rowToTransactionItem(r));
    });
    const txns = (txnHead.data||[]).map(r=>{
      const t = rowToTransactionHeader(r);
      t.items = itemsByTxn[t.id] || [];
      return t;
    });
    // sales still waiting in the upload queue aren't in the cloud yet — keep them in the list
    // (this is what made today's KPIs read 0 after a refresh)
    const haveTxn = new Set(txns.map(t=>t.id));
    pendingQ.forEach(i=>{ if(i.type==='transaction' && i.txn && !haveTxn.has(i.txn.id)){ txns.push(i.txn); haveTxn.add(i.txn.id); } });
    txns.sort((a,b)=> new Date(b.date) - new Date(a.date));
    state.transactions = txns;
    if(set.data){
      if(!dirty.settings) state.settings = {...state.settings, ...rowToSettings(set.data)};
    } else {
      await syncUpsertForce('oyes_settings', [settingsToRow()]);
    }
    return true;
  }catch(e){
    console.error('cloud pull failed', e);
    return false;
  }
}
// used only during initial seed push, before state.cloud.connected is true
async function syncUpsertForce(table, rows){
  if(!state.cloud.client || !rows.length) return;
  try{ await state.cloud.client.from(table).upsert(rows); }catch(e){ console.error('seed push failed', table, e); }
}

const CLOUD_SETUP_SQL = `create table oyes_products (
  id text primary key,
  name text not null,
  category text,
  cost numeric default 0,
  price numeric default 0,
  profit numeric generated always as (price - cost) stored,
  stock integer default 0,
  barcode text,
  variants jsonb default '[]'::jsonb,
  photo text,
  updated_at timestamptz default now()
);

create table oyes_categories (
  id text primary key,
  name text not null,
  color text
);

create table oyes_transactions (
  id text primary key,
  type text,
  payment text,
  txn_date timestamptz,
  subtotal numeric,
  discount numeric,
  total numeric,
  customer_id text,
  customer_name text,
  customer_phone text,
  amount_paid numeric,
  balance_due numeric default 0,
  user_name text, -- the cashier/admin who made this sale (walk-in or credit)
  user_email text
);

-- credit customers, and the ledger of every credit sale & payment against their balance
create table oyes_customers (
  id text primary key,
  name text not null,
  phone text,
  balance numeric default 0,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

create table oyes_customer_ledger (
  id text primary key,
  customer_id text references oyes_customers(id) on delete cascade,
  type text, -- 'sale' or 'payment'
  txn_id text,
  amount numeric,
  paid numeric,
  balance_after numeric,
  pay_method text,
  note text,
  entry_date timestamptz default now(),
  user_name text -- the cashier/admin who made the sale or recorded the payment
);

-- fact table: one row per product sold. transaction_id repeats for multi-item sales.
create table oyes_transaction_items (
  id bigint generated by default as identity primary key,
  transaction_id text references oyes_transactions(id) on delete cascade,
  product_id text,
  product_name text,
  qty integer,
  unit_price numeric,
  unit_cost numeric,
  discount numeric default 0,
  line_total numeric
);

create table oyes_settings (
  id text primary key default 'main',
  shop_name text,
  shop_sub text,
  address text,
  currency text,
  txn_seq integer default 1,
  logo text
);

-- profile info for each login (created automatically when you add a user below)
create table oyes_profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  role text default 'cashier',
  avatar text,
  created_at timestamptz default now()
);

-- auto-create a profile row whenever a new user is added in Authentication > Users
create function handle_new_oyes_user() returns trigger as $$
begin
  insert into public.oyes_profiles (id, full_name, role)
  values (new.id, coalesce(new.raw_user_meta_data->>'full_name', split_part(new.email,'@',1)), 'cashier');
  return new;
end;
$$ language plpgsql security definer;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure handle_new_oyes_user();

alter table oyes_products enable row level security;
alter table oyes_categories enable row level security;
alter table oyes_transactions enable row level security;
alter table oyes_transaction_items enable row level security;
alter table oyes_settings enable row level security;
alter table oyes_profiles enable row level security;
alter table oyes_customers enable row level security;
alter table oyes_customer_ledger enable row level security;

-- any logged-in staff member can read/write the shared shop data
create policy "staff full access" on oyes_products for all to authenticated using (true) with check (true);
create policy "staff full access" on oyes_categories for all to authenticated using (true) with check (true);
create policy "staff full access" on oyes_transactions for all to authenticated using (true) with check (true);
create policy "staff full access" on oyes_transaction_items for all to authenticated using (true) with check (true);
create policy "staff full access" on oyes_settings for all to authenticated using (true) with check (true);
-- customers: any staff member can view/update (balances change on every credit sale & payment,
-- made by cashiers too) but only an admin can register a brand-new customer.
create policy "staff can view customers" on oyes_customers for select to authenticated using (true);
create policy "staff can update customers" on oyes_customers for update to authenticated using (true) with check (true);
create policy "only admins can add customers" on oyes_customers for insert to authenticated
  with check (exists (select 1 from oyes_profiles where id = auth.uid() and role = 'admin'));
create policy "staff full access" on oyes_customer_ledger for all to authenticated using (true) with check (true);

-- staff can see everyone's name/role, but only edit their own profile
create policy "staff read all profiles" on oyes_profiles for select to authenticated using (true);
create policy "staff update own profile" on oyes_profiles for update to authenticated using (auth.uid() = id) with check (auth.uid() = id);

-- lets an admin change ANY staff member's role from inside the app
create function public.get_my_role() returns text
language sql stable security definer set search_path = public as $$
  select role from oyes_profiles where id = auth.uid();
$$;

create policy "admin manage all profiles" on oyes_profiles for update to authenticated
  using (public.get_my_role() = 'admin') with check (public.get_my_role() = 'admin');

-- every new user starts as 'cashier' by default — run this once to make your own
-- account an admin (replace with the email you log in with):
-- update oyes_profiles set role = 'admin' where id = (select id from auth.users where email = 'you@example.com');

-- ALREADY RUNNING THIS APP WITH AN OLDER oyes_transactions TABLE? Run just this part once
-- to add the new credit-customer columns (safe to re-run — IF NOT EXISTS skips them if already there):
-- alter table oyes_transactions add column if not exists customer_id text;
-- alter table oyes_transactions add column if not exists customer_name text;
-- alter table oyes_transactions add column if not exists customer_phone text;
-- alter table oyes_transactions add column if not exists amount_paid numeric;
-- alter table oyes_transactions add column if not exists balance_due numeric default 0;
-- alter table oyes_transactions add column if not exists user_name text;
-- alter table oyes_transactions add column if not exists user_email text;
-- alter table oyes_customer_ledger add column if not exists user_name text;`;

/* Resize + compress an uploaded/captured image before storing it (keeps storage small & fast) */
function readAndResizeImage(file, maxDim=380, quality=0.7){
  return new Promise((resolve, reject)=>{
    if(!file || !file.type.startsWith('image/')){ reject(new Error('Not an image')); return; }
    const reader = new FileReader();
    reader.onload = (e)=>{
      const img = new Image();
      img.onload = ()=>{
        let w = img.width, h = img.height;
        if(w > h){ if(w > maxDim){ h = Math.round(h * maxDim / w); w = maxDim; } }
        else { if(h > maxDim){ w = Math.round(w * maxDim / h); h = maxDim; } }
        const canvas = document.createElement('canvas');
        canvas.width = w; canvas.height = h;
        const ctx = canvas.getContext('2d');
        ctx.fillStyle = '#fff'; ctx.fillRect(0,0,w,h);
        ctx.drawImage(img, 0, 0, w, h);
        resolve(canvas.toDataURL('image/jpeg', quality));
      };
      img.onerror = ()=>reject(new Error('Could not read image'));
      img.src = e.target.result;
    };
    reader.onerror = ()=>reject(new Error('Could not read file'));
    reader.readAsDataURL(file);
  });
}

/* ---------------- utils ---------------- */
function esc(s){ return String(s??'').replace(/[&<>"']/g, c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }
/* Product IDs are stored as "PROD-110" etc. for the database, but that prefix is internal
   plumbing — strip it for anything shown to the person, leaving e.g. just "110". */
function displayId(id){ return String(id??'').replace(/^PROD-?/i, ''); }
function fmtMoney(n){
  n = Math.round((n + Number.EPSILON) * 100) / 100;
  const neg = n < 0; n = Math.abs(n);
  const parts = n.toFixed(2).split('.');
  parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ',');
  const dec = parts[1] === '00' ? '' : '.' + parts[1];
  return (neg?'-':'') + state.settings.currency + parts[0] + dec;
}
/* Profit per unit: sale price minus cost — but if cost hasn't been entered yet (0), treat
   profit as 0 rather than showing the full sale price as "profit", which would be misleading. */
function unitProfit(cost, price){
  cost = Number(cost)||0; price = Number(price)||0;
  return cost === 0 ? 0 : (price - cost);
}

/* ---------------- product variants ---------------- */
// Older saved products (and anything pulled from a cloud table that predates the variants
// column) have no .variants array yet — give them one made from their own flat fields, so
// every product in memory always has at least one variant from here on.
// legacyPhoto: a product-level photo saved by a previous version of the app, carried over as
// this variant's photo so nobody's existing product photos disappear.
function ensureVariants(p, legacyPhoto){
  if(!Array.isArray(p.variants) || !p.variants.length){
    p.variants = [{
      id: uid('VAR-'), name: '',
      cost: Number(p.cost)||0, price: Number(p.price)||0, stock: Number(p.stock)||0,
      barcode: p.barcode || p.id,
      photo: legacyPhoto || null, icon: legacyPhoto ? null : defaultIcon(0),
      lowStockAlert: true, autoUpdateStock: true, preventOOS: false,
      trackExpiry:false, expiryDate:'', addTax:false, taxRate:0, hasNotes:false, internalNotes:'',
    }];
  }
  // Defensively back-fill anything missing on every variant — covers products saved by an
  // in-between version of this app before some of these fields existed.
  p.variants.forEach((v,i)=>{
    if(!v.photo && !v.icon) v.icon = defaultIcon(i);
    if(v.photo===undefined) v.photo = null;
    if(v.lowStockAlert===undefined) v.lowStockAlert = true;
    if(v.autoUpdateStock===undefined) v.autoUpdateStock = true;
    if(v.preventOOS===undefined) v.preventOOS = false;
    if(v.trackExpiry===undefined) v.trackExpiry = false;
    if(v.expiryDate===undefined) v.expiryDate = '';
    if(v.addTax===undefined) v.addTax = false;
    if(v.taxRate===undefined) v.taxRate = 0;
    if(v.hasNotes===undefined) v.hasNotes = false;
    if(v.internalNotes===undefined) v.internalNotes = '';
  });
  syncProductFromVariants(p);
  return p;
}
// Keeps the legacy flat fields (cost/price/stock/barcode) in sync with the variant list, so
// any code that still reads p.price/p.stock directly (search, receipts, low-stock stat) keeps
// working: price/cost mirror the first variant, stock is the sum across all variants.
function syncProductFromVariants(p){
  const vs = p.variants;
  p.stock = vs.reduce((s,v)=>s + (Number(v.stock)||0), 0);
  p.price = vs[0].price;
  p.cost = vs[0].cost;
  p.barcode = vs[0].barcode || p.id;
}
function hasMultiVariants(p){ return Array.isArray(p.variants) && p.variants.length > 1; }
function priceLabel(p){
  if(!hasMultiVariants(p)) return fmtMoney(p.price);
  const prices = p.variants.map(v=>v.price);
  const lo = Math.min(...prices), hi = Math.max(...prices);
  return lo === hi ? fmtMoney(lo) : `${fmtMoney(lo)}–${fmtMoney(hi)}`;
}
// Finds a variant (and its parent product) by barcode, falling back to a bare product-id match
// so old barcodes that were never explicitly set (defaulting to the id) still scan correctly.
function findVariantByBarcode(code){
  code = (code||'').trim();
  if(!code) return null;
  const norm = code.toLowerCase();
  for(const p of state.products){
    for(const v of p.variants){
      if(((v.barcode||p.id)||'').toString().trim().toLowerCase() === norm) return {product:p, variant:v};
    }
  }
  const byId = state.products.find(p=>(p.id||'').toString().trim().toLowerCase() === norm);
  return byId ? {product:byId, variant:byId.variants[0]} : null;
}
// Same duplicate-guarding idea as a single-barcode-per-product check, but checking every variant's
// barcode across the whole catalog (excluding one specific variant, e.g. the one being edited).
function findDuplicateBarcode(barcode, excludeProductId, excludeVariantId){
  const b = (barcode||'').trim().toLowerCase();
  if(!b) return null;
  for(const p of state.products){
    for(const v of p.variants){
      if(p.id===excludeProductId && v.id===excludeVariantId) continue;
      if(((v.barcode||p.id)||'').trim().toLowerCase()===b) return {product:p, variant:v};
    }
  }
  return null;
}
// Internally-generated barcode: starts with 2 (GS1's "restricted circulation / in-store use"
// prefix, so it can never collide with a real manufacturer barcode) plus a valid mod-10 check
// digit, so it passes the scanner's own isValidGtinChecksum() check.
function generateVariantBarcode(){
  let digits = '2';
  for(let i=0;i<11;i++) digits += Math.floor(Math.random()*10);
  const nums = digits.split('').map(Number);
  let sum = 0;
  for(let i=nums.length-1, w=3; i>=0; i--, w=(w===3?1:3)) sum += nums[i]*w;
  const check = (10 - (sum % 10)) % 10;
  return digits + String(check);
}
/* ---------------- variant visuals: a real photo, or a shape+colour fallback icon ---------------- */
// Every variant always has EITHER v.photo (a data URL) OR v.icon ({shape,color}) — never neither,
// so a product is never shown with a blank thumbnail.
const ICON_SHAPES = ['square','circle','diamond','heart','spade','club'];
function defaultIcon(seedIdx){
  return { shape: ICON_SHAPES[(seedIdx||0) % ICON_SHAPES.length], color: CATEGORY_PALETTE[(seedIdx||0) % CATEGORY_PALETTE.length] };
}
function iconShapeSVG(shape, color){
  const paths = {
    square: `<rect x="5" y="5" width="38" height="38" rx="7"/>`,
    circle: `<circle cx="24" cy="24" r="19"/>`,
    diamond: `<rect x="10" y="10" width="28" height="28" rx="4" transform="rotate(45 24 24)"/>`,
    heart: `<path d="M24 41S6 29 6 17a9 9 0 0 1 18-2 9 9 0 0 1 18 2c0 12-18 24-18 24z"/>`,
    spade: `<path d="M24 5C15 16 5 22 5 30a9 9 0 0 0 16 5.5C20 40 18 42 13 44h22c-5-2-7-4-8-8.5A9 9 0 0 0 43 30c0-8-10-14-19-25z"/>`,
    club: `<circle cx="16" cy="19" r="8.5"/><circle cx="32" cy="19" r="8.5"/><circle cx="24" cy="29" r="8.5"/><rect x="20" y="29" width="8" height="13" rx="2"/>`,
  };
  return `<svg viewBox="0 0 48 48" width="100%" height="100%" fill="${color}">${paths[shape]||paths.square}</svg>`;
}
function variantVisualHTML(v){
  if(v && v.photo) return `<img src="${v.photo}" alt="">`;
  const icon = (v && v.icon) || defaultIcon(0);
  return iconShapeSVG(icon.shape, icon.color);
}
/* Variant chips (Products & categories list) are a fixed-size frame — long variant names
   shrink their own font-size to fit instead of growing the chip or truncating with an ellipsis. */
const VARIANT_CHIP_MAX_FONT = 10, VARIANT_CHIP_MIN_FONT = 6.5;
function fitVariantChipText(el){
  let size = VARIANT_CHIP_MAX_FONT;
  el.style.fontSize = size + 'px';
  while(el.scrollWidth > el.clientWidth && size > VARIANT_CHIP_MIN_FONT){
    size -= 0.5;
    el.style.fontSize = size + 'px';
  }
}
function fitAllVariantChips(root){
  (root||document).querySelectorAll('.variant-chip').forEach(fitVariantChipText);
}
function uid(prefix){ return prefix + Math.random().toString(36).slice(2,8).toUpperCase(); }
function nowStamp(){
  const d = new Date();
  const p = n=>String(n).padStart(2,'0');
  return `${d.getFullYear()}${p(d.getMonth()+1)}${p(d.getDate())}${p(d.getHours())}${p(d.getMinutes())}${p(d.getSeconds())}`;
}
function catColor(name){
  const c = state.categories.find(c=>c.name===name);
  return c ? c.color : '#9C9382';
}
function stockClass(stock){
  if(stock<=0) return 'stock-out';
  if(stock<=3) return 'stock-low';
  return 'stock-ok';
}
function stockLabel(stock){
  if(stock<=0) return 'Out';
  return stock + ' left';
}
/* Plain comma-separated number, no currency symbol — used as the variant-bar fallback
   label (product price) when a variant has no name of its own, e.g. 2,500 */
function fmtNumber(n){
  n = Math.round((Number(n)||0) + Number.EPSILON);
  return n.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
}
let toastTimer=null;
function toast(msg, ms){
  const el = document.getElementById('toast');
  el.textContent = msg;
  el.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(()=>el.classList.remove('show'), ms || 2800);
}
function vibrate(ms){ try{ navigator.vibrate && navigator.vibrate(ms); }catch(e){} }

/* Re-runs a render function that rebuilds #screen's innerHTML (which normally destroys/recreates
   the input and steals focus), then restores focus + cursor position to the given input afterward. */
function preserveFocusRender(inputId, renderFn){
  const el = document.getElementById(inputId);
  const hadFocus = el && el === document.activeElement;
  const selStart = el ? el.selectionStart : null;
  const selEnd = el ? el.selectionEnd : null;
  renderFn();
  if(hadFocus){
    const newEl = document.getElementById(inputId);
    if(newEl){
      newEl.focus();
      try{ newEl.setSelectionRange(selStart, selEnd); }catch(e){}
    }
  }
}

/* Lets a horizontally-scrolling row (like the category chips) be dragged left/right with a
   mouse, not just swiped on touch. Tap-to-select is handled here directly (via hit-testing at
   pointerup) rather than relying on the browser's native click, because setPointerCapture
   redirects the click's effective target to the row itself and silently breaks per-chip clicks. */
function enableDragScroll(el, onTap){
  if(!el || el._dragScrollEnabled) return;
  el._dragScrollEnabled = true;
  const drag = { down:false, startX:0, scrollStart:0, moved:false };
  el.addEventListener('pointerdown', e=>{
    drag.down = true; drag.moved = false;
    drag.startX = e.clientX; drag.scrollStart = el.scrollLeft;
    el.classList.add('dragging');
    try{ el.setPointerCapture(e.pointerId); }catch(err){}
  });
  el.addEventListener('pointermove', e=>{
    if(!drag.down) return;
    const dx = e.clientX - drag.startX;
    if(Math.abs(dx) > 4) drag.moved = true;
    el.scrollLeft = drag.scrollStart - dx;
  });
  const endDrag = (e)=>{
    const wasDrag = drag.moved;
    drag.down = false; drag.moved = false;
    el.classList.remove('dragging');
    if(!wasDrag && onTap && e && typeof e.clientX === 'number'){
      const hit = document.elementFromPoint(e.clientX, e.clientY);
      const chip = hit && hit.closest ? hit.closest('.tag-chip') : null;
      if(chip && el.contains(chip)) onTap(chip);
    }
  };
  el.addEventListener('pointerup', endDrag);
  el.addEventListener('pointercancel', ()=>{ drag.down=false; drag.moved=false; el.classList.remove('dragging'); });
  el.addEventListener('pointerleave', ()=>{ drag.down=false; drag.moved=false; el.classList.remove('dragging'); });
}

/* ---------------- icons ---------------- */
const ICO = {
  chevron:`<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="9 18 15 12 9 6"/></svg>`,
  search:`<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>`,
  scan:`<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 7V5a2 2 0 0 1 2-2h2"/><path d="M17 3h2a2 2 0 0 1 2 2v2"/><path d="M21 17v2a2 2 0 0 1-2 2h-2"/><path d="M7 21H5a2 2 0 0 1-2-2v-2"/><line x1="7" y1="12" x2="17" y2="12"/></svg>`,
  plus:`<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>`,
  close:`<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>`,
  back:`<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><line x1="19" y1="12" x2="5" y2="12"/><polyline points="12 19 5 12 12 5"/></svg>`,
  edit:`<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.12 2.12 0 0 1 3 3L12 15l-4 1 1-4Z"/></svg>`,
  trash:`<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>`,
  receipt:`<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 2h16v20l-3-2-3 2-3-2-3 2-3-2-1 2z"/><line x1="8" y1="7" x2="16" y2="7"/><line x1="8" y1="11" x2="16" y2="11"/></svg>`,
  print:`<svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 6 2 18 2 18 9"/><path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"/><rect x="6" y="14" width="12" height="8"/></svg>`,
  cam:`<svg width="30" height="30" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"/><circle cx="12" cy="13" r="4"/></svg>`,
  box:`<svg width="30" height="30" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M21 8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16Z"/><polyline points="3.29 7 12 12 20.71 7"/><line x1="12" y1="22" x2="12" y2="12"/></svg>`,
  tag:`<svg width="30" height="30" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M20.59 13.41 11 3.83A2 2 0 0 0 9.59 3H4a1 1 0 0 0-1 1v5.59a2 2 0 0 0 .59 1.41l9.58 9.59a2 2 0 0 0 2.82 0l4.6-4.6a2 2 0 0 0 0-2.58z"/></svg>`,
  cart:`<svg width="30" height="30" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><circle cx="9" cy="21" r="1"/><circle cx="20" cy="21" r="1"/><path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"/></svg>`,
  clock:`<svg width="30" height="30" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><polyline points="12 7 12 12 15.5 14"/></svg>`,
  check:`<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>`,
  eye:`<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8Z"/><circle cx="12" cy="12" r="3"/></svg>`,
  eyeOff:`<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17.94 17.94A10.94 10.94 0 0 1 12 20c-7 0-11-8-11-8a21.77 21.77 0 0 1 5.06-6.06M9.9 4.24A10.94 10.94 0 0 1 12 4c7 0 11 8 11 8a21.77 21.77 0 0 1-2.16 3.19"/><path d="M14.12 14.12a3 3 0 1 1-4.24-4.24"/><line x1="1" y1="1" x2="23" y2="23"/></svg>`,
  flash:`<svg width="17" height="17" viewBox="0 0 24 24" fill="currentColor" stroke="none"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></svg>`,
};

/* =========================================================================
   RENDER: SELL
   ========================================================================= */
function cartQtyFor(pid, vid){
  return state.cart.filter(i=>i.productId===pid && (vid===undefined || i.variantId===vid)).reduce((s,i)=>s+i.qty,0);
}
function cartTotals(){
  let subtotal=0, discount=0;
  state.cart.forEach(it=>{
    subtotal += it.unitPrice * it.qty;
    discount += (it.discount||0);
  });
  return { subtotal, discount, total: Math.max(0, subtotal - discount) };
}
function updateCartBar(){
  const bar = document.getElementById('cartbar');
  const totalQty = state.cart.reduce((s,i)=>s+i.qty,0);
  if(totalQty === 0 || state.tab!=='sell'){ bar.classList.add('hidden'); return; }
  bar.classList.remove('hidden');
  document.getElementById('cbCount').textContent = totalQty;
  document.getElementById('cbTotal').textContent = fmtMoney(cartTotals().total);
}

function renderSell(){
  const qRaw = state.search.trim();
  const q = qRaw.length >= 3 ? qRaw.toLowerCase() : '';
  let list = state.products.filter(p=>{
    const matchCat = state.activeCategory==='All' || p.category===state.activeCategory;
    const matchQ = !q || p.name.toLowerCase().includes(q) || p.id.toLowerCase().includes(q) || p.variants.some(v=>((v.barcode||'').toLowerCase().includes(q)));
    return matchCat && matchQ;
  });
  list.sort((a,b)=>a.name.localeCompare(b.name));
  // Every variant is its own tappable card — a product with several sizes shows up as
  // several cards side by side instead of one combined card with a picker sheet.
  const entries = [];
  list.forEach(p=>{ p.variants.forEach(v=>entries.push({p, v})); });

  const today = new Date().toDateString();
  const todaysTxns = state.transactions.filter(t=> new Date(t.date).toDateString()===today);
  const todayRevenue = todaysTxns.reduce((s,t)=>s+t.total,0);

  const html = `
    <div class="stat-strip stat-strip-sticky stat-strip-compact" id="sellStatStrip">
      <div class="stat-card"><div class="label">Today's sales</div><div class="value">${fmtMoney(todayRevenue)}</div></div>
      <div class="stat-card"><div class="label">Transactions</div><div class="value">${todaysTxns.length}</div></div>
      ${isAdmin() ? `<div class="stat-card"><div class="label">Today's profit</div><div class="value">${fmtMoney(totalProfit(todaysTxns))}</div></div>` : ''}
    </div>
    <div class="searchbar" id="sellSearchbar">
      <div class="search-input-wrap">
        ${ICO.search}
        <input id="searchInput" placeholder="Search product, ID or barcode (3+ letters)" value="${esc(state.search)}">
      </div>
      <button class="scan-fab" id="openScanBtn" title="Scan barcode">${ICO.scan}</button>
    </div>
    <div class="chip-row-outer" id="chipRowOuter">
      <div class="tag-chip chip-all ${state.activeCategory==='All'?'active':''}" data-cat="All" id="allChip">All</div>
      <div class="chip-row" id="chipRow">
        ${state.categories.map(c=>`<div class="tag-chip ${c.name===state.activeCategory?'active':''}" data-cat="${esc(c.name)}">${esc(c.name)}</div>`).join('')}
      </div>
    </div>
    ${entries.length? `<div class="product-grid">${entries.map(({p,v})=>cardHTML(p,v)).join('')}</div>` : emptyState('box','No products found', 'Try a different search or category.')}
  `;
  document.getElementById('screen').innerHTML = html;
  updateCartBar();

  document.getElementById('searchInput').addEventListener('input', e=>{
    state.search = e.target.value;
    preserveFocusRender('searchInput', renderSell);
  });
  document.getElementById('openScanBtn').addEventListener('click', ()=>openScanner());
  const chipRowEl = document.getElementById('chipRow');
  const chipRowOuterEl = document.getElementById('chipRowOuter');
  const topbarEl = document.getElementById('topbar');
  const statStripEl = document.getElementById('sellStatStrip');
  const searchbarEl = document.getElementById('sellSearchbar');
  // Stack the sticky bands under each other: topbar, then the KPIs, then the search/scan
  // bar, then the category chips — each pinned to the bottom edge of the one above it so
  // they float together as a single fixed header while the product grid scrolls underneath.
  if(topbarEl){
    const topH = topbarEl.offsetHeight;
    if(statStripEl) statStripEl.style.top = topH + 'px';
    const afterStat = topH + (statStripEl ? statStripEl.offsetHeight : 0);
    if(searchbarEl) searchbarEl.style.top = afterStat + 'px';
    if(chipRowOuterEl) chipRowOuterEl.style.top = (afterStat + (searchbarEl ? searchbarEl.offsetHeight : 0)) + 'px';
  }
  document.getElementById('allChip').addEventListener('click', ()=>{
    state.activeCategory = 'All';
    renderSell();
  });
  enableDragScroll(chipRowEl, (chip)=>{
    state.activeCategory = chip.dataset.cat;
    renderSell();
  });
  document.querySelectorAll('.pcard').forEach(el=>{
    el.addEventListener('click', ()=>{
      if(addToCart(el.dataset.id, 1, el.dataset.vid)) renderCartOverlay();
    });
  });
}

/* Quick bottom-sheet for choosing which size/variant of a multi-variant product to add
   to the cart — used from the sell grid and from barcode-scan results that hit a product
   whose variants share no single price/stock to just add directly. */
function openVariantPicker(p, onPick){
  const root = document.getElementById('modalRoot');
  root.innerHTML = `
    <div class="modal-back" id="mbVariantPick">
      <div class="modal-sheet">
        <div class="modal-handle"></div>
        <div class="section-title" style="padding-top:0">${esc(p.name)} — choose a size</div>
        ${p.variants.map(v=>`
          <div class="list-row variant-pick-row" data-vid="${esc(v.id)}" style="cursor:pointer">
            <div class="variant-thumb" style="cursor:default">${variantVisualHTML(v)}</div>
            <div class="row-info">
              <div class="row-title">${esc(v.name || 'Default')}</div>
              <div class="row-sub">${stockLabel(v.stock)}</div>
            </div>
            <div class="row-right"><div class="amt">${fmtMoney(v.price)}</div></div>
          </div>
        `).join('')}
      </div>
    </div>`;
  document.getElementById('mbVariantPick').addEventListener('click', e=>{ if(e.target.id==='mbVariantPick') root.innerHTML=''; });
  document.querySelectorAll('.variant-pick-row').forEach(el=>{
    el.addEventListener('click', ()=>{
      const v = p.variants.find(x=>x.id===el.dataset.vid);
      root.innerHTML='';
      if(v) onPick(v);
    });
  });
}

/* Case-insensitive exact-name duplicate check, excluding the product currently being edited */
function findDuplicateProductName(name, excludeId){
  const n = (name||'').trim().toLowerCase();
  if(!n) return null;
  return state.products.find(x => x.id!==excludeId && x.name.trim().toLowerCase()===n) || null;
}

function cardHTML(p, v){
  const qty = cartQtyFor(p.id, v.id);
  const out = v.stock<=0;
  const variantTag = v.name || fmtNumber(v.price);
  return `
    <div class="pcard" data-id="${esc(p.id)}" data-vid="${esc(v.id)}">
      ${qty>0?`<div class="add-badge">${qty}</div>`:''}
      <div class="pcard-photo">${variantVisualHTML(v)}</div>
      <div class="pname">${esc(p.name)}</div>
      <div class="price">${fmtMoney(v.price)}</div>
      <div class="variant-bar ${out?'out':''}">${esc(out ? 'Out' : variantTag)}</div>
    </div>`;
}

function emptyState(icon, title, sub){
  return `<div class="empty-state">${ICO[icon]}<div class="t">${esc(title)}</div><div class="s">${esc(sub)}</div></div>`;
}

function addToCart(productId, qtyDelta, variantId){
  const p = state.products.find(x=>x.id===productId);
  if(!p){ toast('Product not found'); return false; }
  const variant = variantId ? p.variants.find(v=>v.id===variantId) : p.variants[0];
  if(!variant){ toast('Variant not found'); return false; }
  const lineKey = p.id + '::' + variant.id;
  let item = state.cart.find(i=>i.lineKey===lineKey);
  const currentQty = item ? item.qty : 0;
  const newQty = currentQty + qtyDelta;
  if(newQty > variant.stock){ toast(`Only ${variant.stock} in stock`); vibrate(60); return false; }
  const label = p.name + (variant.name ? ` (${variant.name})` : '');
  if(newQty <= 0){
    state.cart = state.cart.filter(i=>i.lineKey!==lineKey);
  } else if(item){
    item.qty = newQty;
  } else {
    state.cart.push({ lineKey, productId:p.id, variantId:variant.id, name:label, category:p.category, qty:newQty, unitPrice:variant.price, unitCost:variant.cost, discount:0 });
  }
  vibrate(15);
  if(state.tab==='sell') renderSell();
  updateCartBar();
  if(qtyDelta>0) toast(`Added ${label}`);
  return true;
}

/* =========================================================================
   CART / CHECKOUT OVERLAY
   ========================================================================= */
function openCart(){
  renderCartOverlay();
}
function renderCartOverlay(){
  const root = document.getElementById('modalRoot');
  if(state.cart.length===0){ root.innerHTML=''; return; }
  const t = cartTotals();
  root.innerHTML = `
    <div class="modal-back" id="cartSheetBack">
      <div class="modal-sheet" style="max-height:56vh; display:flex; flex-direction:column;">
        <div class="modal-handle"></div>
        <div class="section-title" style="padding-top:0">
          <span>Current sale (${state.cart.reduce((s,i)=>s+i.qty,0)})</span>
          <button class="icon-btn" style="background:var(--paper-dim);color:var(--ink);width:30px;height:30px" id="cartSheetClose">${ICO.close}</button>
        </div>
        <div style="overflow-y:auto; flex:1; border-top:1px solid var(--line); border-bottom:1px solid var(--line);">
          ${state.cart.map(itemHTML).join('')}
        </div>
        <div class="totals-block">
          <div class="totals-row"><span>Subtotal</span><span class="v">${fmtMoney(t.subtotal)}</span></div>
          <div class="totals-row"><span>Discount</span><span class="v">-${fmtMoney(t.discount)}</span></div>
          <div class="totals-row grand"><span>Total</span><span class="v">${fmtMoney(t.total)}</span></div>
        </div>
        <div class="field" style="padding-bottom:0">
          <div class="btn-row">
            <button class="icon-btn" style="background:var(--red-tint);color:var(--red);width:46px;flex-shrink:0" id="cartClearAll">${ICO.trash}</button>
            <button class="btn btn-primary" id="goCheckoutBtn">Charge ${fmtMoney(t.total)}</button>
          </div>
        </div>
      </div>
    </div>
  `;
  document.getElementById('cartSheetBack').addEventListener('click', e=>{ if(e.target.id==='cartSheetBack') root.innerHTML=''; });
  document.getElementById('cartSheetClose').onclick = ()=> root.innerHTML='';
  document.getElementById('cartClearAll').onclick = ()=>{
    confirmModal('Clear cart?', 'This removes all items from the current sale.', ()=>{
      state.cart=[]; root.innerHTML=''; updateCartBar(); if(state.tab==='sell') renderSell();
    });
  };
  document.getElementById('goCheckoutBtn').onclick = openCheckoutModal;
  root.querySelectorAll('[data-inc]').forEach(b=>b.onclick=()=>{
    const it = state.cart.find(i=>i.lineKey===b.dataset.inc);
    if(it) addToCart(it.productId, 1, it.variantId);
    renderCartOverlay();
  });
  root.querySelectorAll('[data-dec]').forEach(b=>b.onclick=()=>{
    const it = state.cart.find(i=>i.lineKey===b.dataset.dec);
    if(it) addToCart(it.productId, -1, it.variantId);
    renderCartOverlay();
  });
  root.querySelectorAll('[data-remove]').forEach(b=>b.onclick=()=>{
    state.cart = state.cart.filter(i=>i.lineKey!==b.dataset.remove);
    renderCartOverlay(); updateCartBar(); if(state.tab==='sell') renderSell();
  });
  root.querySelectorAll('[data-disc]').forEach(b=>b.onclick=()=>openDiscountModal(b.dataset.disc));
}
function itemHTML(it){
  const lineTotal = it.unitPrice*it.qty - (it.discount||0);
  const prod = state.products.find(x=>x.id===it.productId);
  const variant = prod && prod.variants.find(v=>v.id===it.variantId);
  return `
    <div class="cart-item">
      <div class="ci-thumb">${variant ? variantVisualHTML(variant) : `<div class="ci-thumb-empty" style="background:${catColor(it.category)}">${esc(it.name.slice(0,1).toUpperCase())}</div>`}</div>
      <div class="ci-info">
        <div class="ci-name">${esc(it.name)}</div>
        <div class="ci-unit">${fmtMoney(it.unitPrice)} × ${it.qty}${it.discount?` · -${fmtMoney(it.discount)} off`:''}</div>
        <div class="hstack mt8">
          <div class="qty-stepper">
            <button data-dec="${esc(it.lineKey)}">−</button>
            <span>${it.qty}</span>
            <button data-inc="${esc(it.lineKey)}">+</button>
          </div>
          <button class="discount-link" data-disc="${esc(it.lineKey)}">${it.discount?'Edit discount':'+ Discount'}</button>
        </div>
      </div>
      <div class="ci-right">
        <div class="ci-linetotal">${fmtMoney(lineTotal)}</div>
        <button class="ci-remove" data-remove="${esc(it.lineKey)}">Remove</button>
      </div>
    </div>`;
}
function closeOverlay(){ document.getElementById('overlayRoot').innerHTML=''; document.getElementById('overlayRoot2').innerHTML=''; }

/* =========================================================================
   CUSTOMERS / CREDIT ACCOUNTS / WHATSAPP RECEIPTS
   ========================================================================= */
/* Turns whatever a shop owner types into a phone number into the digits-only,
   country-code-prefixed form wa.me needs. Defaults to Nigeria (234) since a bare
   local number like "0803..." or "803..." is what most people will type in. */
function normalizePhone(phone){
  let d = String(phone||'').replace(/[^\d]/g,'');
  if(!d) return '';
  if(d.startsWith('00')) d = d.slice(2);
  if(d.startsWith('0')) d = '234' + d.slice(1);
  else if(d.length===10) d = '234' + d;               // e.g. "8031234567"
  else if(!d.startsWith('234') && d.length===11) d = '234' + d.slice(1); // safety net
  return d;
}
function hasUsablePhone(phone){ return normalizePhone(phone).length >= 10; }
/* Opens WhatsApp (app or web) with the message pre-typed into a chat with this number —
   the person on this device still taps Send themselves. A vanilla client-side app like this
   one has no way to silently push a WhatsApp message on its own; that requires WhatsApp's
   paid Business API running from a server, which is a separate integration. */
function waLink(phone, text){ return `https://wa.me/${normalizePhone(phone)}?text=${encodeURIComponent(text)}`; }
function sendViaWhatsApp(phone, text){
  if(!hasUsablePhone(phone)){ toast('No valid WhatsApp number on file'); return; }
  window.open(waLink(phone, text), '_blank');
}

/* The customer's total outstanding balance to print on a sale receipt: this sale's
   unpaid portion PLUS whatever they already owed before. Older transactions saved
   before this field existed fall back to just this sale's balance. */
function receiptTotalOwing(txn){
  return txn.totalOwing!=null ? txn.totalOwing : (txn.balanceDue||0);
}
function buildSaleReceiptText(txn){
  const lines = [];
  lines.push(`*${state.settings.shopName}*`);
  if(state.settings.address) lines.push(state.settings.address);
  lines.push('');
  lines.push(`Receipt: ${txn.id}`);
  lines.push(`Date: ${new Date(txn.date).toLocaleString()}`);
  if(txn.userName) lines.push(`Served by: ${txn.userName}`);
  lines.push('');
  txn.items.forEach(it=> lines.push(`${it.name} x${it.qty} — ${fmtMoney(it.lineTotal)}`));
  lines.push('');
  lines.push(`Subtotal: ${fmtMoney(txn.subtotal)}`);
  if(txn.discount) lines.push(`Discount: -${fmtMoney(txn.discount)}`);
  lines.push(`TOTAL: ${fmtMoney(txn.total)}`);
  if(txn.customerName){
    const paid = txn.amountPaid!=null ? txn.amountPaid : txn.total;
    const owing = receiptTotalOwing(txn);
    lines.push('');
    lines.push(`Customer: ${txn.customerName}`);
    lines.push(`Paid now: ${fmtMoney(paid)}`);
    lines.push(owing>0 ? `Total owing: ${fmtMoney(owing)}` : `Fully paid`);
  }
  lines.push('');
  lines.push('Thank you for shopping with us!');
  return lines.join('\n');
}
function buildPaymentReceiptText(customer, entry){
  const lines = [];
  lines.push(`*${state.settings.shopName}*`);
  if(state.settings.address) lines.push(state.settings.address);
  lines.push('');
  lines.push('Payment received');
  lines.push(`Date: ${new Date(entry.date).toLocaleString()}`);
  if(entry.userName) lines.push(`Received by: ${entry.userName}`);
  lines.push(`Customer: ${customer.name}`);
  lines.push(`Amount paid: ${fmtMoney(entry.paid)}`);
  lines.push(entry.balanceAfter>0 ? `Remaining balance: ${fmtMoney(entry.balanceAfter)}` : `Balance cleared — fully paid. Thank you!`);
  lines.push('');
  lines.push('Thank you!');
  return lines.join('\n');
}
/* A stand-alone "how much do you currently owe" statement — used for the "Send balance
   statement" button on a customer's page, not tied to any single sale or payment. */
function buildBalanceStatementText(customer){
  const lines = [];
  lines.push(`*${state.settings.shopName}*`);
  if(state.settings.address) lines.push(state.settings.address);
  lines.push('');
  lines.push('Account balance statement');
  lines.push(`Date: ${new Date().toLocaleString()}`);
  lines.push(`Customer: ${customer.name}`);
  lines.push('');
  lines.push(customer.balance>0 ? `*You currently owe: ${fmtMoney(customer.balance)}*` : `Your balance is fully cleared — you owe nothing. Thank you!`);
  lines.push('');
  lines.push(customer.balance>0 ? 'Kindly settle at your earliest convenience. Thank you for your patronage!' : 'Thank you for your patronage!');
  return lines.join('\n');
}

function findCustomer(id){ return state.customers.find(c=>c.id===id); }

/* Sheet to search existing customers or add a new one on the fly — used from checkout and
   from the Customers tab. Fully replaces #modalRoot (matching the rest of the app's nested-
   sheet pattern); onCancel/onSelect are responsible for redrawing whatever should come back. */
function openCustomerPickerModal(onSelect, onCancel){
  const root = document.getElementById('modalRoot');
  let q = '';
  function render(){
    const ql = q.trim().toLowerCase();
    const list = state.customers
      .filter(c=> !ql || c.name.toLowerCase().includes(ql) || (c.phone||'').includes(ql))
      .sort((a,b)=>a.name.localeCompare(b.name));
    root.innerHTML = `
      <div class="modal-back" id="mbCustPick">
        <div class="modal-sheet" style="max-height:70vh; display:flex; flex-direction:column;">
          <div class="modal-handle"></div>
          <div class="section-title" style="padding-top:0">Select customer</div>
          <div class="field" style="padding-top:0">
            <div class="search-input-wrap">${ICO.search}<input id="custPickSearch" placeholder="Search name or phone" value="${esc(q)}"></div>
          </div>
          <div style="overflow-y:auto; flex:1; border-top:1px solid var(--line);">
            ${list.length ? list.map(c=>`
              <div class="list-row" data-id="${esc(c.id)}">
                <div class="row-swatch" style="background:var(--teal)">${esc((c.name||'?').trim().slice(0,1).toUpperCase())}</div>
                <div class="row-info">
                  <div class="row-title">${esc(c.name)}</div>
                  <div class="row-sub">${esc(c.phone||'No phone number')}</div>
                </div>
                <div class="row-right"><div class="amt" style="color:${c.balance>0?'var(--red)':'var(--green)'}">${c.balance>0?fmtMoney(c.balance)+' owed':'Clear'}</div></div>
              </div>
            `).join('') : `<div class="field-hint" style="padding:14px 16px">${ql?'No matching customers.':'No customers yet — add one below.'}</div>`}
          </div>
          <div class="field"><div class="btn-row">
            <button class="btn btn-ghost" id="custPickCancel">Cancel</button>
            ${isAdmin()?`<button class="btn btn-primary" id="custPickAdd">+ Add new customer</button>`:''}
          </div></div>
        </div>
      </div>`;
    document.getElementById('mbCustPick').addEventListener('click', e=>{ if(e.target.id==='mbCustPick'){ root.innerHTML=''; onCancel && onCancel(); } });
    document.getElementById('custPickCancel').onclick = ()=>{ root.innerHTML=''; onCancel && onCancel(); };
    const custPickAddBtn = document.getElementById('custPickAdd');
    if(custPickAddBtn) custPickAddBtn.onclick = ()=> openCustomerFormModal(null, newCust=>{ onSelect(newCust); });
    document.getElementById('custPickSearch').addEventListener('input', e=>{ q = e.target.value; preserveFocusRender('custPickSearch', render); });
    root.querySelectorAll('.list-row').forEach(el=>{
      el.addEventListener('click', ()=>{ const c = findCustomer(el.dataset.id); if(c){ root.innerHTML=''; onSelect(c); } });
    });
  }
  render();
}

/* Add / edit a customer's name & phone. onSaved receives the saved customer object. */
function openCustomerFormModal(customer, onSaved){
  const editing = !!customer;
  if(!isAdmin()){ toast(editing?'Only an admin can edit customer details':'Only an admin can register a new credit customer'); return; }
  const root = document.getElementById('modalRoot');
  root.innerHTML = `
    <div class="modal-back" id="mbCustForm">
      <div class="modal-sheet">
        <div class="modal-handle"></div>
        <div class="section-title" style="padding-top:0">${editing?'Edit customer':'New customer'}</div>
        <div class="field"><label>Name</label><input id="custName" placeholder="Customer's name" value="${editing?esc(customer.name):''}"></div>
        <div class="field"><label>WhatsApp / phone number</label><input id="custPhone" type="tel" placeholder="e.g. 0803 123 4567" value="${editing?esc(customer.phone||''):''}"></div>
        <div class="field field-hint" style="padding-top:0">Used to send this customer their sale and payment receipts on WhatsApp.</div>
        <div class="field"><div class="btn-row">
          <button class="btn btn-ghost" id="custFormCancel">Cancel</button>
          <button class="btn btn-primary" id="custFormSave">Save</button>
        </div></div>
      </div>
    </div>`;
  document.getElementById('mbCustForm').addEventListener('click', e=>{ if(e.target.id==='mbCustForm') root.innerHTML=''; });
  document.getElementById('custFormCancel').onclick = ()=>root.innerHTML='';
  document.getElementById('custFormSave').onclick = ()=>{
    const name = document.getElementById('custName').value.trim();
    const phone = document.getElementById('custPhone').value.trim();
    if(!name){ toast('Enter a customer name'); return; }
    if(phone && !hasUsablePhone(phone)){ toast('That phone number looks incomplete'); return; }
    let saved;
    if(editing){
      customer.name = name; customer.phone = phone; customer.updatedAt = new Date().toISOString();
      saved = customer;
    } else {
      saved = { id: uid('CUST'), name, phone, balance:0, createdAt:new Date().toISOString(), updatedAt:new Date().toISOString() };
      state.customers.push(saved);
    }
    saveCustomers();
    root.innerHTML='';
    toast(editing?'Customer updated':'Customer added');
    onSaved && onSaved(saved);
  };
}

/* Record a payment against a customer's outstanding balance. Creates a ledger entry, updates
   their balance, then shows a payment receipt that can be sent straight to their WhatsApp. */
function openRecordPaymentModal(customer){
  const root = document.getElementById('modalRoot');
  root.innerHTML = `
    <div class="modal-back" id="mbPay">
      <div class="modal-sheet">
        <div class="modal-handle"></div>
        <div class="section-title" style="padding-top:0">Record payment — ${esc(customer.name)}</div>
        <div class="field field-hint" style="padding-top:0">Currently owes ${fmtMoney(customer.balance)}</div>
        <div class="field"><label>Amount paid (${state.settings.currency})</label><input type="number" min="0" step="0.01" id="payAmount" value="${customer.balance>0?customer.balance:''}"></div>
        <div class="field">
          <label>Payment method</label>
          <div class="seg" id="payMethodSegC">
            <button class="active" data-v="Cash">Cash</button>
            <button data-v="Transfer">Transfer</button>
            <button data-v="Card">Card</button>
          </div>
        </div>
        <div class="field"><label>Note (optional)</label><input id="payNote" placeholder="e.g. part payment"></div>
        <div class="field"><div class="btn-row">
          <button class="btn btn-ghost" id="payCancel">Cancel</button>
          <button class="btn btn-primary" id="payConfirm">Save payment</button>
        </div></div>
      </div>
    </div>`;
  let payMethod = 'Cash';
  root.querySelectorAll('#payMethodSegC button').forEach(b=>b.onclick=()=>{
    root.querySelectorAll('#payMethodSegC button').forEach(x=>x.classList.remove('active')); b.classList.add('active'); payMethod=b.dataset.v;
  });
  document.getElementById('mbPay').addEventListener('click', e=>{ if(e.target.id==='mbPay') root.innerHTML=''; });
  document.getElementById('payCancel').onclick = ()=>root.innerHTML='';
  document.getElementById('payConfirm').onclick = ()=>{
    let amount = parseFloat(document.getElementById('payAmount').value)||0;
    if(amount<=0){ toast('Enter an amount greater than 0'); return; }
    if(amount>customer.balance){ toast(`Can't exceed the ${fmtMoney(customer.balance)} owed`); return; }
    const note = document.getElementById('payNote').value.trim();
    customer.balance = Math.round((customer.balance - amount + Number.EPSILON)*100)/100;
    customer.updatedAt = new Date().toISOString();
    const entry = { id: uid('LEDG'), customerId: customer.id, type:'payment', txnId:null, amount, paid:amount, balanceAfter:customer.balance, payMethod, note, date:new Date().toISOString(), userName: currentUserInfo().name };
    state.customerLedger.unshift(entry);
    saveCustomers(); saveCustomerLedger(); saveNewLedgerEntryCloud(entry);
    root.innerHTML='';
    toast('Payment recorded');
    vibrate([20,40,20]);
    showPaymentReceipt(customer, entry);
  };
}

function showPaymentReceipt(customer, entry){
  const root = document.getElementById('overlayRoot');
  root.innerHTML = `
    <div class="overlay">
      <div class="overlay-header">
        <button class="icon-btn" style="background:transparent;color:var(--ink)" id="prBack">${ICO.back}</button>
        <h2>Payment receipt</h2>
        <span style="width:36px"></span>
      </div>
      <div class="overlay-body">
        <div class="receipt-wrap">
          <div id="printArea">
            <div class="receipt-jag-top"></div>
            <div id="receiptPrint">
              <div class="r-center">
                <div class="r-shop">${esc(state.settings.shopName)}</div>
                <div class="r-sub">${esc(state.settings.address||'')}</div>
              </div>
              <div class="r-divider"></div>
              <div class="r-row"><span>Customer</span><span>${esc(customer.name)}</span></div>
              <div class="r-row"><span>Date</span><span>${new Date(entry.date).toLocaleString()}</span></div>
              <div class="r-row"><span>Method</span><span>${esc(entry.payMethod||'-')}</span></div>
              ${entry.userName?`<div class="r-row"><span>Received by</span><span>${esc(entry.userName)}</span></div>`:''}
              ${entry.note?`<div class="r-row"><span>Note</span><span>${esc(entry.note)}</span></div>`:''}
              <div class="r-divider"></div>
              <div class="r-grand"><span>AMOUNT PAID</span><span>${fmtMoney(entry.paid)}</span></div>
              <div class="r-row"><span>${entry.balanceAfter>0?'Balance remaining':'Balance'}</span><span>${entry.balanceAfter>0?fmtMoney(entry.balanceAfter):'Cleared'}</span></div>
              <div class="r-foot">Thank you!</div>
            </div>
            <div class="receipt-jag-bottom"></div>
          </div>
        </div>
      </div>
      <div class="overlay-footer">
        <div class="btn-row">
          <button class="btn btn-ghost" id="prDone">Done</button>
          ${hasUsablePhone(customer.phone)?`<button class="btn btn-primary" id="prWhatsapp">Send via WhatsApp</button>`:''}
        </div>
      </div>
    </div>`;
  const back = ()=> openCustomerDetail(customer.id);
  document.getElementById('prBack').onclick = back;
  document.getElementById('prDone').onclick = back;
  const waBtn = document.getElementById('prWhatsapp');
  if(waBtn) waBtn.onclick = ()=> sendViaWhatsApp(customer.phone, buildPaymentReceiptText(customer, entry));
}

/* Full ledger (sales-on-credit + payments) for one customer, newest first. */
function openCustomerDetail(customerId){
  const customer = findCustomer(customerId);
  if(!customer) return;
  const root = document.getElementById('overlayRoot');
  function render(){
    const entries = state.customerLedger.filter(e=>e.customerId===customerId).sort((a,b)=>new Date(b.date)-new Date(a.date));
    root.innerHTML = `
      <div class="overlay">
        <div class="overlay-header">
          <button class="icon-btn" style="background:transparent;color:var(--ink)" id="cdBack">${ICO.back}</button>
          <h2>${esc(customer.name)}</h2>
          ${isAdmin()?`<button class="icon-btn" style="background:transparent;color:var(--ink)" id="cdEdit">${ICO.edit}</button>`:`<span style="width:36px"></span>`}
        </div>
        <div class="overlay-body">
          <div class="section-pad" style="padding-top:14px">
            <div class="stat-strip stat-strip-compact">
              <div class="stat-card"><div class="label">Balance owed</div><div class="value" style="color:${customer.balance>0?'var(--red)':'var(--green)'}">${fmtMoney(customer.balance)}</div></div>
              <div class="stat-card"><div class="label">Phone</div><div class="value" style="font-size:13px">${esc(customer.phone||'—')}</div></div>
            </div>
            <div class="field"><div class="btn-row">
              ${customer.balance>0?`<button class="btn btn-primary" id="cdRecordPay">Record payment</button>`:''}
              ${isAdmin()?`<button class="btn btn-ghost" id="cdAdjust">Adjust balance</button>`:''}
            </div></div>
            ${hasUsablePhone(customer.phone)?`<div class="field"><button class="btn btn-ghost" id="cdWhatsapp" style="width:100%">Send balance statement via WhatsApp</button></div>`:''}
          </div>
          <div class="section-title"><span>History</span></div>
          ${entries.length? entries.map(e=>{
            const added = Math.round((e.amount-e.paid+Number.EPSILON)*100)/100; // portion of a sale left unpaid, added to balance
            const isAdj = e.type==='adjustment';
            const delta = isAdj ? e.amount : added; // adjustments store the signed change directly
            const icon = e.type==='payment' ? ICO.check : (isAdj ? ICO.edit : ICO.receipt);
            const swatch = e.type==='payment' ? 'var(--green)' : (isAdj ? 'var(--teal)' : 'var(--amber)');
            const title = e.type==='payment' ? 'Payment received' : (isAdj ? 'Balance adjustment' : 'Credit sale');
            const positive = e.type==='payment' ? false : (isAdj ? delta>=0 : true);
            const amtShown = e.type==='payment' ? e.paid : Math.abs(delta);
            return `
            <div class="list-row">
              <div class="row-swatch" style="background:${swatch}">${icon}</div>
              <div class="row-info">
                <div class="row-title">${title}${e.txnId?` · ${esc(e.txnId)}`:''}</div>
                <div class="row-sub">${new Date(e.date).toLocaleString()}${e.payMethod?' · '+esc(e.payMethod):''}${e.note?' · '+esc(e.note):''}</div>
                ${e.userName?`<div class="row-sub">By ${esc(e.userName)}</div>`:''}
              </div>
              <div class="row-right">
                <div class="amt" style="color:${positive?'var(--red)':'var(--green)'}">${positive?'+':'-'}${fmtMoney(amtShown)}</div>
                <div class="tag">Bal ${fmtMoney(e.balanceAfter)}</div>
              </div>
            </div>
          `;}).join('') : emptyState('clock','No history yet','Sales and payments for this customer will appear here.')}
        </div>
      </div>`;
    document.getElementById('cdBack').onclick = closeOverlay;
    const editBtn = document.getElementById('cdEdit');
    // Don't closeOverlay() here — that would clear this customer page out from underneath
    // the edit form, so cancelling out of the edit would drop straight to the Customers tab
    // instead of back to this page. Leave it in place; the form opens on top of it (like
    // Record payment does) and cancelling just reveals it again.
    if(editBtn) editBtn.onclick = ()=>{
      openCustomerFormModal(customer, ()=>{ if(state.tab==='customers') renderCustomers(); openCustomerDetail(customerId); });
    };
    const payBtn = document.getElementById('cdRecordPay');
    if(payBtn) payBtn.onclick = ()=> openRecordPaymentModal(customer);
    const adjustBtn = document.getElementById('cdAdjust');
    if(adjustBtn) adjustBtn.onclick = ()=> openAdjustBalanceModal(customer, ()=>{ if(state.tab==='customers') renderCustomers(); render(); });
    const waBtn = document.getElementById('cdWhatsapp');
    if(waBtn) waBtn.onclick = ()=> sendViaWhatsApp(customer.phone, buildBalanceStatementText(customer));
  }
  render();
}

/* Manually correct a customer's balance — the main use is setting an opening balance for
   someone who already owed money before you started tracking them in the app. Admin-only,
   since it edits the balance directly rather than through a normal sale/payment. */
function openAdjustBalanceModal(customer, onSaved){
  const root = document.getElementById('modalRoot');
  root.innerHTML = `
    <div class="modal-back" id="mbAdjust">
      <div class="modal-sheet">
        <div class="modal-handle"></div>
        <div class="section-title" style="padding-top:0">Adjust balance — ${esc(customer.name)}</div>
        <div class="field field-hint" style="padding-top:0">Currently owes ${fmtMoney(customer.balance)}. Use this for a correction or an opening balance carried over from before — not for a normal sale or payment.</div>
        <div class="field">
          <label>New balance owed (${state.settings.currency})</label>
          <input type="number" min="0" step="0.01" id="adjNewBalance" value="${customer.balance}">
        </div>
        <div class="field"><label>Reason / note</label><input id="adjNote" placeholder="e.g. Balance owed before using this app"></div>
        <div class="field"><div class="btn-row">
          <button class="btn btn-ghost" id="adjCancel">Cancel</button>
          <button class="btn btn-primary" id="adjConfirm">Save</button>
        </div></div>
      </div>
    </div>`;
  document.getElementById('mbAdjust').addEventListener('click', e=>{ if(e.target.id==='mbAdjust') root.innerHTML=''; });
  document.getElementById('adjCancel').onclick = ()=>root.innerHTML='';
  document.getElementById('adjConfirm').onclick = ()=>{
    const newBalance = Math.max(0, Math.round((parseFloat(document.getElementById('adjNewBalance').value)||0)*100)/100);
    const note = document.getElementById('adjNote').value.trim();
    const delta = Math.round((newBalance-customer.balance+Number.EPSILON)*100)/100;
    if(delta===0){ toast('Balance unchanged'); return; }
    if(!note){ toast('Add a short note explaining the adjustment'); return; }
    customer.balance = newBalance;
    customer.updatedAt = new Date().toISOString();
    const entry = { id: uid('LEDG'), customerId: customer.id, type:'adjustment', txnId:null, amount:delta, paid:0, balanceAfter:newBalance, payMethod:null, note, date:new Date().toISOString(), userName: currentUserInfo().name };
    state.customerLedger.unshift(entry);
    saveCustomers(); saveCustomerLedger(); saveNewLedgerEntryCloud(entry);
    root.innerHTML='';
    toast('Balance updated');
    onSaved && onSaved();
  };
}

/* =========================================================================
   RENDER: CUSTOMERS
   ========================================================================= */
function renderCustomers(){
  const q = state.customersSearch.trim().toLowerCase();
  const list = state.customers
    .filter(c=> !q || c.name.toLowerCase().includes(q) || (c.phone||'').includes(q))
    .sort((a,b)=> (b.balance||0)-(a.balance||0) || a.name.localeCompare(b.name));
  const totalOwed = state.customers.reduce((s,c)=>s+(c.balance>0?c.balance:0),0);
  const owingCount = state.customers.filter(c=>c.balance>0).length;
  const html = `
    <div class="stat-strip stat-strip-sticky stat-strip-compact" id="custStatStrip">
      <div class="stat-card"><div class="label">Total owed</div><div class="value">${fmtMoney(totalOwed)}</div></div>
      <div class="stat-card"><div class="label">Customers owing</div><div class="value">${owingCount}</div></div>
    </div>
    <div class="searchbar searchbar-sticky" id="custSearchbar">
      <div class="search-input-wrap">${ICO.search}<input id="custSearchInput" placeholder="Search name or phone" value="${esc(state.customersSearch)}"></div>
      ${isAdmin()?`<button class="scan-fab" id="custAddBtn" title="Add customer">${ICO.plus}</button>`:''}
    </div>
    <div class="section-title"><span>Customers</span><span class="count">${state.customers.length}</span></div>
    ${list.length? list.map(c=>`
      <div class="list-row" data-id="${esc(c.id)}">
        <div class="row-swatch" style="background:var(--teal)">${esc((c.name||'?').trim().slice(0,1).toUpperCase())}</div>
        <div class="row-info">
          <div class="row-title">${esc(c.name)}</div>
          <div class="row-sub">${esc(c.phone||'No phone number')}</div>
        </div>
        <div class="row-right">
          <div class="amt" style="color:${c.balance>0?'var(--red)':'var(--green)'}">${c.balance>0?fmtMoney(c.balance):'Clear'}</div>
          <div class="tag">${c.balance>0?'owed':'no balance'}</div>
        </div>
        <span class="chevron">${ICO.chevron}</span>
      </div>
    `).join('') : emptyState('box', state.customers.length?'No matches':'No customers yet', state.customers.length?'Try a different search.':'Add a customer here, or while checking out a credit sale.')}
  `;
  document.getElementById('screen').innerHTML = html;
  const custTopbarEl = document.getElementById('topbar');
  const custStatStripEl = document.getElementById('custStatStrip');
  if(custTopbarEl && custStatStripEl) custStatStripEl.style.top = custTopbarEl.offsetHeight + 'px';
  document.getElementById('custSearchInput').addEventListener('input', e=>{
    state.customersSearch = e.target.value;
    preserveFocusRender('custSearchInput', renderCustomers);
  });
  const custAddBtn = document.getElementById('custAddBtn');
  if(custAddBtn) custAddBtn.addEventListener('click', ()=>{
    openCustomerFormModal(null, ()=>renderCustomers());
  });
  document.querySelectorAll('#screen .list-row').forEach(el=>{
    el.addEventListener('click', ()=> openCustomerDetail(el.dataset.id));
  });
}

function openDiscountModal(lineKey){
  const it = state.cart.find(i=>i.lineKey===lineKey);
  if(!it) return;
  const root = document.getElementById('modalRoot');
  root.innerHTML = `
    <div class="modal-back" id="mbDisc">
      <div class="modal-sheet">
        <div class="modal-handle"></div>
        <div class="section-title" style="padding-top:0">Line discount — ${esc(it.name)}</div>
        <div class="field"><label>Discount amount (${state.settings.currency})</label><input type="number" min="0" id="discInput" value="${it.discount||0}"></div>
        <div class="field"><div class="btn-row"><button class="btn btn-ghost" id="discCancel">Cancel</button><button class="btn btn-primary" id="discSave">Apply</button></div></div>
      </div>
    </div>`;
  document.getElementById('mbDisc').addEventListener('click', e=>{ if(e.target.id==='mbDisc') root.innerHTML=''; });
  document.getElementById('discCancel').onclick = ()=>root.innerHTML='';
  document.getElementById('discSave').onclick = ()=>{
    let v = parseFloat(document.getElementById('discInput').value)||0;
    const max = it.unitPrice*it.qty;
    if(v<0) v=0; if(v>max) v=max;
    it.discount = v;
    root.innerHTML='';
    renderCartOverlay();
  };
}

function openCheckoutModal(){
  const t = cartTotals();
  const root = document.getElementById('modalRoot');
  let txnType='Sales', payMethod='Cash';
  let custType='walkin'; // 'walkin' | 'credit'
  let customer=null;
  let amountPaid=t.total;

  function render(){
    if(amountPaid>t.total) amountPaid=t.total;
    if(amountPaid<0) amountPaid=0;
    const due = customer ? Math.max(0, Math.round((t.total-amountPaid+Number.EPSILON)*100)/100) : 0;
    root.innerHTML = `
      <div class="modal-back" id="mbCheckout">
        <div class="modal-sheet">
          <div class="modal-handle"></div>
          <div class="section-title" style="padding-top:0">Complete sale</div>
          <div class="field">
            <label>Transaction type</label>
            <div class="seg" id="txnTypeSeg">
              <button class="${txnType==='Sales'?'active':''}" data-v="Sales">Sales</button>
              <button class="${txnType==='Personal Use'?'active':''}" data-v="Personal Use">Personal Use</button>
              <button class="${txnType==='Return'?'active':''}" data-v="Return">Return</button>
            </div>
          </div>
          <div class="field">
            <label>Customer</label>
            <div class="seg" id="custTypeSeg">
              <button class="${custType==='walkin'?'active':''}" data-v="walkin">Walk-in</button>
              <button class="${custType==='credit'?'active':''}" data-v="credit">Credit customer</button>
            </div>
          </div>
          ${custType==='credit' ? `
            <div class="field" style="padding-top:0">
              ${customer ? `
                <div class="list-row" id="ckCustRow" style="border:1px solid var(--line);border-radius:12px;cursor:pointer">
                  <div class="row-swatch" style="background:var(--teal)">${esc((customer.name||'?').trim().slice(0,1).toUpperCase())}</div>
                  <div class="row-info"><div class="row-title">${esc(customer.name)}</div><div class="row-sub">${esc(customer.phone||'No phone number')}${customer.balance>0?` · already owes ${fmtMoney(customer.balance)}`:''}</div></div>
                  <span class="chevron">${ICO.chevron}</span>
                </div>
              ` : `<button class="btn btn-ghost" id="ckCustRow" style="width:100%">${isAdmin()?'Select or add customer':'Select customer'}</button>`}
            </div>
          ` : ''}
          <div class="field">
            <label>Payment method${custType==='credit'?' (for amount paid now)':''}</label>
            <div class="seg" id="payMethodSeg">
              <button class="${payMethod==='Cash'?'active':''}" data-v="Cash">Cash</button>
              <button class="${payMethod==='Transfer'?'active':''}" data-v="Transfer">Transfer</button>
              <button class="${payMethod==='Card'?'active':''}" data-v="Card">Card</button>
            </div>
          </div>
          ${custType==='credit' ? `
            <div class="field">
              <label>Amount paying now (${state.settings.currency})</label>
              <input type="text" inputmode="decimal" id="ckAmountPaid" value="${amountPaid}">
              <div class="hstack mt8" style="gap:8px">
                <button type="button" class="discount-link" id="ckPayFull">Full amount</button>
                <button type="button" class="discount-link" id="ckPayNone">No payment now</button>
              </div>
            </div>
          ` : ''}
          <div class="totals-block" style="border-top:1px solid var(--line)">
            <div class="totals-row"><span>Subtotal</span><span class="v">${fmtMoney(t.subtotal)}</span></div>
            <div class="totals-row"><span>Discount</span><span class="v">-${fmtMoney(t.discount)}</span></div>
            <div class="totals-row grand"><span>Amount due</span><span class="v">${fmtMoney(t.total)}</span></div>
            ${custType==='credit' ? `
              <div class="totals-row"><span>Paying now</span><span class="v">${fmtMoney(amountPaid)}</span></div>
              <div class="totals-row"><span>Added to balance</span><span class="v" style="color:${due>0?'var(--red)':'var(--green)'}">${fmtMoney(due)}</span></div>
            ` : ''}
          </div>
          <div class="field"><div class="btn-row">
            <button class="btn btn-ghost" id="ckCancel">Cancel</button>
            <button class="btn btn-primary" id="ckConfirm">Confirm &amp; print receipt</button>
          </div></div>
        </div>
      </div>`;
    root.querySelectorAll('#txnTypeSeg button').forEach(b=>b.onclick=()=>{ txnType=b.dataset.v; render(); });
    root.querySelectorAll('#custTypeSeg button').forEach(b=>b.onclick=()=>{
      custType=b.dataset.v;
      if(custType==='walkin'){ customer=null; amountPaid=t.total; }
      render();
    });
    root.querySelectorAll('#payMethodSeg button').forEach(b=>b.onclick=()=>{ payMethod=b.dataset.v; render(); });
    const custRow = document.getElementById('ckCustRow');
    if(custRow) custRow.onclick = ()=>{
      openCustomerPickerModal(sel=>{ customer=sel; amountPaid=t.total; render(); }, ()=>render());
    };
    const amtInput = document.getElementById('ckAmountPaid');
    if(amtInput) amtInput.addEventListener('input', e=>{ amountPaid = parseFloat(e.target.value)||0; preserveFocusRender('ckAmountPaid', render); });
    const payFullBtn = document.getElementById('ckPayFull');
    if(payFullBtn) payFullBtn.onclick = ()=>{ amountPaid=t.total; render(); };
    const payNoneBtn = document.getElementById('ckPayNone');
    if(payNoneBtn) payNoneBtn.onclick = ()=>{ amountPaid=0; render(); };
    document.getElementById('mbCheckout').addEventListener('click', e=>{ if(e.target.id==='mbCheckout') root.innerHTML=''; });
    document.getElementById('ckCancel').onclick = ()=>root.innerHTML='';
    document.getElementById('ckConfirm').onclick = ()=>{
      if(custType==='credit' && !customer){ toast('Select or add a customer first'); return; }
      root.innerHTML='';
      completeSale(txnType, payMethod, custType==='credit' ? { customer, amountPaid } : null);
    };
  }
  render();
}

function completeSale(txnType, payMethod, creditCtx){
  // validate stock again
  for(const it of state.cart){
    const p = state.products.find(x=>x.id===it.productId);
    const v = p && p.variants.find(x=>x.id===it.variantId);
    if(!p || !v || v.stock < it.qty){ toast(`${it.name} no longer has enough stock`); return; }
  }
  const t = cartTotals();
  const who = currentUserInfo();
  const customer = creditCtx && creditCtx.customer;
  const amountPaid = customer ? Math.max(0, Math.min(t.total, creditCtx.amountPaid)) : t.total;
  const balanceDue = customer ? Math.round((t.total-amountPaid+Number.EPSILON)*100)/100 : 0;
  const txn = {
    id: 'TXN-' + nowStamp() + '-' + String(state.settings.txnSeq++).padStart(3,'0'),
    type: txnType,
    payment: amountPaid>0 ? payMethod : 'Credit',
    date: new Date().toISOString(),
    userName: who.name, userEmail: who.email,
    items: state.cart.map(it=>({
      productId:it.productId, variantId:it.variantId, name:it.name, qty:it.qty, unitPrice:it.unitPrice, unitCost:it.unitCost,
      discount:it.discount||0, lineTotal: it.unitPrice*it.qty - (it.discount||0)
    })),
    subtotal:t.subtotal, discount:t.discount, total:t.total,
    customerId: customer?customer.id:null, customerName: customer?customer.name:null, customerPhone: customer?customer.phone:null,
    amountPaid, balanceDue
  };
  // decrement stock on the specific variant sold, then re-sync the product's aggregate stock
  state.cart.forEach(it=>{
    const p = state.products.find(x=>x.id===it.productId);
    const v = p && p.variants.find(x=>x.id===it.variantId);
    if(p && v){ v.stock -= it.qty; syncProductFromVariants(p); p.updatedAt = new Date().toISOString(); }
  });
  state.transactions.unshift(txn);
  saveProducts(); saveTransactions(); saveSettings();
  saveNewTransactionCloud(txn);
  if(customer){
    customer.balance = Math.round(((customer.balance||0) + balanceDue + Number.EPSILON)*100)/100;
    customer.updatedAt = new Date().toISOString();
    // total the customer owes across ALL purchases (this sale plus any prior unpaid
    // balance), not just what this one sale added — this is what prints on the receipt
    // so a customer who already owed money still sees that debt even if they paid
    // today's purchase in full.
    txn.totalOwing = customer.balance;
    const entry = { id: uid('LEDG'), customerId: customer.id, type:'sale', txnId: txn.id, amount:t.total, paid:amountPaid, balanceAfter:customer.balance, payMethod:txn.payment, note:'', date:new Date().toISOString(), userName: who.name };
    state.customerLedger.unshift(entry);
    saveCustomers(); saveCustomerLedger(); saveNewLedgerEntryCloud(entry);
  }
  state.lastReceipt = txn;
  state.cart = [];
  closeOverlay();
  updateCartBar();
  if(state.tab==='sell') renderSell();
  vibrate([20,40,20]);
  showReceipt(txn, true);
}

/* =========================================================================
   RECEIPT
   ========================================================================= */
function showReceipt(txn, fresh){
  const root = document.getElementById('overlayRoot');
  root.innerHTML = `
    <div class="overlay">
      <div class="overlay-header">
        <button class="icon-btn" style="background:transparent;color:var(--ink)" id="rcBack">${ICO.back}</button>
        <h2>Receipt</h2>
        <button class="icon-btn" style="background:transparent;color:var(--ink)" id="rcPrint">${ICO.print}</button>
      </div>
      <div class="overlay-body">
        <div class="receipt-wrap">
          <div id="printArea">
            <div class="receipt-jag-top"></div>
            <div id="receiptPrint">
              <div class="r-center">
                ${state.settings.logo?`<img src="${state.settings.logo}" alt="" style="width:44px;height:44px;object-fit:cover;border-radius:8px;margin-bottom:6px">`:''}
                <div class="r-shop">${esc(state.settings.shopName)}</div>
                <div class="r-sub">${esc(state.settings.shopSub)}</div>
                <div class="r-sub">${esc(state.settings.address||'')}</div>
              </div>
              <div class="r-divider"></div>
              <div class="r-row"><span>Receipt</span><span>${esc(txn.id)}</span></div>
              <div class="r-row"><span>Date</span><span>${new Date(txn.date).toLocaleString()}</span></div>
              <div class="r-row"><span>Type</span><span>${esc(txn.type)}</span></div>
              <div class="r-row"><span>Payment</span><span>${esc(txn.payment||'-')}</span></div>
              ${txn.userName?`<div class="r-row"><span>Served by</span><span>${esc(txn.userName)}</span></div>`:''}
              <div class="r-divider"></div>
              ${txn.items.map(it=>`
                <div class="r-item-name">${esc(it.name)}</div>
                <div class="r-item-meta"><span>${it.qty} × ${fmtMoney(it.unitPrice)}${it.discount?` (-${fmtMoney(it.discount)})`:''}</span><span>${fmtMoney(it.lineTotal)}</span></div>
              `).join('')}
              <div class="r-divider"></div>
              <div class="r-row"><span>Subtotal</span><span>${fmtMoney(txn.subtotal)}</span></div>
              <div class="r-row"><span>Discount</span><span>-${fmtMoney(txn.discount)}</span></div>
              <div class="r-grand"><span>TOTAL</span><span>${fmtMoney(txn.total)}</span></div>
              ${txn.customerName ? `
                <div class="r-divider"></div>
                <div class="r-row"><span>Customer</span><span>${esc(txn.customerName)}</span></div>
                <div class="r-row"><span>Paid now</span><span>${fmtMoney(txn.amountPaid!=null?txn.amountPaid:txn.total)}</span></div>
                ${receiptTotalOwing(txn)>0 ? `<div class="r-row" style="color:var(--red)"><span>Total owing</span><span>${fmtMoney(receiptTotalOwing(txn))}</span></div>` : ''}
              ` : ''}
              <div class="r-barcode"><svg id="rcBarcodeSvg"></svg></div>
              <div class="r-foot">Thank you for shopping with us!<br>Goods sold in good condition.</div>
            </div>
            <div class="receipt-jag-bottom"></div>
          </div>
        </div>
      </div>
      <div class="overlay-footer">
        <div class="btn-row">
          ${fresh?`<button class="btn btn-ghost" id="rcDone">Done</button>`:''}
          <button class="btn btn-primary" id="rcPrint2">Print receipt</button>
        </div>
        ${hasUsablePhone(txn.customerPhone) ? `<button class="btn btn-ghost mt8" id="rcWhatsapp" style="width:100%">Send receipt via WhatsApp</button>` : ''}
      </div>
    </div>
  `;
  try{ JsBarcode('#rcBarcodeSvg', txn.id, { format:'CODE128', displayValue:true, fontSize:10, height:34, width:1.4, margin:0, font:'IBM Plex Mono', background:'transparent', lineColor:'#1a1a1a' }); }catch(e){}
  document.getElementById('rcBack').onclick = closeOverlay;
  document.getElementById('rcPrint').onclick = ()=>window.print();
  document.getElementById('rcPrint2').onclick = ()=>window.print();
  const rcWaBtn = document.getElementById('rcWhatsapp');
  if(rcWaBtn) rcWaBtn.onclick = ()=> sendViaWhatsApp(txn.customerPhone, buildSaleReceiptText(txn));
  if(fresh) document.getElementById('rcDone').onclick = closeOverlay;
}

/* =========================================================================
   RENDER: PRODUCTS
   ========================================================================= */
/* Finds groups of products that currently share the same barcode — leftover from before this
   was blocked, or from data entered outside the app. Surfaced as a cleanup banner on Products tab. */
function findBarcodeConflicts(){
  const groups = {};
  state.products.forEach(p=>{
    (p.variants||[]).forEach(v=>{
      const b = ((v.barcode||p.id)||'').trim().toLowerCase();
      if(!b) return;
      (groups[b] = groups[b] || []).push({p, v});
    });
  });
  return Object.values(groups).filter(g=>g.length>1);
}

/* Products & Categories are shown as one screen: categories are the rows, and each
   expands to reveal the products inside it — the same place product editing already
   lands, so there's no second "category manager" screen duplicating this list. */
function renderProducts(){
  const qRaw = state.search.trim();
  const q = qRaw.length >= 3 ? qRaw.toLowerCase() : '';
  const lowOnly = state.productStockFilter === 'low';
  const filtering = !!q || lowOnly; // true whenever some filter narrows the list, beyond manual expand/collapse
  const matches = p => (!q || p.name.toLowerCase().includes(q) || p.id.toLowerCase().includes(q) || p.variants.some(v=>((v.barcode||'').toLowerCase().includes(q)))) && (!lowOnly || p.stock<=3);
  const lowStock = state.products.filter(p=>p.stock<=3).length;
  const conflicts = findBarcodeConflicts();

  // While a filter (search text or "low stock") is active, every category with a match is
  // shown expanded so results are visible without an extra tap. Otherwise, only the
  // manually-expanded category (if any) opens.
  const catsToRender = filtering
    ? state.categories.filter(c=> state.products.some(p=>p.category===c.name && matches(p)))
    : state.categories;
  // A text search still force-expands every matching category so results are visible right
  // away. The "Low stock" pill alone, with no search text, behaves like normal browsing —
  // categories stay collapsed until tapped, so the reveal chevron keeps working under it.
  const forceOpen = !!q;

  const catBlocks = catsToRender.map(c=>{
    const allInCat = state.products.filter(p=>p.category===c.name);
    const isOpen = forceOpen ? true : (c.id === state.expandedCategoryId);
    const shownProducts = isOpen
      ? [...allInCat].filter(matches).sort((a,b)=>a.name.localeCompare(b.name))
      : [];
    return `
      <div class="cat-block">
        <div class="list-row cat-row" data-id="${c.id}">
          <div class="row-swatch" style="background:${c.color}">${ICO.tag.replace('width="30" height="30"','width="17" height="17"')}</div>
          <div class="row-info">
            <div class="row-title">${esc(c.name)}</div>
            <div class="row-sub">${allInCat.length} product${allInCat.length===1?'':'s'}</div>
          </div>
          <button class="icon-btn cat-edit-btn" data-editid="${c.id}" style="background:var(--paper-dim);color:var(--ink)" title="Edit category">${ICO.edit}</button>
          <span class="chevron cat-chevron" style="transform:rotate(${isOpen?90:0}deg)">${ICO.chevron}</span>
        </div>
        ${isOpen ? `
          <div class="cat-products">
            ${shownProducts.length ? shownProducts.map(p=>`
              <div class="subproduct-row" data-pid="${esc(p.id)}">
                <div class="subproduct-top">
                  <div class="row-swatch" data-role="photo" style="width:32px;height:32px;border-radius:8px;overflow:hidden;flex-shrink:0">${variantVisualHTML(p.variants[0])}</div>
                  <div class="row-info"><div class="row-title" style="font-size:12.5px">${esc(p.name)}</div></div>
                  <div class="row-right">
                    <div class="amt" style="font-size:12.5px" data-role="price">${fmtMoney(p.variants[0].price)}</div>
                    <div class="tag"><span class="stock-pill ${stockClass(p.variants[0].stock)}" data-role="stock">${stockLabel(p.variants[0].stock)}</span></div>
                  </div>
                </div>
                <div class="variant-chip-row">
                  ${p.variants.map((v,i)=>`<button type="button" class="variant-chip ${i===0?'active':''}" data-vidx="${i}">${esc(v.name) || fmtMoney(v.price)}</button>`).join('')}
                </div>
              </div>
            `).join('') : `<div class="field-hint" style="padding:10px 16px 10px 44px">${filtering?'No matching products in this category.':'No products in this category yet.'}</div>`}
          </div>
        ` : ''}
      </div>
    `;
  }).join('');

  const html = `
    <div class="searchbar searchbar-sticky" id="prodSearchbar">
      <div class="search-input-wrap">${ICO.search}<input id="pSearch" placeholder="Search name, ID or barcode (3+ letters)" value="${esc(state.search)}"></div>
      <button class="scan-fab" id="pScanBtn" title="Scan to find product">${ICO.scan}</button>
      <button class="scan-fab" id="pAddBtn" title="Add product">${ICO.plus}</button>
    </div>
    <div class="stock-filter-row stock-filter-sticky" id="prodStockFilter">
      <button type="button" class="stock-filter-btn ${!lowOnly?'active':''}" data-filter="all">All products (${state.products.length})</button>
      <button type="button" class="stock-filter-btn ${lowOnly?'active':''}" data-filter="low">Low stock${lowStock?` (${lowStock})`:''}</button>
    </div>
    ${conflicts.length? `
    <div class="section-pad" style="padding-bottom:0">
      <div class="cloud-status" style="background:var(--red-tint);color:var(--red);border-radius:10px;padding:10px 12px;">
        <span class="dot" style="background:var(--red)"></span>
        <span>${conflicts.length} barcode${conflicts.length===1?'':'s'} shared by more than one product — scanning ${conflicts.length===1?'it':'them'} will only ever find one. Tap a product below to fix it.</span>
      </div>
      ${conflicts.map(g=>`
        <div style="padding:8px 2px 2px">
          ${g.map(({p,v})=>`<span class="list-row" data-id="${esc(p.id)}" style="display:inline-flex;padding:4px 10px;margin:2px 4px 2px 0;border:1px solid var(--red);border-radius:8px;background:var(--card);cursor:pointer;width:auto">${esc(p.name)}${v.name?` <span class="row-sub" style="margin-left:6px">${esc(v.name)}</span>`:''}</span>`).join('')}
        </div>
      `).join('')}
    </div>
    ` : ''}
    <div class="section-title"><span>Products &amp; categories</span><span class="count">${filtering ? `${catsToRender.length} match${catsToRender.length===1?'':'es'}` : `${state.categories.length} categories`}</span></div>
    ${catsToRender.length ? catBlocks : (filtering ? emptyState('box', lowOnly&&!q?'No low-stock products':'No matches', lowOnly&&!q?'Everything is comfortably stocked right now.':'Try a different search term.') : emptyState('box','No categories yet','Add a category to start organizing products.'))}
    <div class="section-pad">
      <button class="btn btn-outline" id="addCatBtn">${ICO.plus} Add category</button>
    </div>
  `;
  document.getElementById('screen').innerHTML = html;
  fitAllVariantChips(document.getElementById('screen'));
  const topbarEl = document.getElementById('topbar');
  const prodSearchbarEl = document.getElementById('prodSearchbar');
  const prodStockFilterEl = document.getElementById('prodStockFilter');
  // Stack the search/scan/add bar and the stock filter pills under the topbar so they float
  // together as one fixed header while the category list scrolls underneath.
  if(topbarEl){
    const topH = topbarEl.offsetHeight;
    if(prodSearchbarEl) prodSearchbarEl.style.top = topH + 'px';
    if(prodStockFilterEl) prodStockFilterEl.style.top = (topH + (prodSearchbarEl ? prodSearchbarEl.offsetHeight : 0)) + 'px';
  }
  document.getElementById('pSearch').addEventListener('input', e=>{
    state.search = e.target.value;
    preserveFocusRender('pSearch', renderProducts);
  });
  document.getElementById('pAddBtn').addEventListener('click', ()=>openProductForm(null));
  document.getElementById('pScanBtn').addEventListener('click', ()=>{
    openScanner(null, {
      onFound: (found)=> openProductForm(found.product.id),
      onNotFound: (code)=>{ toast('New barcode — add it as a product'); openProductForm(null, code); },
      hint: 'Scan to view a product, or add it as new'
    });
  });
  document.querySelectorAll('.stock-filter-btn').forEach(btn=>{
    btn.addEventListener('click', ()=>{
      state.productStockFilter = btn.dataset.filter;
      renderProducts();
    });
  });
  document.getElementById('addCatBtn').addEventListener('click', ()=>openCategoryForm(null));
  document.querySelectorAll('#screen .list-row:not(.cat-row)').forEach(el=>{
    el.addEventListener('click', ()=>openProductForm(el.dataset.id));
  });
  document.querySelectorAll('.cat-row').forEach(el=>{
    el.addEventListener('click', (e)=>{
      if(e.target.closest('.cat-edit-btn')) return;
      const id = el.dataset.id;
      state.expandedCategoryId = (state.expandedCategoryId === id) ? null : id;
      renderProducts();
    });
  });
  document.querySelectorAll('.cat-edit-btn').forEach(btn=>{
    btn.addEventListener('click', (e)=>{
      e.stopPropagation();
      openCategoryForm(btn.dataset.editid);
    });
  });
  document.querySelectorAll('.subproduct-row').forEach(el=>{
    el.addEventListener('click', ()=> openProductForm(el.dataset.pid));
  });
  // Tapping a variant chip previews that variant's own price/stock instead of navigating
  // into the product editor — it just swaps which variant's numbers are shown on the right.
  document.querySelectorAll('.subproduct-row').forEach(row=>{
    const pid = row.dataset.pid;
    const p = state.products.find(x=>x.id===pid);
    if(!p) return;
    row.querySelectorAll('.variant-chip').forEach(btn=>{
      btn.addEventListener('click', e=>{
        e.stopPropagation();
        const v = p.variants[Number(btn.dataset.vidx)];
        if(!v) return;
        row.querySelectorAll('.variant-chip').forEach(c=>c.classList.remove('active'));
        btn.classList.add('active');
        const priceEl = row.querySelector('[data-role="price"]');
        const stockEl = row.querySelector('[data-role="stock"]');
        const photoEl = row.querySelector('[data-role="photo"]');
        if(priceEl) priceEl.textContent = fmtMoney(v.price);
        if(stockEl){ stockEl.textContent = stockLabel(v.stock); stockEl.className = 'stock-pill ' + stockClass(v.stock); }
        if(photoEl) photoEl.innerHTML = variantVisualHTML(v);
      });
    });
  });
}


function defaultVariant(seedIdx){
  return { id: uid('VAR-'), name:'', cost:0, price:0, stock:0, barcode:'',
    photo:null, icon: defaultIcon(seedIdx||0),
    lowStockAlert:true, autoUpdateStock:true, preventOOS:false,
    trackExpiry:false, expiryDate:'', addTax:false, taxRate:0, hasNotes:false, internalNotes:'' };
}
// Collapsed summary row shown in the product form's variant list (matches the "Manage Item"
// row layout from the reference app) — tapping the price/cost/stock strip opens the full
// detail editor for that one variant; tapping the thumbnail opens the photo/shape picker.
function variantRowHTML(v, idx){
  return `
    <div class="variant-row" data-idx="${idx}">
      <div class="variant-row-top">
        <div class="variant-thumb" data-action="thumb">${variantVisualHTML(v)}</div>
        <div class="variant-name-display" data-action="expand">${v.name ? esc(v.name) : '<span class="vname-placeholder">Enter variant name</span>'}</div>
        <button type="button" class="btn variant-history-btn">History</button>
        <button type="button" class="icon-btn variant-row-delete" style="background:var(--red-tint);color:var(--red);width:26px;height:26px;flex-shrink:0" title="Delete variant">${ICO.trash}</button>
      </div>
      <div class="variant-row-summary" data-action="expand">
        <div class="vrs-col"><span class="vrs-label">Selling price</span><div class="vrs-val">${fmtMoney(v.price)}</div></div>
        <div class="vrs-col"><span class="vrs-label">Cost price</span><div class="vrs-val">${fmtMoney(v.cost)}</div></div>
        <div class="vrs-col"><span class="vrs-label">Stock</span><div class="vrs-val ${v.stock<=3?'vrs-low':''}">${v.stock}</div></div>
        <div class="vrs-chev">›</div>
      </div>
    </div>
  `;
}
function openProductForm(productId, prefillBarcode){
  const editing = !!productId;
  const p = editing ? state.products.find(x=>x.id===productId) : { id:'', name:'', category: state.categories[0]?.name||'' };
  let variants = editing
    ? p.variants.map(v=>({...v}))
    : [ prefillBarcode ? {...defaultVariant(0), barcode: prefillBarcode} : defaultVariant(0) ];
  // remembers each existing variant's stock as of opening the form, so a save that changes it
  // can be logged as a stock movement (shows up in that variant's History)
  const origStockById = {};
  if(editing) p.variants.forEach(v=>{ origStockById[v.id] = v.stock; });
  const root = document.getElementById('overlayRoot');
  root.innerHTML = `
    <div class="overlay">
      <div class="overlay-header">
        <button class="icon-btn" style="background:transparent;color:var(--ink)" id="pfBack">${ICO.back}</button>
        <h2>${editing?'Edit product':'New product'}</h2>
        ${editing?`<button class="icon-btn" style="background:transparent;color:var(--red)" id="pfDelete">${ICO.trash}</button>`:'<span style="width:36px"></span>'}
      </div>
      <div class="overlay-body">
        <div class="field">
          <label>Product name</label>
          <input id="pfName" value="${esc(p.name)}" placeholder="e.g. Nivea Cocoa">
          <div id="pfNameDupHint" class="field-hint hidden" style="color:var(--red)"></div>
        </div>
        <div class="field"><label>Category</label>
          <select id="pfCategory">${state.categories.map(c=>`<option value="${esc(c.name)}" ${c.name===p.category?'selected':''}>${esc(c.name)}</option>`).join('')}<option value="__new__">+ Add new category…</option></select>
        </div>
        <div class="section-title" style="padding-top:4px"><span>Variants</span></div>
        <div class="field-hint" style="padding:0 16px 8px">Each variant is a size or type this product comes in — its own photo (or shape), price, stock and barcode. Tap a variant's price row to edit it.</div>
        <div id="pfVariantsWrap"></div>
        <div class="field">
          <button type="button" class="btn btn-outline" id="pfAddVariant">${ICO.plus} Add variant</button>
        </div>
      </div>
      <div class="overlay-footer">
        <button class="btn btn-primary" id="pfSave">${editing?'Update product':'Add product'}</button>
      </div>
    </div>
  `;
  document.getElementById('pfBack').onclick = closeOverlay;

  const variantsWrap = document.getElementById('pfVariantsWrap');
  const renderVariantsUI = ()=>{
    variantsWrap.innerHTML = variants.map((v,i)=>variantRowHTML(v, i)).join('');
  };
  renderVariantsUI();

  // One delegated listener on the wrapper handles every variant row, including ones
  // added later — re-rendering the wrapper doesn't lose these bindings.
  variantsWrap.addEventListener('click', e=>{
    const row = e.target.closest('.variant-row');
    if(!row) return;
    const idx = Number(row.dataset.idx);
    const v = variants[idx];
    if(e.target.closest('[data-action="thumb"]')){
      openVariantPhotoSheet(v, renderVariantsUI);
    } else if(e.target.closest('.variant-history-btn')){
      openVariantHistory(editing?p:null, v);
    } else if(e.target.closest('.variant-row-delete')){
      if(variants.length<=1){ toast('A product needs at least one variant'); return; }
      confirmModal('Delete this variant?', `"${v.name||'This variant'}" will be removed.`, ()=>{
        variants.splice(idx,1);
        renderVariantsUI();
      });
    } else if(e.target.closest('[data-action="expand"]')){
      openVariantDetailEditor(idx, variants, editing, p, renderVariantsUI, trySaveProduct);
    }
  });
  document.getElementById('pfAddVariant').onclick = ()=>{
    variants.push(defaultVariant(variants.length));
    renderVariantsUI();
  };

  const pfNameInput = document.getElementById('pfName');
  const pfNameDupHint = document.getElementById('pfNameDupHint');
  const checkDupName = ()=>{
    const dup = findDuplicateProductName(pfNameInput.value, editing ? p.id : null);
    if(dup){
      pfNameDupHint.textContent = `Already in your catalog as "${dup.name}" (${dup.id}) — edit that product instead of adding a duplicate.`;
      pfNameDupHint.classList.remove('hidden');
      pfNameInput.style.borderColor = 'var(--red)';
    } else {
      pfNameDupHint.classList.add('hidden');
      pfNameInput.style.borderColor = '';
    }
    return dup;
  };
  pfNameInput.addEventListener('input', checkDupName);
  checkDupName();

  const pfCategorySelect = document.getElementById('pfCategory');
  let lastRealCategory = pfCategorySelect.value === '__new__' ? (state.categories[0]?.name || '') : pfCategorySelect.value;
  pfCategorySelect.addEventListener('change', ()=>{
    if(pfCategorySelect.value !== '__new__') { lastRealCategory = pfCategorySelect.value; return; }
    openQuickAddCategoryModal((newName)=>{
      // rebuild the option list so the new category shows up, then select it
      pfCategorySelect.innerHTML = state.categories.map(c=>`<option value="${esc(c.name)}" ${c.name===newName?'selected':''}>${esc(c.name)}</option>`).join('') + `<option value="__new__">+ Add new category…</option>`;
      lastRealCategory = newName;
    }, ()=>{
      pfCategorySelect.value = lastRealCategory; // cancelled — revert to whatever was selected before
    });
  });

  if(editing){
    document.getElementById('pfDelete').onclick = ()=>{
      confirmModal('Delete product?', `"${p.name}" will be permanently removed from your catalog.`, ()=>{
        state.products = state.products.filter(x=>x.id!==p.id);
        saveProducts(); syncDelete('oyes_products', p.id); closeOverlay(); renderProducts();
      });
    };
  }
  // Shared save routine: builds the final product from the current form + variants state and
  // persists it. Used by the "Add product" footer button (new-product flow) and, when editing,
  // by the "Save changes" button that now lives on the variant detail page instead of here.
  // Returns true on success, false if validation failed (a toast has already explained why).
  function trySaveProduct(opts){
    const closeForm = !opts || opts.closeForm !== false;
    const name = document.getElementById('pfName').value.trim();
    if(!name){ toast('Enter a product name'); return false; }
    if(checkDupName()){ toast('That product name is already in use'); return false; }
    if(!variants.length){ toast('Add at least one variant'); return false; }
    const category = document.getElementById('pfCategory').value;
    const targetId = editing ? p.id : 'PROD-' + (Math.max(0, ...state.products.map(x=>parseInt((x.id.match(/\d+/)||[0])[0])||0)) + 1);

    // catch two variants (on this product, or shared with another) claiming the same barcode
    const seenHere = new Set();
    for(const v of variants){
      const b = (v.barcode||'').trim().toLowerCase();
      if(b){
        if(seenHere.has(b)){ toast('Two of this product\'s variants share the same barcode'); return false; }
        seenHere.add(b);
      }
      const dup = findDuplicateBarcode(v.barcode, editing?p.id:null, v.id);
      if(dup){ toast(`Barcode already used by "${dup.product.name}${dup.variant.name?' '+dup.variant.name:''}"`); return false; }
    }

    const finalVariants = variants.map((v,i)=>({
      id: v.id, name: v.name.trim(),
      cost: Number(v.cost)||0, price: Number(v.price)||0, stock: Number(v.stock)||0,
      barcode: (v.barcode||'').trim() || (i===0 ? targetId : `${targetId}-${i+1}`),
      photo: v.photo||null, icon: v.photo ? null : (v.icon||defaultIcon(i)),
      lowStockAlert: !!v.lowStockAlert, autoUpdateStock: v.autoUpdateStock!==false, preventOOS: !!v.preventOOS,
      trackExpiry: !!v.trackExpiry, expiryDate: v.expiryDate||'', addTax: !!v.addTax, taxRate: Number(v.taxRate)||0,
      hasNotes: !!v.hasNotes, internalNotes: v.internalNotes||'',
    }));

    // A manual stock edit (changing "Stock available" on an existing variant) is logged as a
    // restock/adjustment movement so it shows up alongside sales in that variant's History.
    if(editing){
      const who = currentUserInfo();
      finalVariants.forEach(v=>{
        const before = origStockById[v.id];
        if(before === undefined) return; // brand-new variant added in this edit — nothing to log yet
        const delta = v.stock - before;
        if(delta === 0) return;
        state.stockLog.push({
          id: 'STK-'+Date.now()+'-'+Math.random().toString(36).slice(2,7),
          productId: targetId, variantId: v.id,
          delta, resultingStock: v.stock,
          date: new Date().toISOString(),
          userName: who.name, userEmail: who.email,
        });
      });
      saveStockLog();
    }
    // Keep the "before" snapshot current so a later save in this same form session (e.g.
    // reopening the variant editor again) logs only what changed since THIS save, not
    // everything since the form was first opened.
    finalVariants.forEach(v=>{ origStockById[v.id] = v.stock; });

    if(editing){
      Object.assign(p, { name, category, variants: finalVariants, updatedAt:new Date().toISOString() });
      syncProductFromVariants(p);
    } else {
      const newProduct = { id:targetId, name, category, variants: finalVariants, updatedAt:new Date().toISOString() };
      syncProductFromVariants(newProduct);
      state.products.push(newProduct);
    }
    saveProducts(); renderProducts();
    if(closeForm) closeOverlay();
    toast(editing?'Product updated':'Product added');
    return true;
  }

  document.getElementById('pfSave').onclick = ()=>trySaveProduct();
}

/* ---------------- variant detail editor (full-screen, stacks on top of the product form) ---------------- */
function openVariantDetailEditor(idx, variants, editing, p, onClose, onSaveProduct){
  const v = variants[idx];
  const root2 = document.getElementById('overlayRoot2');
  const render = ()=>{
    const dup = findDuplicateBarcode(v.barcode, editing?p.id:null, v.id);
    root2.innerHTML = `
      <div class="overlay">
        <div class="overlay-header">
          <button class="icon-btn" style="background:transparent;color:var(--ink)" id="vdBack">${ICO.back}</button>
          <h2>${esc(v.name)||'Variant'}</h2>
          <button class="icon-btn" style="background:transparent;color:var(--red)" id="vdDelete">${ICO.trash}</button>
        </div>
        <div class="overlay-body">
          <div class="field">
            <label>Photo</label>
            <button type="button" class="variant-detail-photo" id="vdPhotoBtn">
              <div class="variant-thumb variant-thumb-lg">${variantVisualHTML(v)}</div>
              <div class="variant-thumb-edit-badge">${ICO.cam.replace(/width="30" height="30"/,'width="14" height="14"')}</div>
            </button>
          </div>
          <div class="field"><label>Variant name</label><input id="vdName" value="${esc(v.name)}" placeholder="e.g. 80g, Small, Regular"></div>
          <div class="field-row">
            <div class="field"><label>Cost price</label><input type="number" min="0" id="vdCost" value="${v.cost}"></div>
            <div class="field"><label>Selling price</label><input type="number" min="0" id="vdPrice" value="${v.price}"></div>
          </div>
          <div class="field-row">
            <div class="field"><label>Stock available</label><input type="number" id="vdStock" value="${v.stock}"></div>
            <div class="field"><label>Profit per item</label><input disabled id="vdProfit" value="${fmtMoney(unitProfit(v.cost,v.price))}"></div>
          </div>
          <div class="field check-row">
            <label class="check-label"><input type="checkbox" id="vdLowStock" ${v.lowStockAlert?'checked':''}> Low stock alerts</label>
            <label class="check-label"><input type="checkbox" id="vdAutoUpdate" ${v.autoUpdateStock?'checked':''}> Auto-update stock on item sales</label>
            <label class="check-label"><input type="checkbox" id="vdPreventOOS" ${v.preventOOS?'checked':''}> Prevent sale when out of stock</label>
          </div>
          <div class="field">
            <label>Barcode</label>
            <div class="hstack">
              <input id="vdBarcode" style="flex:1" value="${esc(v.barcode)}" placeholder="Scan, type, or generate">
              <button type="button" class="icon-btn" id="vdScanBarcode" style="background:var(--teal);color:#fff">${ICO.scan}</button>
            </div>
            <div class="field-hint" id="vdBarcodeHint" style="${dup?'color:var(--red)':''}">${dup?`Already used by "${dup.product.name}${dup.variant.name?' '+dup.variant.name:''}"`:'Leave blank to fall back to the product ID.'}</div>
            <button type="button" class="btn btn-ghost" id="vdGenBarcode" style="margin-top:8px">Generate barcode</button>
          </div>
        </div>
        <div class="overlay-footer">
          <button class="btn btn-primary" id="vdDone">${editing?'Save changes':'Done'}</button>
        </div>
      </div>
    `;
    bind();
  };
  const close = ()=>{ root2.innerHTML=''; onClose(); };
  const bind = ()=>{
    document.getElementById('vdBack').onclick = close;
    document.getElementById('vdDone').onclick = editing ? ()=>{
      const saved = onSaveProduct({ closeForm:false });
      if(saved) close(); // returns to the edit-product page, which onClose (renderVariantsUI) refreshes with the updated variant
    } : close;
    document.getElementById('vdDelete').onclick = ()=>{
      if(variants.length<=1){ toast('A product needs at least one variant'); return; }
      confirmModal('Delete this variant?', `"${v.name||'This variant'}" will be removed.`, ()=>{
        const pos = variants.indexOf(v);
        if(pos>-1) variants.splice(pos,1);
        close();
      });
    };
    document.getElementById('vdPhotoBtn').onclick = ()=>openVariantPhotoSheet(v, render);
    document.getElementById('vdName').addEventListener('input', e=>{
      v.name = e.target.value;
      document.querySelector('#overlayRoot2 h2').textContent = v.name || 'Variant';
    });
    const updateProfit = ()=>{ document.getElementById('vdProfit').value = fmtMoney(unitProfit(v.cost, v.price)); };
    document.getElementById('vdCost').addEventListener('input', e=>{ v.cost=parseFloat(e.target.value)||0; updateProfit(); });
    document.getElementById('vdPrice').addEventListener('input', e=>{ v.price=parseFloat(e.target.value)||0; updateProfit(); });
    document.getElementById('vdStock').addEventListener('input', e=>{ v.stock=parseInt(e.target.value)||0; });
    document.getElementById('vdLowStock').addEventListener('change', e=>{ v.lowStockAlert=e.target.checked; });
    document.getElementById('vdAutoUpdate').addEventListener('change', e=>{ v.autoUpdateStock=e.target.checked; });
    document.getElementById('vdPreventOOS').addEventListener('change', e=>{ v.preventOOS=e.target.checked; });
    const barcodeInput = document.getElementById('vdBarcode');
    const barcodeHint = document.getElementById('vdBarcodeHint');
    const checkDup = ()=>{
      const d = findDuplicateBarcode(barcodeInput.value, editing?p.id:null, v.id);
      barcodeHint.textContent = d ? `Already used by "${d.product.name}${d.variant.name?' '+d.variant.name:''}"` : 'Leave blank to fall back to the product ID.';
      barcodeHint.style.color = d ? 'var(--red)' : '';
    };
    barcodeInput.addEventListener('input', e=>{ v.barcode=e.target.value; checkDup(); });
    document.getElementById('vdScanBarcode').onclick = ()=>openScanner((code)=>{ v.barcode=code; barcodeInput.value=code; checkDup(); });
    document.getElementById('vdGenBarcode').onclick = ()=>{ v.barcode=generateVariantBarcode(); barcodeInput.value=v.barcode; checkDup(); };
  };
  render();
}
/* ---------------- variant photo action sheet: real photo, or a shape+colour fallback ---------------- */
function openVariantPhotoSheet(v, onChange){
  const root = document.getElementById('modalRoot');
  const hasPhoto = !!v.photo;
  root.innerHTML = `
    <div class="modal-back" id="mbPhotoSheet">
      <div class="modal-sheet">
        <div class="modal-handle"></div>
        <div class="list-row" id="vpsShape" style="cursor:pointer"><div class="row-info"><div class="row-title">Pick shape and colour</div></div></div>
        <div class="list-row" id="vpsGallery" style="cursor:pointer"><div class="row-info"><div class="row-title">Upload from gallery</div></div></div>
        <div class="list-row" id="vpsCamera" style="cursor:pointer"><div class="row-info"><div class="row-title">Take photo</div></div></div>
        ${hasPhoto?`<div class="list-row" id="vpsView" style="cursor:pointer"><div class="row-info"><div class="row-title">View photo</div></div></div>`:''}
        ${hasPhoto?`<div class="list-row" id="vpsRemove" style="cursor:pointer"><div class="row-info"><div class="row-title" style="color:var(--red)">Remove photo</div></div></div>`:''}
      </div>
    </div>`;
  const close = ()=>{ root.innerHTML=''; };
  document.getElementById('mbPhotoSheet').addEventListener('click', e=>{ if(e.target.id==='mbPhotoSheet') close(); });
  document.getElementById('vpsShape').onclick = ()=>{ close(); openShapeColorPicker(v, onChange); };
  document.getElementById('vpsGallery').onclick = ()=>{
    close();
    const inp = document.createElement('input'); inp.type='file'; inp.accept='image/*';
    inp.onchange = async ()=>{
      const file = inp.files && inp.files[0]; if(!file) return;
      try{ toast('Processing photo…'); v.photo = await readAndResizeImage(file); v.icon=null; onChange(); }
      catch(err){ toast('Could not load that photo'); }
    };
    inp.click();
  };
  document.getElementById('vpsCamera').onclick = ()=>{ close(); openPhotoCapture((dataUrl)=>{ v.photo=dataUrl; v.icon=null; onChange(); }); };
  if(hasPhoto){
    document.getElementById('vpsView').onclick = ()=>{ close(); openImageViewer(v.photo); };
    document.getElementById('vpsRemove').onclick = ()=>{ close(); v.photo=null; if(!v.icon) v.icon=defaultIcon(0); onChange(); };
  }
}
function openImageViewer(src){
  const root = document.getElementById('modalRoot');
  root.innerHTML = `<div class="modal-back" id="mbImgView" style="align-items:center;justify-content:center;padding:24px"><img src="${src}" style="max-width:100%;max-height:80vh;border-radius:12px" alt=""></div>`;
  document.getElementById('mbImgView').onclick = ()=>{ root.innerHTML=''; };
}
function openShapeColorPicker(v, onChange){
  const root = document.getElementById('modalRoot');
  let chosenColor = (v.icon && v.icon.color) || CATEGORY_PALETTE[0];
  const render = ()=>{
    root.innerHTML = `
      <div class="modal-back" id="mbShapeColor">
        <div class="modal-sheet">
          <div class="modal-handle"></div>
          <div class="section-title" style="padding-top:0">Pick a shape and colour</div>
          <div class="field-hint" style="padding:0 16px 10px">Used when this variant doesn't have a real photo.</div>
          <div class="field-hint" style="padding:0 16px 6px;font-weight:600;color:var(--ink)">Colour</div>
          <div class="swatch-grid" id="colorGrid">
            ${CATEGORY_PALETTE.map(c=>`<button type="button" class="swatch-color ${c===chosenColor?'selected':''}" data-color="${c}" style="background:${c}">${c===chosenColor?'✓':''}</button>`).join('')}
          </div>
          <div class="field-hint" style="padding:14px 16px 6px;font-weight:600;color:var(--ink)">Shape</div>
          <div class="swatch-grid" id="shapeGrid">
            ${ICON_SHAPES.map(s=>`<button type="button" class="swatch-shape" data-shape="${s}">${iconShapeSVG(s, chosenColor)}</button>`).join('')}
          </div>
        </div>
      </div>`;
    document.getElementById('mbShapeColor').addEventListener('click', e=>{ if(e.target.id==='mbShapeColor') root.innerHTML=''; });
    document.querySelectorAll('.swatch-color').forEach(b=>b.onclick=()=>{ chosenColor=b.dataset.color; render(); });
    document.querySelectorAll('.swatch-shape').forEach(b=>b.onclick=()=>{
      v.icon = { shape:b.dataset.shape, color:chosenColor }; v.photo=null;
      root.innerHTML=''; onChange();
    });
  };
  render();
}
/* ---------------- per-variant sales history (reads variantId off past transaction items) ---------------- */
// Best-effort display name/email for whoever is signed in, used to attribute stock changes.
function currentUserInfo(){
  const profile = state.auth.profile, user = state.auth.user;
  return {
    name: (profile && profile.full_name) || (user && user.email) || 'You',
    email: (user && user.email) || '',
  };
}
// Combines this variant's sales (from transactions) and stock additions/adjustments
// (from state.stockLog) into one "sold vs added" timeline with a running stock balance
// after each event — mirroring the reference app's variant history screen.
function openVariantHistory(p, v){
  const root = document.getElementById('modalRoot');
  const events = [];
  state.transactions.forEach(t=>{
    (t.items||[]).forEach(it=>{
      if(it.variantId !== v.id) return;
      const isReturn = t.type==='return';
      events.push({
        kind: isReturn ? 'added' : 'sold',
        qty: it.qty,
        date: t.date,
        ref: t.id,
        label: isReturn ? 'Returned' : 'Sold',
        userName: t.userName || '', userEmail: t.userEmail || '',
      });
    });
  });
  state.stockLog.forEach(s=>{
    if(s.variantId !== v.id) return;
    events.push({
      kind: s.delta >= 0 ? 'added' : 'sold',
      qty: Math.abs(s.delta),
      date: s.date,
      ref: null,
      label: s.delta >= 0 ? 'Added' : 'Removed',
      userName: s.userName || '', userEmail: s.userEmail || '',
    });
  });
  events.sort((a,b)=> new Date(b.date) - new Date(a.date)); // newest first, like the reference screen

  // Walk newest→oldest starting from the variant's true current stock, so each row shows the
  // running balance immediately after that event happened.
  let runningBalance = v.stock;
  const rows = events.map(ev=>{
    const balanceAfter = runningBalance;
    runningBalance = ev.kind==='sold' ? runningBalance + ev.qty : runningBalance - ev.qty;
    return { ...ev, balanceAfter };
  });

  const fmtWhen = (iso)=>{
    const d = new Date(iso);
    const date = d.toLocaleDateString('en-GB', { day:'2-digit', month:'short', year:'numeric' });
    const time = d.toLocaleTimeString('en-US', { hour:'2-digit', minute:'2-digit' });
    return `${date} - ${time}`;
  };

  root.innerHTML = `
    <div class="modal-back" id="mbVariantHistory">
      <div class="modal-sheet">
        <div class="modal-handle"></div>
        <div class="section-title" style="padding-top:0">${esc(v.name||'Variant')} — stock history</div>
        ${rows.length ? `<div class="history-list">
          ${rows.map((r,i)=>`
            <div class="history-item">
              <div class="history-rail"><div class="history-dot"></div></div>
              <div class="history-card ${r.kind}">
                <div class="hc-info">
                  <div class="hc-title">${r.qty} ${r.label}</div>
                  ${r.ref ? `<div class="hc-sub">From #${esc(r.ref)}</div>` : ''}
                  <div class="hc-sub">${fmtWhen(r.date)}${r.userName?`, ${esc(r.userName)}`:''}</div>
                  ${r.userEmail ? `<div class="hc-sub">${esc(r.userEmail)}</div>` : ''}
                </div>
                <div class="hc-bal">=${r.balanceAfter}</div>
              </div>
            </div>
          `).join('')}
        </div>` : `<div class="field-hint" style="padding:0 16px 16px">No stock activity recorded for this variant yet.</div>`}
      </div>
    </div>`;
  document.getElementById('mbVariantHistory').addEventListener('click', e=>{ if(e.target.id==='mbVariantHistory') root.innerHTML=''; });
}

/* =========================================================================
   RENDER: CATEGORIES
   ========================================================================= */
function openQuickAddCategoryModal(onCreated, onCancelled){
  let chosenColor = CATEGORY_PALETTE[state.categories.length % CATEGORY_PALETTE.length];
  const root = document.getElementById('modalRoot');
  root.innerHTML = `
    <div class="modal-back" id="mbQuickCat">
      <div class="modal-sheet">
        <div class="modal-handle"></div>
        <div class="section-title" style="padding-top:0">New category</div>
        <div class="field" style="padding-top:0"><label>Category name</label><input id="qcName" placeholder="e.g. Snacks"></div>
        <div class="field"><label>Color</label></div>
        <div class="swatch-row" id="qcSwatches">
          ${CATEGORY_PALETTE.map(col=>`<div class="swatch ${col===chosenColor?'selected':''}" data-color="${col}" style="background:${col}"></div>`).join('')}
        </div>
        <div class="field"><div class="btn-row">
          <button class="btn btn-ghost" id="qcCancel">Cancel</button>
          <button class="btn btn-primary" id="qcSave">Add category</button>
        </div></div>
      </div>
    </div>`;
  document.getElementById('mbQuickCat').addEventListener('click', e=>{ if(e.target.id==='mbQuickCat'){ root.innerHTML=''; if(onCancelled) onCancelled(); } });
  document.querySelectorAll('#qcSwatches .swatch').forEach(sw=>{
    sw.onclick = ()=>{ document.querySelectorAll('#qcSwatches .swatch').forEach(s=>s.classList.remove('selected')); sw.classList.add('selected'); chosenColor = sw.dataset.color; };
  });
  document.getElementById('qcCancel').onclick = ()=>{ root.innerHTML=''; if(onCancelled) onCancelled(); };
  document.getElementById('qcSave').onclick = ()=>{
    const name = document.getElementById('qcName').value.trim();
    if(!name){ toast('Enter a category name'); return; }
    if(state.categories.some(x=>x.name.toLowerCase()===name.toLowerCase())){ toast('Category already exists'); return; }
    const newCat = { id:'cat_'+Date.now(), name, color:chosenColor };
    state.categories.push(newCat);
    saveCategories();
    root.innerHTML='';
    toast('Category added');
    if(onCreated) onCreated(name);
  };
  document.getElementById('qcName').focus();
}

function openCategoryForm(catId){
  const editing = !!catId;
  const c = editing ? state.categories.find(x=>x.id===catId) : { id:'', name:'', color:CATEGORY_PALETTE[state.categories.length % CATEGORY_PALETTE.length] };
  const productCount = editing ? state.products.filter(p=>p.category===c.name).length : 0;
  let chosenColor = c.color;
  const root = document.getElementById('overlayRoot');
  root.innerHTML = `
    <div class="overlay">
      <div class="overlay-header">
        <button class="icon-btn" style="background:transparent;color:var(--ink)" id="cfBack">${ICO.back}</button>
        <h2>${editing?'Edit category':'New category'}</h2>
        ${editing?`<button class="icon-btn" style="background:transparent;color:var(--red)" id="cfDelete">${ICO.trash}</button>`:'<span style="width:36px"></span>'}
      </div>
      <div class="overlay-body">
        <div class="field"><label>Category name</label><input id="cfName" value="${esc(c.name)}" placeholder="e.g. Skin Care"></div>
        <div class="field"><label>Color</label></div>
        <div class="swatch-row" id="cfSwatches">
          ${CATEGORY_PALETTE.map(col=>`<div class="swatch ${col===chosenColor?'selected':''}" data-color="${col}" style="background:${col}"></div>`).join('')}
        </div>
        ${editing?`<div class="field field-hint">${productCount} product${productCount===1?'':'s'} currently use this category.</div>`:''}
      </div>
      <div class="overlay-footer">
        <button class="btn btn-primary" id="cfSave">${editing?'Save changes':'Add category'}</button>
      </div>
    </div>
  `;
  document.getElementById('cfBack').onclick = closeOverlay;
  document.querySelectorAll('#cfSwatches .swatch').forEach(sw=>{
    sw.onclick = ()=>{ document.querySelectorAll('#cfSwatches .swatch').forEach(s=>s.classList.remove('selected')); sw.classList.add('selected'); chosenColor = sw.dataset.color; };
  });
  if(editing){
    document.getElementById('cfDelete').onclick = ()=>{
      if(productCount>0){
        openReassignModal(c, ()=>{ closeOverlay(); renderProducts(); });
      } else {
        confirmModal('Delete category?', `"${c.name}" will be removed.`, ()=>{
          state.categories = state.categories.filter(x=>x.id!==c.id);
          saveCategories(); syncDelete('oyes_categories', c.id); closeOverlay(); renderProducts();
        });
      }
    };
  }
  document.getElementById('cfSave').onclick = ()=>{
    const name = document.getElementById('cfName').value.trim();
    if(!name){ toast('Enter a category name'); return; }
    if(editing){
      const oldName = c.name;
      c.name = name; c.color = chosenColor;
      if(oldName !== name){
        state.products.forEach(p=>{ if(p.category===oldName) p.category = name; });
        saveProducts();
      }
    } else {
      if(state.categories.some(x=>x.name.toLowerCase()===name.toLowerCase())){ toast('Category already exists'); return; }
      state.categories.push({ id:'cat_'+Date.now(), name, color:chosenColor });
    }
    saveCategories(); closeOverlay(); renderProducts(); toast(editing?'Category updated':'Category added');
  };
}

function openReassignModal(cat, onDone){
  const others = state.categories.filter(c=>c.id!==cat.id);
  const root = document.getElementById('modalRoot');
  root.innerHTML = `
    <div class="modal-back" id="mbReassign">
      <div class="modal-sheet">
        <div class="modal-handle"></div>
        <div class="section-title" style="padding-top:0">Move products first</div>
        <div class="field field-hint" style="padding-top:0">"${esc(cat.name)}" has products in it. Choose where to move them before deleting this category.</div>
        <div class="field"><label>Move products to</label>
          <select id="reassignSel">${others.length? others.map(o=>`<option value="${esc(o.name)}">${esc(o.name)}</option>`).join('') : `<option value="Uncategorized">Uncategorized</option>`}</select>
        </div>
        <div class="field"><div class="btn-row">
          <button class="btn btn-ghost" id="reassignCancel">Cancel</button>
          <button class="btn btn-danger" id="reassignConfirm">Move & delete category</button>
        </div></div>
      </div>
    </div>`;
  document.getElementById('mbReassign').addEventListener('click', e=>{ if(e.target.id==='mbReassign') root.innerHTML=''; });
  document.getElementById('reassignCancel').onclick = ()=>root.innerHTML='';
  document.getElementById('reassignConfirm').onclick = ()=>{
    const target = document.getElementById('reassignSel').value;
    if(target==='Uncategorized' && !state.categories.some(c=>c.name==='Uncategorized')){
      state.categories.push({id:'cat_unc_'+Date.now(), name:'Uncategorized', color:'#9C9382'});
    }
    state.products.forEach(p=>{ if(p.category===cat.name) p.category = target; });
    state.categories = state.categories.filter(c=>c.id!==cat.id);
    saveProducts(); saveCategories(); syncDelete('oyes_categories', cat.id);
    root.innerHTML='';
    toast('Products moved, category deleted');
    onDone();
  };
}

/* =========================================================================
   RENDER: HISTORY
   ========================================================================= */
function filteredTransactions(){
  const { start, end } = state.historyFilter;
  if(!start && !end) return state.transactions;
  return state.transactions.filter(t=>{
    const d = new Date(t.date);
    if(start && d < new Date(start + 'T00:00:00')) return false;
    if(end && d > new Date(end + 'T23:59:59')) return false;
    return true;
  });
}

/* Total profit across a set of transactions: for each sold line, quantity × per-item profit
   (sale price minus cost at the time of sale, or 0 if no cost was recorded) — Personal Use
   transactions are excluded, matching how revenue totals already treat them. */
function totalProfit(transactions){
  return transactions
    .filter(t => t.type !== 'Personal Use')
    .reduce((sum, t) => sum + t.items.reduce((s, it) => s + unitProfit(it.unitCost, it.unitPrice) * it.qty, 0), 0);
}

function renderHistory(){
  const list = filteredTransactions();
  const isDefaultMonth = state.historyFilter.start === firstOfCurrentMonth() && !state.historyFilter.end;
  const isCustomFiltered = !isDefaultMonth && !!(state.historyFilter.start || state.historyFilter.end);
  const totalRevenue = list.filter(t=>t.type!=='Personal Use').reduce((s,t)=>s+t.total,0);
  const statLabel = isCustomFiltered ? 'Filtered sales' : "This month's sales";
  const html = `
    <div class="section-pad hist-filter-block" style="padding-bottom:0">
      <div class="field-row">
        <div class="field"><label>From</label><input type="date" id="histStart" value="${esc(state.historyFilter.start||'')}"></div>
        <div class="field"><label>To</label><input type="date" id="histEnd" value="${esc(state.historyFilter.end||'')}"></div>
      </div>
      <div class="field"><div class="btn-row">
        <button class="btn btn-ghost" id="histClearBtn">Clear</button>
        <button class="btn btn-primary" id="histApplyBtn">Apply filter</button>
      </div></div>
    </div>
    <div class="stat-strip stat-strip-sticky stat-strip-compact stat-strip-history" id="histStatStrip">
      <div class="stat-card"><div class="label">${statLabel}</div><div class="value">${fmtMoney(totalRevenue)}</div></div>
      <div class="stat-card"><div class="label">Transactions</div><div class="value">${list.length}</div></div>
      ${isAdmin() ? `<div class="stat-card"><div class="label">Total profit</div><div class="value">${fmtMoney(totalProfit(list))}</div></div>` : ''}
    </div>
    <div class="section-title"><span>Transaction history</span></div>
    ${list.length? list.map(t=>`
      <div class="list-row hist-row" data-id="${esc(t.id)}">
        <div class="row-swatch" style="background:${t.type==='Personal Use'?'var(--ink-faint)':'var(--teal)'}">${ICO.receipt.replace('width="16" height="16"','width="17" height="17"')}</div>
        <div class="row-info">
          <div class="row-title">${esc(t.id)}</div>
          <div class="row-sub">${new Date(t.date).toLocaleString()} · ${esc(t.type)}</div>
        </div>
        <div class="row-right">
          <div class="amt">${fmtMoney(t.total)}</div>
          <div class="tag">${t.items.length} item${t.items.length===1?'':'s'}</div>
        </div>
        <span class="chevron">${ICO.chevron}</span>
      </div>
    `).join('') : emptyState('clock', 'No sales in this range', 'Try a different date range.')}
  `;
  document.getElementById('screen').innerHTML = html;
  const histTopbarEl = document.getElementById('topbar');
  const histStatStripEl = document.getElementById('histStatStrip');
  // KPIs float below the topbar once the date-filter panel above them scrolls out of view.
  if(histTopbarEl && histStatStripEl) histStatStripEl.style.top = histTopbarEl.offsetHeight + 'px';
  document.getElementById('histApplyBtn').addEventListener('click', ()=>{
    state.historyFilter.start = document.getElementById('histStart').value || null;
    state.historyFilter.end = document.getElementById('histEnd').value || null;
    renderHistory();
  });
  document.getElementById('histClearBtn').addEventListener('click', ()=>{
    state.historyFilter = { start:firstOfCurrentMonth(), end:null };
    renderHistory();
  });
  document.querySelectorAll('#screen .list-row').forEach(el=>{
    el.addEventListener('click', ()=>{
      const t = state.transactions.find(x=>x.id===el.dataset.id);
      if(t) showReceipt(t, false);
    });
  });
}

/* =========================================================================
   SCANNER (camera + hardware keyboard-wedge)
   ========================================================================= */
function lookupByCode(code){ return findVariantByBarcode(code); }

let scannerOnFound = null;
let scannerOnNotFound = null;
let zxingReader = null;
let scanDiagInterval = null;
let lastScanCode = null, lastScanTime = 0;
let pendingConfirmCode = null, pendingConfirmCount = 0;

/* A small, blurry, or curved-surface barcode (bottles, tubes, jars) is prone to one-off
   misreads on a single camera frame — the classic symptom is an existing product's barcode
   getting garbled into a code that matches nothing, so it looks like a brand new item.
   Two independent checks stand between a raw frame reading and actually acting on it: */
/* A second, independent decoder on the same frame the native detector already sees. Different
   phones/Chrome builds have wildly different quality "Shape Detection" (native BarcodeDetector)
   implementations — some genuinely can't read a barcode that ZXing's own decoder reads without
   trouble on the exact same image. Running both costs a little CPU but gives two real chances
   at every frame instead of one. */
let sharedZxingDecoder = null;
function getSharedZxingDecoder(){
  if(sharedZxingDecoder !== null) return sharedZxingDecoder;
  try{
    let hints = new Map();
    if(window.ZXing && window.ZXing.DecodeHintType){
      if(typeof window.ZXing.DecodeHintType.TRY_HARDER !== 'undefined') hints.set(window.ZXing.DecodeHintType.TRY_HARDER, true);
      if(window.ZXing.BarcodeFormat && typeof window.ZXing.DecodeHintType.POSSIBLE_FORMATS !== 'undefined'){
        const wanted = ['EAN_13','UPC_A','CODE_128','CODE_39','EAN_8'];
        const resolved = wanted.filter(n=>typeof window.ZXing.BarcodeFormat[n] !== 'undefined').map(n=>window.ZXing.BarcodeFormat[n]);
        if(resolved.length === wanted.length) hints.set(window.ZXing.DecodeHintType.POSSIBLE_FORMATS, resolved);
      }
    }
    const reader = new window.ZXing.BrowserMultiFormatReader(hints);
    // Feature-detect the exact synchronous decode method this build exposes — different builds
    // of @zxing/library have named this slightly differently across versions.
    if(typeof reader.decodeFromCanvas === 'function') sharedZxingDecoder = (canvas)=>reader.decodeFromCanvas(canvas);
    else if(reader.reader && typeof reader.reader.decode === 'function' && window.ZXing.HTMLCanvasElementLuminanceSource){
      sharedZxingDecoder = (canvas)=>{
        const luminanceSource = new window.ZXing.HTMLCanvasElementLuminanceSource(canvas);
        const binaryBitmap = new window.ZXing.BinaryBitmap(new window.ZXing.HybridBinarizer(luminanceSource));
        return reader.reader.decode(binaryBitmap, hints);
      };
    } else {
      sharedZxingDecoder = false; // no compatible method found on this build — disable cleanly
    }
  }catch(e){ sharedZxingDecoder = false; }
  return sharedZxingDecoder;
}

function isValidGtinChecksum(code){
  const digits = (code||'').trim();
  if(!/^\d+$/.test(digits)) return true; // not purely numeric — not an EAN/UPC code, nothing to validate
  if(![8,12,13].includes(digits.length)) return true; // not an EAN-8 / UPC-A / EAN-13 length, skip
  const nums = digits.split('').map(Number);
  const check = nums.pop();
  let sum = 0;
  // GS1 mod-10 check digit: from the digit immediately left of the check digit, alternate
  // weights 3 and 1 moving further left, then sum and compare against the stored check digit.
  for(let i = nums.length - 1, w = 3; i >= 0; i--, w = (w===3?1:3)) sum += nums[i]*w;
  return ((10 - (sum % 10)) % 10) === check;
}
/* Returns true if this reading was accepted and handed to handleScanResult; false if it was
   discarded (bad checksum) or is still waiting on a second, matching frame to confirm it. */
function reportScanCandidate(text, onCapture){
  if(!isValidGtinChecksum(text)) return false; // fails its own check digit — almost certainly a misread, ignore
  if(text === pendingConfirmCode){
    pendingConfirmCount++;
  } else {
    pendingConfirmCode = text;
    pendingConfirmCount = 1;
  }
  if(pendingConfirmCount < 2) return false; // need the same value on two frames in a row — a one-off misread rarely repeats identically
  pendingConfirmCount = 0;
  const now = Date.now();
  if(text === lastScanCode && (now - lastScanTime) < 1500) return false;
  lastScanCode = text; lastScanTime = now;
  handleScanResult(text, onCapture);
  return true;
}

async function openScanner(onCapture, opts={}){
  scannerOnFound = opts.onFound || null;
  scannerOnNotFound = opts.onNotFound || null;
  const root = document.getElementById('cameraOverlayRoot');
  root.innerHTML = `
    <div class="scanner-float-back" id="scannerOverlay">
      <div class="scanner-float-card">
        <div class="scanner-float-title">Scan a barcode</div>
        <div class="camera-full camera-full-v2" id="cameraCardWrap">
          <video id="scanVideo" playsinline autoplay muted></video>
          <div class="scan-frame-v2">
            <span class="corner tl"></span><span class="corner tr"></span>
            <span class="corner bl"></span><span class="corner br"></span>
            <div class="laser-line"></div>
          </div>
          <button class="torch-btn hidden" id="torchBtn" title="Flashlight">${ICO.flash}</button>
        </div>
        <div class="scan-hint hidden" id="scanHintText"></div>
        <div class="manual-row" style="margin-top:10px">
          <input id="manualCodeInput" placeholder="Or type the barcode">
          <button class="btn btn-primary" id="manualFindBtn" style="width:auto;padding:0 18px;flex-shrink:0">Find</button>
        </div>
        <button class="btn btn-outline" id="scanClose" style="margin-top:8px">Cancel</button>
      </div>
    </div>
  `;
  document.getElementById('scanClose').onclick = closeScanner;
  document.getElementById('scannerOverlay').addEventListener('click', e=>{ if(e.target.id==='scannerOverlay') closeScanner(); });
  const manualInput = document.getElementById('manualCodeInput');
  const submitManualCode = ()=>{
    const code = manualInput.value.trim();
    if(code) handleScanResult(code, onCapture);
  };
  document.getElementById('manualFindBtn').addEventListener('click', submitManualCode);
  manualInput.addEventListener('keydown', e=>{ if(e.key==='Enter'){ e.preventDefault(); submitManualCode(); } });

  lastScanCode = null; lastScanTime = 0;
  pendingConfirmCode = null; pendingConfirmCount = 0;
  const video = document.getElementById('scanVideo');

  // Prefer the phone's own built-in, hardware-accelerated barcode reader when the browser has
  // one (Android Chrome does) — it's typically faster and more reliable than a JS decoding
  // library run in software. Fall back to ZXing (works everywhere else, including desktop
  // Chrome and iOS Safari, which don't have this built in) if it's not available or fails.
  if('BarcodeDetector' in window){
    try{
      await startNativeScan(video, onCapture);
      setupCameraControls(video);
      return;
    }catch(e){
      console.error('Native BarcodeDetector failed to start, falling back to ZXing:', e);
      // clean up any partial camera stream the failed native attempt may have already opened
      if(state.scannerRAF){ cancelAnimationFrame(state.scannerRAF); state.scannerRAF = null; }
      if(video.srcObject){
        try{ video.srcObject.getTracks().forEach(t=>t.stop()); }catch(err){}
        try{ video.srcObject = null; }catch(err){}
      }
      if(state.scannerStream){
        try{ state.scannerStream.getTracks().forEach(t=>t.stop()); }catch(err){}
        state.scannerStream = null;
      }
    }
  }
  await startZXingScan(video, onCapture);
  setupCameraControls(video);
}

async function startNativeScan(video, onCapture){
  const stream = await navigator.mediaDevices.getUserMedia({
    // Ask for a sharper feed than before — more raw pixels per barcode bar makes a real
    // difference for small or distant codes (like one printed on a bottle cap/label).
    // `advanced` constraints are best-effort: unsupported ones are silently ignored rather
    // than rejecting the whole request, so it's safe to ask for continuous autofocus here —
    // a barcode held close to the lens is exactly the case a fixed/locked focus struggles with.
    video: { facingMode:'environment', width:{ ideal:3840 }, height:{ ideal:2160 }, advanced:[{ focusMode:'continuous' }] }
  });
  state.scannerStream = stream;
  video.srcObject = stream;
  await video.play();

  let detector;
  try{ detector = new window.BarcodeDetector({ formats:['ean_13','ean_8','upc_a','upc_e','code_128','code_39'] }); }
  catch(e){ detector = new window.BarcodeDetector(); } // some implementations reject a formats filter

  // Only ever analyze the region inside the on-screen corner brackets, not the whole wide-angle
  // frame. A barcode that looks small/blurry across a full 1280×720 frame fills far more of the
  // image once we crop down to just the area the user is actually aiming at — the same idea as
  // zooming in before taking a photo. Matches the .scan-frame-v2 CSS (inset: 14% 9%).
  const cropCanvas = document.createElement('canvas');
  const cropCtx = cropCanvas.getContext('2d');
  function getCropRegion(){
    const vw = video.videoWidth, vh = video.videoHeight;
    if(!vw || !vh) return null;
    // The video fills a square preview via object-fit:cover, so what's on-screen is a centered
    // square crop of the raw video — figure out that square first, then the guide box within it.
    const squareSide = Math.min(vw, vh);
    const offsetX = (vw - squareSide) / 2;
    const offsetY = (vh - squareSide) / 2;
    const x = offsetX + squareSide * 0.09;
    const y = offsetY + squareSide * 0.14;
    const width = squareSide * (1 - 0.09 * 2);
    const height = squareSide * (1 - 0.14 * 2);
    return { x, y, width, height };
  }

  let busy = false;
  let frameCount = 0;
  const loop = async ()=>{
    if(!document.getElementById('scanVideo')) return; // scanner was closed
    if(!busy){
      busy = true;
      frameCount++;
      try{
        let detectTarget = video;
        const region = getCropRegion();
        if(region && region.width > 0 && region.height > 0){
          // Upscale the crop too (capped so it stays fast) — gives the detector more effective
          // pixels per barcode bar, which helps with small, distant, or lower-resolution codes.
          const scale = Math.min(4, 1800 / Math.max(region.width, region.height));
          const outW = Math.round(region.width * scale);
          const outH = Math.round(region.height * scale);
          cropCanvas.width = outW;
          cropCanvas.height = outH;
          cropCtx.imageSmoothingEnabled = true;
          cropCtx.imageSmoothingQuality = 'high';
          cropCtx.drawImage(video, region.x, region.y, region.width, region.height, 0, 0, outW, outH);
          detectTarget = cropCanvas;
        }
        const codes = await detector.detect(detectTarget);
        if(codes && codes.length){
          const text = codes[0].rawValue;
          if(reportScanCandidate(text, onCapture)) return; // handleScanResult closes the scanner (on success) or leaves it open to retry
        } else if(detectTarget !== video && frameCount % 3 === 0){
          // The device's own detector found nothing on this frame — give ZXing's decoder a
          // shot at the exact same (already cropped/upscaled) image before moving on. Only
          // every 3rd frame, so this safety net doesn't cost more battery than it's worth.
          const zxingDecode = getSharedZxingDecoder();
          if(zxingDecode){
            try{
              const result = zxingDecode(detectTarget);
              if(result){
                const text = result.getText ? result.getText() : result.text;
                if(text && reportScanCandidate(text, onCapture)) return;
              }
            }catch(e){ /* ZXing throws NotFoundException on a clean miss — normal, ignore */ }
          }
        }
      }catch(e){ /* detect() can throw transiently on an odd frame — just try again next frame */ }
      busy = false;
    }
    state.scannerRAF = requestAnimationFrame(loop);
  };
  state.scannerRAF = requestAnimationFrame(loop);
}

async function startZXingScan(video, onCapture){
  let scanAttempts = 0;
  try{
    let hints = null;
    try{
      hints = new Map();
      if(window.ZXing.DecodeHintType && typeof window.ZXing.DecodeHintType.TRY_HARDER !== 'undefined'){
        hints.set(window.ZXing.DecodeHintType.TRY_HARDER, true);
      }
      // Restricting to the 1D formats retail barcodes actually use speeds up each decode attempt
      // and avoids frames being spent on 2D formats we don't need. Each format name is checked
      // individually before use — an unresolved constant would otherwise silently become
      // `undefined` in the array (JS doesn't error on that), which could reject every real scan.
      if(window.ZXing.DecodeHintType && window.ZXing.BarcodeFormat && typeof window.ZXing.DecodeHintType.POSSIBLE_FORMATS !== 'undefined'){
        const wantedFormats = ['EAN_13','UPC_A','CODE_128','CODE_39','EAN_8'];
        const resolvedFormats = wantedFormats
          .filter(name => typeof window.ZXing.BarcodeFormat[name] !== 'undefined')
          .map(name => window.ZXing.BarcodeFormat[name]);
        if(resolvedFormats.length === wantedFormats.length){
          hints.set(window.ZXing.DecodeHintType.POSSIBLE_FORMATS, resolvedFormats);
        } else {
          console.error('Some ZXing BarcodeFormat names did not resolve — scanning all formats instead.');
        }
      }
    }catch(e){ hints = null; console.error('ZXing hint setup failed, scanning without hints:', e); }
    zxingReader = hints ? new window.ZXing.BrowserMultiFormatReader(hints) : new window.ZXing.BrowserMultiFormatReader();
    const video = document.getElementById('scanVideo');

    // `ideal` (not `min`) resolution — mobile cameras default to low resolutions that make fine
    // barcode bars unreadable, but a hard `min` constraint previously caused a virtual camera
    // (DroidCam) to fail silently and go black. `ideal` is just a preference: the browser picks
    // the closest available resolution instead of rejecting the stream outright if unmet.
    await zxingReader.decodeFromConstraints(
      { video: { facingMode:'environment', width:{ ideal:3840 }, height:{ ideal:2160 }, advanced:[{ focusMode:'continuous' }] } },
      video,
      (result, err)=>{
        scanAttempts++;
        if(!result){
          // NotFoundException/ChecksumException/FormatException fire on essentially every frame
          // that doesn't contain a clean, fully-decoded barcode — that's normal, not a bug.
          // Anything else is unexpected and worth knowing about.
          if(err && err.name && !['NotFoundException','ChecksumException','FormatException'].includes(err.name)){
            console.error('Unexpected barcode decode error:', err);
          }
          return;
        }
        const text = result.getText();
        reportScanCandidate(text, onCapture);
      }
    );
  }catch(e){
    console.error('Camera/scanner failed to start:', e);
    const wrap = document.getElementById('cameraCardWrap');
    if(wrap) wrap.outerHTML = `
      <div class="scan-fallback">
        ${ICO.cam}
        <div style="font-weight:700;font-size:13.5px;color:var(--ink)">Camera access unavailable</div>
        <div style="font-size:12px;line-height:1.5">Grant camera permission in your browser, or type the barcode / use a hardware scanner below.</div>
      </div>`;
  }
}

function setupCameraControls(video){
  try{
    const track = video.srcObject && video.srcObject.getVideoTracks()[0];
    const caps = track && track.getCapabilities ? track.getCapabilities() : null;
    if(!track || !caps) return;

    if(caps.torch){
      const torchBtn = document.getElementById('torchBtn');
      torchBtn.classList.remove('hidden');
      let torchOn = false;
      torchBtn.onclick = async ()=>{
        torchOn = !torchOn;
        try{ await track.applyConstraints({ advanced:[{ torch: torchOn }] }); torchBtn.classList.toggle('active', torchOn); }
        catch(e){ toast('Flashlight not available on this camera'); }
      };
    }

    // Hardware zoom: applied automatically and silently (no user-facing controls) when the
    // device exposes real optical/sensor zoom. A barcode that's genuinely small or far away
    // in frame (a cap, a curved tube label) is a case no amount of software cropping/upscaling
    // can fully fix — actual optical/sensor zoom captures real extra detail that isn't there
    // in the original frame. A mild default level keeps the frame wide enough to still find
    // the code before zooming in on it, while the crop+upscale step in the scan loop below
    // does the rest of the "digital zoom" work automatically, frame by frame.
    if(caps.zoom && typeof caps.zoom.max === 'number' && caps.zoom.max > caps.zoom.min){
      const min = caps.zoom.min, max = caps.zoom.max;
      const zoom = Math.min(max, min + (max - min) * 0.3);
      track.applyConstraints({ advanced:[{ zoom }] }).catch(()=>{});
    }

    // Continuous autofocus, re-nudged periodically: some devices' continuous-AF doesn't
    // re-trigger promptly on its own when a small/close-up barcode enters frame. Re-asserting
    // the focusMode constraint every couple of seconds costs nothing and prompts a fresh focus
    // sweep on devices where it matters, fully automatically (no tap required).
    if(caps.focusMode && caps.focusMode.includes && caps.focusMode.includes('continuous')){
      const refocusTimer = setInterval(()=>{
        if(!document.getElementById('scanVideo')){ clearInterval(refocusTimer); return; }
        track.applyConstraints({ advanced:[{ focusMode:'continuous' }] }).catch(()=>{});
      }, 2000);
    }

    // Tap-to-focus: continuous autofocus doesn't always re-trigger promptly when the person
    // moves the phone in close on a small barcode, which is exactly when a fresh focus pass
    // matters most. Where the browser/device exposes a focus point constraint, tapping the
    // preview nudges the camera to refocus right there. Silently does nothing on devices that
    // don't support it — no visible downside to trying.
    const wrap = document.getElementById('cameraCardWrap');
    if(wrap && caps.pointsOfInterest){
      wrap.addEventListener('click', async (e)=>{
        const rect = wrap.getBoundingClientRect();
        const x = (e.clientX - rect.left) / rect.width;
        const y = (e.clientY - rect.top) / rect.height;
        try{
          await track.applyConstraints({ advanced:[{ pointsOfInterest:[{ x, y }] }] });
          if(caps.focusMode && caps.focusMode.includes && caps.focusMode.includes('single-shot')){
            await track.applyConstraints({ advanced:[{ focusMode:'single-shot' }] });
            await track.applyConstraints({ advanced:[{ focusMode:'continuous' }] });
          }
        }catch(err){}
      });
    }
  }catch(e){}
}

function handleScanResult(code, onCapture){
  vibrate(30);
  if(onCapture){
    closeScanner();
    onCapture(code);
    return;
  }
  const found = lookupByCode(code);
  if(found){
    if(scannerOnFound){
      // closeScanner() clears the scannerOnFound/scannerOnNotFound globals as part of its
      // cleanup, so the callback must be captured into a local variable BEFORE calling it —
      // calling closeScanner() first and then invoking scannerOnFound would call it as null.
      const onFound = scannerOnFound;
      closeScanner();
      onFound(found);
    } else {
      const added = addToCart(found.product.id, 1, found.variant.id); // shows its own toast either way (success or stock-limit)
      if(added){
        closeScanner();
        renderCartOverlay();
      } else {
        // out of stock (or similar) — addToCart's toast can be easy to miss, so also show a
        // persistent message right in the scanner itself that won't disappear in 2 seconds.
        const label = found.product.name + (found.variant.name?` (${found.variant.name})`:'');
        setScanHint(`Found "${label}" — but it has 0 stock, so it can't be added. Add stock first.`, true);
      }
    }
  } else if(scannerOnNotFound){
    const onNotFound = scannerOnNotFound;
    closeScanner();
    onNotFound(code);
  } else {
    setScanHint(`No product matches "${code}". Check its barcode value on the product's page.`, true);
    toast(`No product matches "${code}"`);
    // camera keeps running and ZXing keeps calling back on new frames automatically — no
    // manual "resume" needed here, unlike the old BarcodeDetector-based loop.
  }
}

/* Persistent (not auto-hiding) status banner shown right in the scanner overlay — used for
   outcomes that matter and are easy to miss as a quick toast (out of stock, no match, etc). */
function setScanHint(msg, isError){
  const el = document.getElementById('scanHintText');
  if(!el) return;
  el.classList.remove('hidden');
  if(isError){
    el.innerHTML = `<div class="scan-result-banner">${esc(msg)}</div>`;
  } else {
    el.textContent = msg;
    el.style.color = '';
  }
}

function closeScanner(){
  if(scanDiagInterval){ clearInterval(scanDiagInterval); scanDiagInterval = null; }
  if(state.scannerRAF){ cancelAnimationFrame(state.scannerRAF); state.scannerRAF = null; } // native scan loop
  if(zxingReader){ try{ zxingReader.reset(); }catch(e){} zxingReader = null; }
  // Pausing before stopping, and explicitly nulling srcObject after, gets the camera to fully
  // release (and the camera-in-use indicator to turn off) more reliably on iOS Safari — just
  // stopping the tracks can otherwise leave the camera looking "still active" on some devices.
  const video = document.getElementById('scanVideo');
  if(video){
    try{ video.pause(); }catch(e){}
    if(video.srcObject){
      try{ video.srcObject.getTracks().forEach(t=>t.stop()); }catch(e){}
      try{ video.srcObject = null; }catch(e){}
    }
  }
  if(state.scannerStream){ state.scannerStream.getTracks().forEach(t=>t.stop()); state.scannerStream=null; }
  scannerOnFound = null;
  scannerOnNotFound = null;
  document.getElementById('cameraOverlayRoot').innerHTML = '';
}
// Release the camera if the browser tab/app is backgrounded while scanning — leaving it running
// wastes battery and iOS Safari in particular can struggle to resume a camera stream cleanly
// after the tab returns from the background.
document.addEventListener('visibilitychange', ()=>{
  if(document.hidden && document.getElementById('scannerOverlay')) closeScanner();
});

/* ---------------- live camera photo capture (for product/profile/logo photos) ---------------- */
async function openPhotoCapture(onPhoto){
  const root = document.getElementById('cameraOverlayRoot');
  root.innerHTML = `
    <div class="scanner-overlay" id="photoCaptureOverlay">
      <div class="scanner-header">
        <button class="icon-btn" id="photoCapClose" style="background:var(--paper-dim);color:var(--ink)" title="Back">${ICO.back}</button>
        <h2>Take photo</h2>
      </div>
      <div class="scanner-content">
        <div class="camera-card" id="photoCardWrap">
          <video id="photoVideo" playsinline autoplay muted></video>
        </div>
        <div class="scan-hint" id="photoHint">Center the product, then tap to capture</div>
        <button class="shutter-btn" id="shutterBtn" title="Capture"></button>
      </div>
    </div>
  `;
  const close = ()=>{
    if(state.scannerStream){ state.scannerStream.getTracks().forEach(t=>t.stop()); state.scannerStream=null; }
    document.getElementById('cameraOverlayRoot').innerHTML = '';
  };
  document.getElementById('photoCapClose').onclick = close;

  try{
    const stream = await navigator.mediaDevices.getUserMedia({
      video:{ facingMode:'environment', width:{ideal:1280}, height:{ideal:720} }
    });
    state.scannerStream = stream;
    const video = document.getElementById('photoVideo');
    video.srcObject = stream;
    await video.play();
    document.getElementById('shutterBtn').onclick = async ()=>{
      vibrate(20);
      const canvas = document.createElement('canvas');
      const maxDim = 480;
      let w = video.videoWidth, h = video.videoHeight;
      if(w > h){ if(w > maxDim){ h = Math.round(h*maxDim/w); w = maxDim; } }
      else { if(h > maxDim){ w = Math.round(w*maxDim/h); h = maxDim; } }
      canvas.width = w; canvas.height = h;
      canvas.getContext('2d').drawImage(video, 0, 0, w, h);
      const dataUrl = canvas.toDataURL('image/jpeg', 0.75);
      close();
      onPhoto(dataUrl);
    };
  }catch(e){
    const wrap = document.getElementById('photoCardWrap');
    if(wrap) wrap.outerHTML = `
      <div class="scan-fallback">
        ${ICO.cam}
        <div style="font-weight:700;font-size:13.5px;color:var(--ink)">Camera access unavailable</div>
        <div style="font-size:12px;line-height:1.5">Grant camera permission in your browser, or choose an existing photo instead.</div>
      </div>`;
    document.getElementById('shutterBtn').classList.add('hidden');
  }
}

/* ---------------- hardware keyboard-wedge scanner (global — works on every tab, camera or no camera) ---------------- */
let wedgeBuffer = '';
let wedgeLastTime = 0;
document.addEventListener('keydown', (e)=>{
  const activeEl = document.activeElement;
  const typing = activeEl && (activeEl.tagName==='INPUT' || activeEl.tagName==='TEXTAREA' || activeEl.tagName==='SELECT');
  if(typing) return; // don't hijack real typing — the scanner's own manual input handles itself
  if(document.getElementById('scannerOverlay')) return; // camera scanner overlay handles its own input

  const now = Date.now();
  if(e.key === 'Enter'){
    if(wedgeBuffer.length >= 3){
      const code = wedgeBuffer;
      wedgeBuffer = '';
      handleScanResult(code); // same lookup + add-to-cart path a normal scan takes
    }
    wedgeBuffer = '';
    return;
  }
  if(e.key.length === 1){
    // Real hardware scanners type each character within ~50ms of the last one — far faster than
    // any human. Anything slower resets the buffer instead of appending, so ordinary fast typing
    // can't accidentally get mistaken for a scan.
    if(wedgeBuffer.length > 0 && (now - wedgeLastTime) > 50) wedgeBuffer = '';
    wedgeBuffer += e.key;
    wedgeLastTime = now;
  }
});

/* =========================================================================
   SETTINGS
   ========================================================================= */

/* ---------------- shared: profile photo picker (used in Settings for admin & Account modal for cashier) ---------------- */
function profilePhotoBlockHTML(){
  const p = state.auth.profile || {};
  const name = p.full_name || (state.auth.user && state.auth.user.email) || 'You';
  const avatar = p.avatar || null;
  return `
    <div class="section-title" style="padding-top:0">Your profile</div>
    <div class="field" style="padding-top:0">
      <div class="photo-picker">
        <div class="photo-preview" id="avatarPreview" style="border-radius:50%">
          ${avatar?`<img src="${avatar}" alt="">`:`<div class="photo-empty" style="font-family:var(--font-display);font-weight:700;font-size:26px;color:var(--ink-faint)">${esc(name.slice(0,1).toUpperCase())}</div>`}
        </div>
        <div class="photo-picker-actions">
          <div class="row-title" style="margin-bottom:2px">${esc(name)}</div>
          <div class="row-sub" style="font-family:var(--font-body);text-transform:capitalize;margin-bottom:4px">${esc(p.role||'')}</div>
          <button type="button" class="btn btn-outline" id="avatarCam">${ICO.cam.replace('width="30" height="30"','width="15" height="15"')} Take photo</button>
          <button type="button" class="btn btn-ghost" id="avatarPick">${avatar?'Choose different file':'Choose file'}</button>
          ${avatar?`<button type="button" class="btn btn-ghost" id="avatarRemove">Remove</button>`:''}
          <input type="file" id="avatarInput" accept="image/*" class="hidden">
        </div>
      </div>
    </div>`;
}
function wireProfilePhotoBlock(onChanged){
  const saveAvatar = async (dataUrlOrNull)=>{
    state.auth.profile = state.auth.profile || {};
    state.auth.profile.avatar = dataUrlOrNull;
    try{
      await state.cloud.client.from('oyes_profiles').update({ avatar: dataUrlOrNull }).eq('id', state.auth.user.id);
      toast(dataUrlOrNull ? 'Profile photo updated' : 'Profile photo removed');
    }catch(e){ toast('Could not save photo to your account'); }
    syncUserChip();
    if(onChanged) onChanged();
  };
  document.getElementById('avatarCam').onclick = ()=>openPhotoCapture((dataUrl)=>saveAvatar(dataUrl));
  document.getElementById('avatarPick').onclick = ()=> document.getElementById('avatarInput').click();
  const removeBtn = document.getElementById('avatarRemove');
  if(removeBtn) removeBtn.onclick = ()=>saveAvatar(null);
  document.getElementById('avatarInput').addEventListener('change', async (e)=>{
    const file = e.target.files && e.target.files[0];
    if(!file) return;
    try{
      toast('Processing photo…');
      const dataUrl = await readAndResizeImage(file, 300, 0.7);
      await saveAvatar(dataUrl);
    }catch(err){ toast('Could not load that photo'); }
    e.target.value = '';
  });
}

function openAccountModal(){
  const root = document.getElementById('modalRoot');
  root.innerHTML = `
    <div class="modal-back" id="mbAccount">
      <div class="modal-sheet">
        <div class="modal-handle"></div>
        ${profilePhotoBlockHTML()}
        <div class="field field-hint" style="padding-top:0">You're signed in as a cashier — you can ring up sales, but product, category and store settings are managed by your admin.</div>
        <div class="field"><button class="btn btn-danger" id="acctLogout">Log out</button></div>
      </div>
    </div>`;
  document.getElementById('mbAccount').addEventListener('click', e=>{ if(e.target.id==='mbAccount') root.innerHTML=''; });
  wireProfilePhotoBlock(()=>openAccountModal());
  document.getElementById('acctLogout').onclick = ()=>{
    const name = state.auth.profile ? (state.auth.profile.full_name||state.auth.user.email) : '';
    root.innerHTML='';
    confirmModal('Log out?', `Signed in as ${name}. You'll need to log in again to use the app.`, logout);
  };
}

function openSettings(){
  const root = document.getElementById('modalRoot');
  root.innerHTML = `
    <div class="modal-back" id="mbSettings">
      <div class="modal-sheet">
        <div class="modal-handle"></div>
        ${state.cloud.connected ? profilePhotoBlockHTML() : ''}
        <div class="section-title" style="padding-top:${state.cloud.connected?'6px':'0'}">Settings</div>
        <div class="field" style="padding-top:0">
          <button class="btn btn-outline" id="hubStoreBtn" style="justify-content:space-between">
            <span>Store settings</span>${ICO.chevron}
          </button>
        </div>
        <div class="field">
          <button class="btn btn-outline" id="hubCloudBtn" style="justify-content:space-between">
            <span>Cloud sync${state.cloud.connected?' — Connected':''}</span>${ICO.chevron}
          </button>
        </div>
        ${state.cloud.connected ? `
        <div class="field">
          <button class="btn btn-outline" id="hubTeamBtn" style="justify-content:space-between">
            <span>Manage team roles</span>${ICO.chevron}
          </button>
        </div>` : ''}
      </div>
    </div>`;
  document.getElementById('mbSettings').addEventListener('click', e=>{ if(e.target.id==='mbSettings') root.innerHTML=''; });
  if(state.cloud.connected) wireProfilePhotoBlock(()=>openSettings());
  document.getElementById('hubStoreBtn').onclick = ()=>{ root.innerHTML=''; openStoreSettingsModal(); };
  document.getElementById('hubCloudBtn').onclick = ()=>{ root.innerHTML=''; openCloudSyncModal(); };
  const hubTeamBtn = document.getElementById('hubTeamBtn');
  if(hubTeamBtn) hubTeamBtn.onclick = openManageTeamModal;
}

function openStoreSettingsModal(){
  const root = document.getElementById('modalRoot');
  const logo = state.settings.logo;
  root.innerHTML = `
    <div class="modal-back" id="mbStore">
      <div class="modal-sheet">
        <div class="modal-handle"></div>
        <div class="section-title" style="padding-top:0">Store settings</div>
        <div class="field" style="padding-top:0">
          <label>Store logo</label>
          <div class="photo-picker" id="logoPicker">
            ${logo?`<div class="photo-preview" id="logoPreview"><img src="${logo}" alt=""></div>`:''}
            <div class="photo-picker-actions">
              <button type="button" class="btn btn-outline" id="logoCam">${ICO.cam.replace('width="30" height="30"','width="15" height="15"')} Take photo</button>
              <button type="button" class="btn btn-ghost" id="logoPick">${logo?'Choose different file':'Choose file'}</button>
              ${logo?`<button type="button" class="btn btn-ghost" id="logoRemove">Remove</button>`:''}
              <input type="file" id="logoInput" accept="image/*" class="hidden">
            </div>
          </div>
        </div>
        <div class="field"><label>Shop name</label><input id="stName" value="${esc(state.settings.shopName)}"></div>
        <div class="field"><label>Tagline</label><input id="stSub" value="${esc(state.settings.shopSub)}"></div>
        <div class="field"><label>Address (shown on receipt)</label><input id="stAddr" value="${esc(state.settings.address)}"></div>
        <div class="field"><label>Currency symbol</label><input id="stCur" value="${esc(state.settings.currency)}" maxlength="3"></div>
        <div class="field"><div class="btn-row">
          <button class="btn btn-ghost" id="stCancel">Back</button>
          <button class="btn btn-primary" id="stSave">Save</button>
        </div></div>
      </div>
    </div>`;
  document.getElementById('mbStore').addEventListener('click', e=>{ if(e.target.id==='mbStore') root.innerHTML=''; });

  let pendingLogo = logo;
  const refreshLogoUI = ()=>{
    const picker = document.getElementById('logoPicker');
    let preview = document.getElementById('logoPreview');
    if(pendingLogo){
      if(!preview){
        preview = document.createElement('div');
        preview.className = 'photo-preview';
        preview.id = 'logoPreview';
        picker.insertBefore(preview, picker.firstChild);
      }
      preview.innerHTML = `<img src="${pendingLogo}" alt="">`;
    } else if(preview){
      preview.remove();
    }
    document.getElementById('logoPick').textContent = pendingLogo ? 'Choose different file' : 'Choose file';
    const rmBtn = document.getElementById('logoRemove');
    if(pendingLogo && !rmBtn){
      document.getElementById('logoPick').insertAdjacentHTML('afterend', `<button type="button" class="btn btn-ghost" id="logoRemove">Remove</button>`);
      document.getElementById('logoRemove').onclick = ()=>{ pendingLogo=null; refreshLogoUI(); };
    } else if(!pendingLogo && rmBtn){ rmBtn.remove(); }
  };
  document.getElementById('logoCam').onclick = ()=>openPhotoCapture((dataUrl)=>{ pendingLogo = dataUrl; refreshLogoUI(); });
  document.getElementById('logoPick').onclick = ()=>document.getElementById('logoInput').click();
  const logoRemoveInit = document.getElementById('logoRemove');
  if(logoRemoveInit) logoRemoveInit.onclick = ()=>{ pendingLogo=null; refreshLogoUI(); };
  document.getElementById('logoInput').addEventListener('change', async (e)=>{
    const file = e.target.files && e.target.files[0];
    if(!file) return;
    try{ toast('Processing photo…'); pendingLogo = await readAndResizeImage(file, 320, 0.75); refreshLogoUI(); }
    catch(err){ toast('Could not load that photo'); }
    e.target.value = '';
  });

  document.getElementById('stCancel').onclick = ()=>{ root.innerHTML=''; openSettings(); };
  document.getElementById('stSave').onclick = ()=>{
    state.settings.shopName = document.getElementById('stName').value.trim() || 'My Store';
    state.settings.shopSub = document.getElementById('stSub').value.trim();
    state.settings.address = document.getElementById('stAddr').value.trim();
    state.settings.currency = document.getElementById('stCur').value.trim() || '₦';
    state.settings.logo = pendingLogo || '';
    saveSettings(); syncTopbar(); root.innerHTML=''; toast('Settings saved');
  };
}

function openCloudSyncModal(){
  const root = document.getElementById('modalRoot');
  root.innerHTML = `
    <div class="modal-back" id="mbCloud">
      <div class="modal-sheet">
        <div class="modal-handle"></div>
        <div class="section-title" style="padding-top:0">Cloud sync (Supabase)</div>
        <div class="field" style="padding-top:0">
          <div class="cloud-status ${state.cloud.connected?'ok':''}">
            <span class="dot"></span>
            <span>${state.cloud.connected ? `Connected — signed in as ${esc(state.auth.profile ? (state.auth.profile.full_name||state.auth.user.email) : '')}` : 'Not connected — data is saved on this device only'}</span>
          </div>
        </div>
        ${state.cloud.connected ? `
        <div class="field" style="padding-top:0"><button class="btn btn-outline" id="cloudSyncDetails">Sync status &amp; retry</button></div>
        <div class="field field-hint" style="padding-top:0">To add a new teammate, ask whoever manages your Supabase project to add them under Authentication → Users. All other database setup happens there too — not in this app.</div>
        ` : `
        <div class="field"><label>Project URL</label><input id="cloudUrl" placeholder="https://xxxxxxxx.supabase.co" value="${esc(state.cloud.url)}"></div>
        <div class="field"><label>Anon / publishable key</label><input id="cloudKey" placeholder="eyJhbGciOi..." value="${esc(state.cloud.key)}"></div>
        <div class="field field-hint" style="padding-top:0">Set up your database tables and first user directly in Supabase, then connect here.</div>
        `}
        <div class="field"><div class="btn-row">
          <button class="btn btn-ghost" id="cloudBack">Back</button>
          ${state.cloud.connected ? '' : `<button class="btn btn-amber" id="cloudConnect">Connect & log in</button>`}
        </div></div>
      </div>
    </div>`;
  document.getElementById('mbCloud').addEventListener('click', e=>{ if(e.target.id==='mbCloud') root.innerHTML=''; });
  document.getElementById('cloudBack').onclick = ()=>{ root.innerHTML=''; openSettings(); };
  const syncDetailsBtn = document.getElementById('cloudSyncDetails');
  if(syncDetailsBtn) syncDetailsBtn.onclick = ()=>openSyncDetailsModal();
  const connectBtn = document.getElementById('cloudConnect');
  if(connectBtn) connectBtn.onclick = async ()=>{
    const url = document.getElementById('cloudUrl').value.trim().replace(/\/+$/,'');
    const key = document.getElementById('cloudKey').value.trim();
    if(!url || !key){ toast('Enter your project URL and anon key'); return; }
    await setJSON('oyes:cloud_config', {url, key});
    initCloudClient(url, key);
    root.innerHTML='';
    renderLogin();
  };
}

async function openManageTeamModal(){
  const root = document.getElementById('modalRoot');
  root.innerHTML = `
    <div class="modal-back" id="mbTeam">
      <div class="modal-sheet">
        <div class="modal-handle"></div>
        <div class="section-title" style="padding-top:0">Team roles</div>
        <div class="field field-hint" style="padding-top:0">Admins can manage products, categories, history and store settings. Cashiers can only ring up sales.</div>
        <div class="field" id="teamListWrap"><div class="field-hint">Loading team…</div></div>
        <div class="field"><button class="btn btn-ghost" id="teamClose">Close</button></div>
      </div>
    </div>`;
  document.getElementById('mbTeam').addEventListener('click', e=>{ if(e.target.id==='mbTeam') root.innerHTML=''; });
  document.getElementById('teamClose').onclick = ()=>root.innerHTML='';

  let profiles = [];
  try{
    const { data, error } = await state.cloud.client.from('oyes_profiles').select('*').order('created_at', {ascending:true});
    if(error) throw error;
    profiles = data || [];
  }catch(e){
    document.getElementById('teamListWrap').innerHTML = `<div class="field-hint" style="color:var(--red)">Could not load team list. Run the role-management SQL (see chat) then try again.</div>`;
    return;
  }
  const wrap = document.getElementById('teamListWrap');
  if(!profiles.length){ wrap.innerHTML = `<div class="field-hint">No team members found.</div>`; return; }
  wrap.innerHTML = profiles.map(p=>`
    <div class="hstack" style="justify-content:space-between;padding:9px 0;border-bottom:1px solid var(--line)">
      <div>
        <div class="row-title">${esc(p.full_name||'Staff')}${p.id===state.auth.user.id?' (you)':''}</div>
        <div class="row-sub" style="font-family:var(--font-body)">${new Date(p.created_at).toLocaleDateString()}</div>
      </div>
      <select class="team-role-sel" data-id="${esc(p.id)}" style="width:auto;border:1px solid var(--line);border-radius:8px;padding:7px 8px;font-size:12.5px">
        <option value="cashier" ${p.role==='cashier'?'selected':''}>Cashier</option>
        <option value="admin" ${p.role==='admin'?'selected':''}>Admin</option>
      </select>
    </div>
  `).join('');
  wrap.querySelectorAll('.team-role-sel').forEach(sel=>{
    sel.addEventListener('change', async ()=>{
      const id = sel.dataset.id;
      const newRole = sel.value;
      sel.disabled = true;
      try{
        const { error } = await state.cloud.client.from('oyes_profiles').update({ role:newRole }).eq('id', id);
        if(error) throw error;
        toast('Role updated');
        if(id === state.auth.user.id){ state.auth.profile.role = newRole; applyRoleUI(); }
      }catch(e){
        toast('Could not update role — run the role-management SQL first');
        sel.value = sel.value==='admin' ? 'cashier' : 'admin'; // revert visual
      }
      sel.disabled = false;
    });
  });
}

function syncTopbar(){
  document.getElementById('shopNameLbl').textContent = state.settings.shopName;
  const mark = document.getElementById('brandMark');
  mark.innerHTML = state.settings.logo
    ? `<img src="${state.settings.logo}" alt="" style="width:100%;height:100%;object-fit:cover">`
    : esc((state.settings.shopName||'O').trim().slice(0,1).toUpperCase());
  syncUserChip();
}

/* ---------------- generic confirm modal ---------------- */
function confirmModal(title, body, onConfirm){
  const root = document.getElementById('modalRoot');
  root.innerHTML = `
    <div class="modal-back" id="mbConfirm">
      <div class="modal-sheet">
        <div class="modal-handle"></div>
        <div class="section-title" style="padding-top:0">${esc(title)}</div>
        <div class="field field-hint" style="padding-top:0">${esc(body)}</div>
        <div class="field"><div class="btn-row">
          <button class="btn btn-ghost" id="cfmNo">Cancel</button>
          <button class="btn btn-danger" id="cfmYes">Confirm</button>
        </div></div>
      </div>
    </div>`;
  document.getElementById('mbConfirm').addEventListener('click', e=>{ if(e.target.id==='mbConfirm') root.innerHTML=''; });
  document.getElementById('cfmNo').onclick = ()=>root.innerHTML='';
  document.getElementById('cfmYes').onclick = ()=>{ root.innerHTML=''; onConfirm(); };
}

/* =========================================================================
   NAV / BOOTSTRAP / ROLES
   ========================================================================= */
function isAdmin(){
  if(!state.cloud.connected) return true; // local-only mode: single device owner, full access
  return !!(state.auth.profile && state.auth.profile.role === 'admin');
}
function applyRoleUI(){
  const admin = isAdmin();
  document.querySelectorAll('.navbtn').forEach(b=>{
    // everyone can see Sell and Customers; Products & History stay admin-only
    const adminOnly = b.dataset.tab==='products' || b.dataset.tab==='history';
    b.classList.toggle('hidden', adminOnly && !admin);
  });
  if(!admin && (state.tab==='products' || state.tab==='history')){ state.tab = 'sell'; }
}
function renderActiveTab(){
  applyRoleUI();
  document.querySelectorAll('.navbtn').forEach(b=>b.classList.toggle('active', b.dataset.tab===state.tab));
  document.getElementById('topbarSub').textContent = {sell:'Point of Sale', products:'Products & categories', history:'Sales history', customers:'Customer accounts & credit'}[state.tab];
  if(state.tab==='sell') renderSell();
  else if(state.tab==='products' && isAdmin()) renderProducts();
  else if(state.tab==='history' && isAdmin()) renderHistory();
  else if(state.tab==='customers') renderCustomers();
  else { state.tab='sell'; renderSell(); }
  updateCartBar();
}

document.querySelectorAll('.navbtn').forEach(btn=>{
  btn.addEventListener('click', ()=>{
    const adminOnly = btn.dataset.tab==='products' || btn.dataset.tab==='history';
    if(adminOnly && !isAdmin()) return; // cashiers can't reach these tabs (Sell & Customers are open to everyone)
    state.tab = btn.dataset.tab;
    state.search='';
    closeOverlay();
    renderActiveTab();
  });
});
document.getElementById('cartbar').addEventListener('click', openCart);
document.getElementById('settingsBtn').addEventListener('click', ()=>{ isAdmin() ? openSettings() : openAccountModal(); });
document.getElementById('userChipBtn').addEventListener('click', ()=>{
  const name = state.auth.profile ? (state.auth.profile.full_name || state.auth.user.email) : '';
  const role = state.auth.profile ? state.auth.profile.role : '';
  confirmModal('Log out?', `Signed in as ${name}${role?` (${role})`:''}. You'll need to log in again to use the app.`, logout);
});

function syncUserChip(){
  const btn = document.getElementById('userChipBtn');
  if(state.cloud.connected && state.auth.profile){
    const name = state.auth.profile.full_name || (state.auth.user && state.auth.user.email) || 'U';
    const avatar = state.auth.profile.avatar;
    document.getElementById('userChipInitial').innerHTML = avatar
      ? `<img src="${avatar}" alt="" style="width:100%;height:100%;object-fit:cover;border-radius:8px">`
      : esc(name.trim().slice(0,1).toUpperCase());
    btn.title = `${name}${state.auth.profile.role ? ' · '+state.auth.profile.role : ''} — tap to log out`;
    btn.classList.remove('hidden');
  } else {
    btn.classList.add('hidden');
  }
}

/* ---------------- login screen ---------------- */
function renderLogin(){
  document.getElementById('bottomnav').classList.add('hidden');
  document.getElementById('cartbar').classList.add('hidden');
  document.getElementById('userChipBtn').classList.add('hidden');
  document.getElementById('settingsBtn').classList.add('hidden');
  document.getElementById('topbarSub').textContent = 'Staff login';
  document.getElementById('screen').innerHTML = `
    <div class="login-wrap">
      <div class="login-card">
        <div class="brand-mark" style="width:48px;height:48px;font-size:20px;margin:0 auto 14px;">${state.settings.logo?`<img src="${state.settings.logo}" alt="" style="width:100%;height:100%;object-fit:cover">`:esc((state.settings.shopName||'O').trim().slice(0,1).toUpperCase())}</div>
        <h2 class="login-title">${esc(state.settings.shopName)}</h2>
        <div class="login-sub">Sign in with the staff login your admin gave you</div>
        <div class="field" style="padding-left:0;padding-right:0"><label>Email</label><input type="email" id="loginEmail" autocomplete="username" placeholder="you@example.com"></div>
        <div class="field" style="padding-left:0;padding-right:0">
          <label>Password</label>
          <div class="pw-wrap">
            <input type="password" id="loginPassword" autocomplete="current-password" placeholder="••••••••">
            <button type="button" class="pw-toggle" id="pwToggle" aria-label="Show password">${ICO.eye}</button>
          </div>
        </div>
        <div id="loginError" class="login-error hidden"></div>
        <button class="btn btn-primary mt8" id="loginBtn">Log in</button>
        <div class="field-hint" style="text-align:center;margin-top:14px">Don't have login details? Ask whoever manages this store's Supabase project to add you under Authentication → Users.</div>
      </div>
    </div>
  `;
  const doLogin = async ()=>{
    const email = document.getElementById('loginEmail').value.trim();
    const password = document.getElementById('loginPassword').value;
    const errEl = document.getElementById('loginError');
    const btn = document.getElementById('loginBtn');
    if(!email || !password){ errEl.textContent='Enter both email and password'; errEl.classList.remove('hidden'); return; }
    errEl.classList.add('hidden');
    btn.textContent = 'Signing in…'; btn.disabled = true;
    const res = await attemptLogin(email, password);
    if(res.ok){
      document.getElementById('bottomnav').classList.remove('hidden');
      document.getElementById('settingsBtn').classList.remove('hidden');
      syncTopbar(); syncUserChip();
      state.tab = 'sell';
      renderActiveTab();
    } else {
      errEl.textContent = res.error; errEl.classList.remove('hidden');
      btn.textContent = 'Log in'; btn.disabled = false;
    }
  };
  document.getElementById('loginBtn').onclick = doLogin;
  document.getElementById('loginPassword').addEventListener('keydown', e=>{ if(e.key==='Enter') doLogin(); });
  document.getElementById('pwToggle').addEventListener('click', ()=>{
    const inp = document.getElementById('loginPassword');
    const toggleBtn = document.getElementById('pwToggle');
    const showing = inp.type === 'text';
    inp.type = showing ? 'password' : 'text';
    toggleBtn.innerHTML = showing ? ICO.eye : ICO.eyeOff;
    toggleBtn.setAttribute('aria-label', showing ? 'Show password' : 'Hide password');
    inp.focus();
  });
}

async function boot(){
  document.getElementById('screen').innerHTML = `<div class="empty-state" style="padding-top:80px">${ICO.box}<div class="t">Loading your store…</div></div>`;
  await loadAll();
  const savedErr = await getJSON('oyes:last_sync_error', null);
  if(savedErr && savedErr.msg){ state.sync.lastError = savedErr.msg; state.sync.lastErrorAt = savedErr.at || ''; }
  if(state.cloud.configured && !state.cloud.connected){
    // no restored session (never logged in on this device, or explicitly logged out) — needs network
    renderLogin();
  } else {
    if(state.cloud.configured && state.cloud.connected){
      document.getElementById('bottomnav').classList.remove('hidden');
      document.getElementById('settingsBtn').classList.remove('hidden');
      flushAllPending().then(()=>updateSyncBanner());
    }
    syncTopbar();
    renderActiveTab();
    updateSyncBanner();
  }
}
boot();

/* ---------------- PWA: service worker registration ---------------- */
if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('./sw.js')
      .catch((err) => console.error('Service worker registration failed:', err));
  });
}

/* =========================================================================
   Back button bridge
   In standalone/PWA mode there's no address bar, so the phone's hardware
   back button (and the browser's own back button, when running in a tab)
   would otherwise just exit the app the moment there's nothing left in the
   browser history. This traps EVERY back press and, instead:
     1. closes the topmost camera/modal/overlay screen, if one is open —
        by reusing that screen's OWN close/cancel control, so it behaves
        exactly like tapping its back arrow, backdrop, or Cancel button
        (including any unsaved-changes prompts or onCancel logic it has).
        This chains correctly through nested overlays too (e.g. the variant
        detail editor stacked on top of the product form): one back press
        closes the variant editor back to the product form, the next closes
        the product form back to the product list — each press consumes
        exactly one layer, however many are stacked.
     2. otherwise (nothing open, on any tab) shows an "Exit App?" prompt
        instead of switching tabs or silently exiting — the app only
        actually closes once that prompt is confirmed.
   The history entry is re-armed on every single back press (not just once),
   so the app can never be exited by mashing the back button — only via the
   explicit "Exit app" confirmation. No individual screen/modal needed to be
   modified for this to work.
   ========================================================================= */
(function(){
  function closeTopLayer(){
    if(document.getElementById('cameraOverlayRoot').firstElementChild){
      closeScanner();
      return true;
    }
    const modalBackdrop = document.querySelector('#modalRoot .modal-back');
    if(modalBackdrop){ modalBackdrop.click(); return true; }
    const back2 = document.querySelector('#overlayRoot2 .overlay-header button');
    if(back2){ back2.click(); return true; }
    const back1 = document.querySelector('#overlayRoot .overlay-header button');
    if(back1){ back1.click(); return true; }
    return false;
  }

  function rearm(){ history.pushState({ appGuard:true }, '', location.href); }

  // Best-effort real exit: tries whatever native bridge the packaged app (TWA/WebView
  // wrapper) exposes, falling back to window.close(), and finally to letting a real back
  // navigation proceed past our guard entry — which is what should actually end the app
  // when nothing else picks it up.
  function exitAppNow(){
    try{ if(window.Android && typeof window.Android.exitApp === 'function'){ window.Android.exitApp(); return; } }catch(e){}
    try{ if(window.AndroidBridge && typeof window.AndroidBridge.exitApp === 'function'){ window.AndroidBridge.exitApp(); return; } }catch(e){}
    try{ if(navigator.app && typeof navigator.app.exitApp === 'function'){ navigator.app.exitApp(); return; } }catch(e){}
    try{ window.close(); }catch(e){}
    setTimeout(()=>{ try{ history.back(); }catch(e){} }, 50);
  }

  let exitConfirmOpen = false;
  function showExitConfirm(){
    if(exitConfirmOpen) return;
    exitConfirmOpen = true;
    const root = document.getElementById('modalRoot');
    root.innerHTML = `
      <div class="modal-back" id="mbExitApp">
        <div class="modal-sheet">
          <div class="modal-handle"></div>
          <div class="section-title" style="padding-top:0">Exit App</div>
          <div class="field field-hint" style="padding-top:0">Do you want to close the app?</div>
          <div class="field"><div class="btn-row">
            <button class="btn btn-ghost" id="exitNo">No</button>
            <button class="btn btn-danger" id="exitYes">Exit app</button>
          </div></div>
        </div>
      </div>`;
    const close = ()=>{ root.innerHTML=''; exitConfirmOpen=false; };
    document.getElementById('mbExitApp').addEventListener('click', e=>{ if(e.target.id==='mbExitApp') close(); });
    document.getElementById('exitNo').onclick = close;
    document.getElementById('exitYes').onclick = ()=>{ close(); exitAppNow(); };
  }

  function handlePopState(){
    rearm();
    if(closeTopLayer()) return;
    showExitConfirm();
  }

  rearm();
  window.addEventListener('popstate', handlePopState);
})();
